import { useRef, useState } from "react";
import {
  CheckCircle2,
  FileSpreadsheet,
  UploadCloud,
  XCircle
} from "lucide-react";
import { api } from "../api";
import { ErrorBlock, PageHeader } from "../components/Shared";

const columns = [
  "user_id",
  "date",
  "has_any_event",
  "logon_count",
  "logoff_count",
  "first_logon_minute",
  "last_logoff_minute",
  "active_span_minutes",
  "after_hours_logon_count",
  "other_pc_logon_count",
  "usb_connect_count",
  "usb_disconnect_count",
  "file_copy_count",
  "archive_copy_count",
  "executable_copy_count",
  "unique_file_extensions",
  "email_count",
  "email_recipient_count",
  "external_recipient_count",
  "email_attachment_count",
  "email_size_bytes",
  "after_hours_email_count",
  "http_count",
  "after_hours_http_count",
  "external_http_count",
  "unique_http_domains",
  "is_weekend",
  "weekday_sin",
  "weekday_cos"
];

export function UploadCenter({
  onCreated
}: {
  onCreated: (runId: string) => void;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [headerStatus, setHeaderStatus] = useState<
    "empty" | "valid" | "invalid"
  >("empty");
  const [headerError, setHeaderError] = useState("");
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const acceptFile = async (candidate: File) => {
    setFile(candidate);
    setError(null);
    setSuccess(null);
    setHeaderStatus("empty");
    const firstLine = (await candidate.slice(0, 16_384).text()).split(/\r?\n/)[0];
    const actual = firstLine.split(",").map((item) => item.trim());
    const valid =
      actual.length === columns.length &&
      actual.every((item, index) => item === columns[index]);
    setHeaderStatus(valid ? "valid" : "invalid");
    setHeaderError(
      valid
        ? ""
        : `列契约不匹配：需要 ${columns.length} 列且顺序固定，当前 ${actual.length} 列。`
    );
  };

  const submit = async () => {
    if (!file || headerStatus !== "valid") return;
    setUploading(true);
    setError(null);
    setSuccess(null);
    try {
      const result = await api.upload(file);
      setSuccess(`推理完成，Run ID：${result.run_id}`);
      onCreated(result.run_id);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "上传推理失败");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="page-stack">
      <PageHeader
        eyebrow="数据接入 / Unlabeled Live"
        title="CSV 数据接入与离线推理中心"
        description="生产模式只读取 29 列无标签契约，不读取 labels、event_id 或事件真值。"
      />
      <section className="upload-layout">
        <article
          className={`drop-zone ${dragging ? "is-dragging" : ""}`}
          onDragOver={(event) => {
            event.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(event) => {
            event.preventDefault();
            setDragging(false);
            const dropped = event.dataTransfer.files[0];
            if (dropped) void acceptFile(dropped);
          }}
          onClick={() => inputRef.current?.click()}
        >
          <input
            ref={inputRef}
            type="file"
            accept=".csv,text/csv"
            hidden
            onChange={(event) => {
              const selected = event.target.files?.[0];
              if (selected) void acceptFile(selected);
            }}
          />
          <UploadCloud size={38} />
          <h2>拖拽脱敏 CSV 到此处</h2>
          <p>最大 64 MiB，列顺序必须严格符合生产契约。</p>
          <button className="button secondary" type="button">
            选择文件
          </button>
        </article>
        <article className="panel">
          <div className="panel-title">
            <div>
              <span className="eyebrow">契约检查</span>
              <h2>上传状态</h2>
            </div>
            <FileSpreadsheet size={20} />
          </div>
          {file ? (
            <div className="file-summary">
              <strong>{file.name}</strong>
              <span>{(file.size / 1024 / 1024).toFixed(2)} MiB</span>
            </div>
          ) : (
            <p className="muted">尚未选择文件。</p>
          )}
          {headerStatus === "valid" ? (
            <p className="contract-ok">
              <CheckCircle2 size={17} />
              29 列生产契约校验通过
            </p>
          ) : null}
          {headerStatus === "invalid" ? (
            <p className="contract-bad">
              <XCircle size={17} />
              {headerError}
            </p>
          ) : null}
          {error ? <ErrorBlock message={error} /> : null}
          {success ? (
            <p className="contract-ok">
              <CheckCircle2 size={17} />
              {success}
            </p>
          ) : null}
          <button
            className="button primary wide"
            disabled={!file || headerStatus !== "valid" || uploading}
            onClick={submit}
          >
            {uploading ? "完成契约检查并推理中" : "上传并启动无标签推理"}
          </button>
        </article>
      </section>
      <section className="panel">
        <div className="panel-title">
          <div>
            <span className="eyebrow">29-Column Contract</span>
            <h2>生产 CSV 列定义</h2>
          </div>
        </div>
        <div className="column-contract">
          {columns.map((column, index) => (
            <span key={column}>
              <i>{String(index + 1).padStart(2, "0")}</i>
              {column}
            </span>
          ))}
        </div>
        <p className="panel-note">
          `-1` 仅表示时间坐标缺失；午夜 `0` 是有效观察值，不得转换为缺失。
        </p>
      </section>
    </div>
  );
}
