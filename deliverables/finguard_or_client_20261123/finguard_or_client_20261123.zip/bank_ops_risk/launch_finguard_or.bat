@echo off
title FinGuard-OR Client Launcher
cd /d "E:\MarketRisker\work\cert\apps\bank_ops_risk"
if errorlevel 1 (
    echo [ERROR] Directory not found: E:\MarketRisker\work\cert\apps\bank_ops_risk
    pause
    exit /b 1
)
echo ==================================================
echo   FinGuard-OR Client Starting (waiting ~5s)...
echo   URL: http://127.0.0.1:8000
echo   Close this window or press Ctrl+C to stop.
echo ==================================================
netstat -ano | findstr ":8000 " | findstr "LISTENING" >nul
if %errorlevel%==0 (
    echo [INFO] Port 8000 is already running. Opening browser...
    start "" "http://127.0.0.1:8000"
    exit /b 0
)
start "" /b powershell -NoProfile -WindowStyle Hidden -Command "for($i=0;$i -lt 60;$i++){try{$c=New-Object System.Net.Sockets.TcpClient('127.0.0.1',8000);$c.Close();Start-Process 'http://127.0.0.1:8000';break}catch{Start-Sleep -Milliseconds 500}}"
"C:\Users\Lenovo\.conda\envs\ts2vec\python.exe" -m uvicorn api:app --host 127.0.0.1 --port 8000
pause
