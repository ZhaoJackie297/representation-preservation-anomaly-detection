import { useCallback, useEffect, useMemo, useState } from "react";
import { RefreshCw } from "lucide-react";
import { api } from "./api";
import { roleLabel } from "./format";
import type { Health, Overview, Role, RunSummary } from "./types";
import { Alerts } from "./views/Alerts";
import { ComplianceCenter } from "./views/ComplianceCenter";
import { Dashboard } from "./views/Dashboard";
import { DrillLab } from "./views/DrillLab";
import { UploadCenter } from "./views/UploadCenter";
import { ErrorBlock, HealthDot, LoadingBlock } from "./components/Shared";

type Page = "dashboard" | "alerts" | "drill" | "upload" | "compliance";

const navItems = [
  { id: "dashboard" as const, label: "风险概览" },
  { id: "alerts" as const, label: "每日候选队列" },
  { id: "drill" as const, label: "红队演练" },
  { id: "upload" as const, label: "行内日志接入" },
  { id: "compliance" as const, label: "处置与审计台账" }
];

export function App() {
  const [page, setPage] = useState<Page>("dashboard");
  const [role, setRoleState] = useState<Role>(
    () =>
      (localStorage.getItem("finguard-role") as Role) ||
      "first_line_reviewer"
  );
  const [health, setHealth] = useState<Health | null>(null);
  const [runs, setRuns] = useState<RunSummary[]>([]);
  const [selectedRunId, setSelectedRunId] = useState<string | null>(null);
  const [overview, setOverview] = useState<Overview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const setRole = (next: Role) => {
    setRoleState(next);
    localStorage.setItem("finguard-role", next);
  };

  const refreshRuns = useCallback(
    async (preferredRunId?: string) => {
      setError(null);
      try {
        const [healthResult, runResult] = await Promise.all([
          api.health(),
          api.runs()
        ]);
        setHealth(healthResult);
        setRuns(runResult);
        setSelectedRunId((current) => {
          const candidate = preferredRunId ?? current;
          if (candidate && runResult.some((item) => item.run_id === candidate)) {
            return candidate;
          }
          return runResult[0]?.run_id ?? null;
        });
      } catch (reason) {
        setError(reason instanceof Error ? reason.message : "服务连接失败");
      } finally {
        setLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    void refreshRuns();
  }, [refreshRuns]);

  useEffect(() => {
    if (!selectedRunId) {
      setOverview(null);
      return;
    }
    let active = true;
    api
      .overview(selectedRunId)
      .then((result) => {
        if (active) setOverview(result);
      })
      .catch((reason: Error) => {
        if (active) setError(reason.message);
      });
    return () => {
      active = false;
    };
  }, [selectedRunId]);

  const selectedRun = useMemo(
    () => runs.find((item) => item.run_id === selectedRunId) ?? null,
    [runs, selectedRunId]
  );
  const toolbarDate = useMemo(() => {
    const source = selectedRun?.started_at;
    const date = source ? new Date(source) : new Date();
    return Number.isNaN(date.getTime())
      ? "—"
      : new Intl.DateTimeFormat("zh-CN", {
          year: "numeric",
          month: "2-digit",
          day: "2-digit"
        })
          .format(date)
          .replaceAll("/", ".");
  }, [selectedRun?.started_at]);

  const onCreated = (runId: string) => {
    void refreshRuns(runId).then(() => {
      setPage("dashboard");
    });
  };

  return (
    <div className="app-shell terminal-app">
      <div className="top-stripe" />
      <header className="terminal-header">
        <div className="brand-block">
          <div className="brand-name">
            <strong>FinGuard</strong>
            <span>/ OR</span>
          </div>
          <small>Operation Risk Intelligence</small>
        </div>
        <nav className="terminal-nav">
          {navItems.map((item) => {
            return (
              <button
                key={item.id}
                className={page === item.id ? "active" : ""}
                onClick={() => setPage(item.id)}
              >
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="terminal-header-actions">
          <span className="intranet-chip">行内专网</span>
          <label className="header-batch">
            <span>批次</span>
            <select
              value={selectedRunId ?? ""}
              onChange={(event) => setSelectedRunId(event.target.value)}
              aria-label="运行批次"
            >
              {runs.length === 0 ? <option value="">暂无运行批次</option> : null}
              {runs.map((run) => (
                <option value={run.run_id} key={run.run_id}>
                  {run.run_id.slice(0, 8)} ·{" "}
                  {run.run_mode === "simulated_drill" ? "演练" : "生产"}
                </option>
              ))}
            </select>
          </label>
          <button
            className="header-refresh"
            onClick={() => void refreshRuns(selectedRunId ?? undefined)}
            title="刷新批次与模型状态"
          >
            <RefreshCw size={14} />
            刷新
          </button>
          <label className="role-select">
            <span>当前角色</span>
            <select
              value={role}
              onChange={(event) => setRole(event.target.value as Role)}
            >
              <option value="first_line_reviewer">
                {roleLabel("first_line_reviewer")}
              </option>
              <option value="second_line_risk">
                {roleLabel("second_line_risk")}
              </option>
              <option value="third_line_audit">
                {roleLabel("third_line_audit")}
              </option>
            </select>
          </label>
          <time className="terminal-date">{toolbarDate}</time>
        </div>
      </header>

      <div className="terminal-context-bar">
        <div className="context-identity">
          <span>
            智御内控 <b>FinGuard-OR</b>
          </span>
          <small>商业银行内部操作风险监测与证据核查系统</small>
        </div>
        <div className="context-status">
          <HealthDot
            ok={Boolean(health?.database_connected)}
            text={health?.database_connected ? "数据库在线" : "数据库异常"}
          />
          <HealthDot
            ok={Boolean(health?.model_frozen)}
            text={health?.model_frozen ? "冻结模型校验通过" : "模型缺失"}
          />
          <span className="env-chip">
            {health?.environment_mode ?? "development"}
          </span>
          <span className="model-chip">
            {selectedRun?.model_version ?? health?.model_version ?? "模型待连接"}
          </span>
          {selectedRun?.run_mode === "simulated_drill" ? (
            <span className="synthetic-chip">合成演练批次</span>
          ) : null}
        </div>
      </div>

      <main className={page === "alerts" ? "alerts-main" : ""}>
          {error ? <ErrorBlock message={error} /> : null}
          {loading ? <LoadingBlock label="正在连接 FinGuard-OR 后端" /> : null}
          {!loading && page === "dashboard" ? (
            <Dashboard
              overview={overview}
              onConfigureDrill={() => setPage("drill")}
            />
          ) : null}
          {!loading && page === "alerts" ? (
            <Alerts
              runId={selectedRunId}
              run={selectedRun}
              role={role}
              overview={overview}
              onChanged={() => void refreshRuns(selectedRunId ?? undefined)}
            />
          ) : null}
          {!loading && page === "drill" ? (
            <DrillLab overview={overview} onCreated={onCreated} />
          ) : null}
          {!loading && page === "upload" ? (
            <UploadCenter onCreated={onCreated} />
          ) : null}
          {!loading && page === "compliance" ? (
            <ComplianceCenter
              runId={selectedRunId}
              role={role}
              setRole={setRole}
            />
          ) : null}
      </main>
      <footer className="app-footer terminal-footer">
        <span>
          版本与数据来源：
          <strong>{selectedRun?.model_version ?? "模型待连接"}</strong>
          {" · "}
          {selectedRun ? `批次 ${selectedRun.run_id.slice(0, 8)}` : "无运行批次"}
          {" · "}
          零标签生产与合成演练隔离
        </span>
        <span className="mono">行内二道防线风控专网终端 · 审计摘要已固化</span>
      </footer>
    </div>
  );
}
