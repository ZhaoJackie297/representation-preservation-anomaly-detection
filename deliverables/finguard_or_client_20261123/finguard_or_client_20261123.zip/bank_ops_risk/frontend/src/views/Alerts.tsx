import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Filter,
  Search,
  ShieldCheck,
  Star
} from "lucide-react";
import { api } from "../api";
import { formatNumber, formatScore } from "../format";
import type {
  AlertItem,
  AlertPage,
  Overview,
  Role,
  RunSummary
} from "../types";
import { ErrorBlock, LoadingBlock } from "../components/Shared";
import { AlertDrawer } from "./AlertDrawer";

const PAGE_SIZE = 10;

export function Alerts({
  runId,
  run,
  role,
  overview,
  onChanged
}: {
  runId: string | null;
  run: RunSummary | null;
  role: Role;
  overview: Overview | null;
  onChanged: () => void;
}) {
  const [page, setPage] = useState(1);
  const [date, setDate] = useState("");
  const [department, setDepartment] = useState("");
  const [alertRole, setAlertRole] = useState("");
  const [status, setStatus] = useState("");
  const [minScore, setMinScore] = useState("");
  const [data, setData] = useState<AlertPage | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const filters = useMemo(
    () => ({ date, department, role: alertRole, status, minScore }),
    [date, department, alertRole, status, minScore]
  );

  const refreshPage = useCallback(async () => {
    if (!runId) return;
    const result = await api.alerts(runId, {
      page,
      pageSize: PAGE_SIZE,
      ...filters
    });
    setData(result);
  }, [filters, page, runId]);

  useEffect(() => {
    if (!runId) return;
    let active = true;
    setLoading(true);
    setError(null);
    api
      .alerts(runId, {
        page,
        pageSize: PAGE_SIZE,
        ...filters
      })
      .then((result) => {
        if (active) setData(result);
      })
      .catch((reason: Error) => {
        if (active) setError(reason.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [filters, page, runId]);

  useEffect(() => {
    setPage(1);
  }, [date, department, alertRole, status, minScore]);

  useEffect(() => {
    if (!date && data?.items[0]?.alert_date) {
      setDate(data.items[0].alert_date);
    }
  }, [data, date]);

  useEffect(() => {
    if (!data?.items.length) {
      setSelected(null);
      return;
    }
    if (!selected || !data.items.some((item) => item.alert_id === selected)) {
      setSelected(data.items[0].alert_id);
    }
  }, [data, selected]);

  useEffect(() => {
    setPage(1);
    setDate("");
    setDepartment("");
    setAlertRole("");
    setStatus("");
    setMinScore("");
    setSelected(null);
  }, [runId]);

  const selectedIndex = useMemo(
    () =>
      data?.items.findIndex((item) => item.alert_id === selected) ??
      -1,
    [data, selected]
  );
  const selectedAlert = selectedIndex >= 0 ? data?.items[selectedIndex] : null;
  const currentDate =
    date || selectedAlert?.alert_date || data?.items[0]?.alert_date || "—";
  const maxRisk = Math.max(
    0,
    ...(data?.items.map((item) => item.risk_score) ?? [])
  );
  const activeEmployees =
    overview?.latest_active_employees ??
    overview?.evaluation_employee_count ??
    0;
  const cooldownCount = overview?.cooldown_suppressed_candidates ?? 0;
  const metricLabel = scoringLabel(run?.selected_metric);

  const handleChanged = async () => {
    onChanged();
    try {
      await refreshPage();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "队列刷新失败");
    }
  };

  if (!runId) {
    return (
      <section className="terminal-empty-state">
        <ShieldCheck size={30} />
        <h1>请选择运行批次</h1>
        <p>批次决定候选队列、评分口径、证据卡与处置权限边界。</p>
      </section>
    );
  }

  return (
    <div className="alerts-terminal-page">
      <section className="alert-command-header">
        <div>
          <span className="terminal-breadcrumb">
            操作风险监控 / 每日审查 / {currentDate}
          </span>
          <h1>每日异常候选队列</h1>
          <p>
            Top-K 仅形成人工复核优先级，不直接构成风险结论；Watchlist
            只影响展示排序。
          </p>
        </div>
        <div className="alert-summary-strip">
          <SummaryMetric label="活跃员工" value={activeEmployees} unit="人" />
          <SummaryMetric
            label="审查容量"
            value={run?.top_k ?? 10}
            unit="人/日"
          />
          <SummaryMetric
            label="冷却期"
            value={run?.cooldown_days ?? 7}
            unit="天"
          />
          <SummaryMetric
            label="最高风险"
            value={formatScore(maxRisk)}
            tone="risk"
          />
        </div>
      </section>

      <section className="alert-filter-strip" aria-label="候选队列筛选">
        <span className="filter-title">
          <Filter size={14} />
          同批筛选
        </span>
        <label>
          <span>核查日</span>
          <input
            type="date"
            value={date}
            onChange={(event) => setDate(event.target.value)}
          />
        </label>
        <label>
          <span>责任网格</span>
          <select
            value={department}
            onChange={(event) => setDepartment(event.target.value)}
          >
            <option value="">全部网格</option>
            <option value="总行">总行</option>
            <option value="分行">分行</option>
            <option value="网点">网点</option>
          </select>
        </label>
        <label>
          <span>岗位</span>
          <select
            value={alertRole}
            onChange={(event) => setAlertRole(event.target.value)}
          >
            <option value="">全部岗位</option>
            <option value="柜面运营">柜面运营</option>
            <option value="客户经理">客户经理</option>
            <option value="信贷审批">信贷审批</option>
            <option value="科技运维">科技运维</option>
          </select>
        </label>
        <label>
          <span>复核状态</span>
          <select
            value={status}
            onChange={(event) => setStatus(event.target.value)}
          >
            <option value="">全部状态</option>
            <option value="pending">待复核</option>
            <option value="confirmed_risk">确认风险</option>
            <option value="false_positive">误报</option>
            <option value="watchlist_observe">关注观察</option>
            <option value="escalate_audit">升级内审</option>
          </select>
        </label>
        <label>
          <span>最低风险分</span>
          <input
            type="number"
            step="0.1"
            placeholder="不限"
            value={minScore}
            onChange={(event) => setMinScore(event.target.value)}
          />
        </label>
        <span className="filter-router mono">
          路由 |ρ|={Math.abs(run?.abs_rho ?? 0).toFixed(3)} · {metricLabel}
        </span>
      </section>

      {error ? <ErrorBlock message={error} /> : null}

      <div className="alert-review-layout">
        <section className="terminal-panel candidate-queue-pane">
          <header className="terminal-panel-head">
            <div>
              <span className="panel-rule" />
              <div>
                <h2>候选队列</h2>
                <small>
                  {currentDate} · TOP-{run?.top_k ?? 10}
                </small>
              </div>
            </div>
            <span className="panel-counter mono">
              {formatNumber(data?.pagination.total ?? 0)} 条
            </span>
          </header>

          <div className="queue-kpi-strip">
            <div>
              <span>当日受检</span>
              <strong className="mono">{formatNumber(activeEmployees)}</strong>
              <small>在岗员工</small>
            </div>
            <div>
              <span>冷却抑制</span>
              <strong className="mono">{formatNumber(cooldownCount)}</strong>
              <small>候选人次</small>
            </div>
            <div>
              <span>当前队列</span>
              <strong className="mono">
                {data?.items.length ?? 0}
                <em>/{run?.top_k ?? 10}</em>
              </strong>
              <small>同批联查</small>
            </div>
          </div>

          <div className="queue-table-wrap">
            <table className="queue-table">
              <thead>
                <tr>
                  <th>日期</th>
                  <th className="center">排名</th>
                  <th>员工 / 所属条线</th>
                  <th className="right">风险分</th>
                  <th>评分来源</th>
                  <th>处理建议</th>
                </tr>
              </thead>
              <tbody>
                {data?.items.map((alert, index) => {
                  const isSelected = alert.alert_id === selected;
                  return (
                    <tr
                      key={alert.alert_id}
                      className={`${isSelected ? "row-selected " : ""}${
                        index % 2 ? "row-alt" : ""
                      }${alert.watchlist_flag ? " row-watch" : ""}`}
                      onClick={() => setSelected(alert.alert_id)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter" || event.key === " ") {
                          event.preventDefault();
                          setSelected(alert.alert_id);
                        }
                      }}
                      tabIndex={0}
                    >
                      <td className="mono queue-date">{alert.alert_date}</td>
                      <td className="center queue-rank">
                        <strong className="mono">#{index + 1}</strong>
                        <small className="mono">全周期 #{alert.rank}</small>
                      </td>
                      <td>
                        <div className="queue-employee">
                          <strong className="mono">
                            {alert.employee_id_masked}
                          </strong>
                          {alert.watchlist_flag ? (
                            <Star size={12} fill="currentColor" />
                          ) : null}
                        </div>
                        <small>
                          {alert.grid_name} · {alert.role_name}
                        </small>
                      </td>
                      <td
                        className={`right mono queue-score ${
                          index === 0 ? "is-critical" : ""
                        }`}
                      >
                        {formatScore(alert.risk_score)}
                      </td>
                      <td>
                        <span className="source-pill mono">{metricLabel}</span>
                      </td>
                      <td>
                        <span
                          className={`queue-advice ${adviceTone(
                            alert,
                            index
                          )}`}
                        >
                          {adviceLabel(alert, index)}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {loading && !data ? <LoadingBlock /> : null}
            {!loading && data?.items.length === 0 ? (
              <div className="terminal-empty-table">
                <Search size={22} />
                当前筛选条件下没有候选记录
              </div>
            ) : null}
          </div>

          <footer className="queue-footer">
            <span>
              {selectedAlert
                ? `已选中 #${selectedIndex + 1} ${selectedAlert.employee_id_masked} · 右侧同批联动`
                : "选择左侧候选记录以调阅证据卡"}
            </span>
            <div>
              <span className="mono">
                {(data?.pagination.page ?? 1) * PAGE_SIZE - PAGE_SIZE + 1}–
                {Math.min(
                  (data?.pagination.page ?? 1) * PAGE_SIZE,
                  data?.pagination.total ?? 0
                )}{" "}
                / {data?.pagination.total ?? 0}
              </span>
              <button
                className="square-button"
                disabled={(data?.pagination.page ?? 1) <= 1}
                onClick={() => setPage((value) => Math.max(value - 1, 1))}
                aria-label="上一页"
              >
                <ChevronLeft size={15} />
              </button>
              <button
                className="square-button"
                disabled={
                  (data?.pagination.page ?? 1) >=
                  (data?.pagination.pages ?? 0)
                }
                onClick={() => setPage((value) => value + 1)}
                aria-label="下一页"
              >
                <ChevronRight size={15} />
              </button>
            </div>
          </footer>
        </section>

        {selected ? (
          <AlertDrawer
            alertId={selected}
            role={role}
            queueRank={Math.max(selectedIndex + 1, 1)}
            run={run}
            onClose={() => setSelected(null)}
            onChanged={() => void handleChanged()}
          />
        ) : (
          <section className="terminal-panel evidence-placeholder">
            <ShieldCheck size={34} />
            <h2>待选择候选记录</h2>
            <p>证据卡将随左侧队列选择实时切换，并保持在同一运行批次内。</p>
          </section>
        )}
      </div>
    </div>
  );
}

function SummaryMetric({
  label,
  value,
  unit,
  tone = "default"
}: {
  label: string;
  value: string | number;
  unit?: string;
  tone?: "default" | "risk";
}) {
  return (
    <div className={`summary-metric summary-${tone}`}>
      <span>{label}</span>
      <strong className="mono">
        {value}
        {unit ? <small>{unit}</small> : null}
      </strong>
    </div>
  );
}

function scoringLabel(metric: string | null | undefined): string {
  return (
    {
      pai_mean: "PAI-Mean",
      bank_cosine: "余弦库",
      bank_euclidean: "欧氏库",
      mask_original: "Mask-L1"
    } as Record<string, string>
  )[metric ?? ""] ?? "PAI-Mean";
}

function adviceLabel(alert: AlertItem, index: number): string {
  if (index === 0) return "优先复核";
  if (alert.watchlist_flag) return "重点关注";
  if (alert.status !== "pending") return "已处置";
  return index < 4 ? "重点复核" : "常规复核";
}

function adviceTone(alert: AlertItem, index: number): string {
  if (index === 0) return "is-priority";
  if (alert.watchlist_flag) return "is-watch";
  if (alert.status !== "pending") return "is-closed";
  return index < 4 ? "is-review" : "is-routine";
}
