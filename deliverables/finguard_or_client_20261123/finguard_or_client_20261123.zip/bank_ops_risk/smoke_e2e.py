"""End-to-end headless smoke for Work Package 1."""

from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path

import pandas as pd
from sqlalchemy import func, select

from bank_sim_generator import DEFAULT_OUTPUT_DIR, generate_bank_sim
from db import (
    Alert,
    AuditTrail,
    ReviewLDC,
    Run,
    WatchlistEntity,
    create_db_engine,
    create_review,
    create_session_factory,
    init_db,
    persist_run_result,
    session_scope,
    set_watchlist,
)
from model_runner import ModelRunner


def main() -> None:
    started = time.time()
    data_manifest = generate_bank_sim(force=True)
    generation_seconds = time.time() - started
    data_dir = DEFAULT_OUTPUT_DIR
    unlabeled = data_dir / "bank_sim_unlabeled.csv"
    staff = pd.read_csv(data_dir / "bank_staff_meta.csv")
    staff_map = staff.set_index("employee_id")[
        ["grid_name", "role_name"]
    ].to_dict(orient="index")

    inference_started = time.time()
    result = ModelRunner().fast_bank_refit(
        unlabeled,
        run_mode="unlabeled_live",
    )
    inference_seconds = time.time() - inference_started

    smoke_dir = data_dir / "smoke"
    smoke_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    db_path = smoke_dir / f"finguard_or_smoke_{stamp}.db"
    engine = create_db_engine(f"sqlite:///{db_path.as_posix()}")
    init_db(engine)
    factory = create_session_factory(engine)
    with session_scope(factory) as session:
        first_employee = result.alerts[0]["employee_id"]
        set_watchlist(
            session,
            employee_id=first_employee,
            reason="演练中的人工重点关注示例",
            created_by="smoke_runner",
        )
        run = persist_run_result(session, result, staff_meta=staff_map)
        first_alert = session.scalar(
            select(Alert).where(Alert.run_id == run.id).limit(1)
        )
        create_review(
            session,
            alert_id=first_alert.id,
            review_state="escalated_ldc",
            reviewer_role="smoke_reviewer",
            recommended_action="核查导出审批与终端登录授权",
            review_notes="端到端冒烟复核",
        )

    with session_scope(factory) as session:
        table_counts = {
            "runs": session.scalar(select(func.count()).select_from(Run)),
            "alerts": session.scalar(select(func.count()).select_from(Alert)),
            "reviews_ldc": session.scalar(
                select(func.count()).select_from(ReviewLDC)
            ),
            "watchlist_entities": session.scalar(
                select(func.count()).select_from(WatchlistEntity)
            ),
            "audit_trail": session.scalar(
                select(func.count()).select_from(AuditTrail)
            ),
        }
        stored_alert = session.scalar(select(Alert).limit(1))
        evidence = stored_alert.evidence_card

    output = {
        "generation_seconds": round(generation_seconds, 3),
        "inference_seconds": round(inference_seconds, 3),
        "generated_rows": data_manifest["employees"] * data_manifest["days"],
        "events": data_manifest["events"],
        "missing_timing_cells": data_manifest["missing_timing_cells"],
        "midnight_zero_cells": data_manifest["midnight_zero_cells"],
        "run_mode": result.run_mode,
        "execution_profile": result.metrics["execution_profile"],
        "device": result.metrics["device"],
        "cross_modal_audit": result.cross_modal_audit,
        "alert_count": len(result.alerts),
        "alerted_employee_count": result.metrics["alerted_employee_count"],
        "cooldown_suppressed_candidates": result.metrics[
            "cooldown_suppressed_candidates"
        ],
        "score_distribution": result.metrics["score_distribution"],
        "table_counts": table_counts,
        "evidence_card_type": evidence["evidence_card_type"],
        "evidence_card_keys": sorted(evidence),
        "contains_raw_first_logon_min": "raw_first_logon_min" in evidence,
        "contains_peer_channel_means": "peer_channel_means" in evidence,
        "sample_peer_channel_means": evidence["peer_channel_means"],
        "sample_raw_first_logon_min": evidence["raw_first_logon_min"],
        "database_path": str(db_path),
    }
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
