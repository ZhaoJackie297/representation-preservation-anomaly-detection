# 补实验执行交接说明（给执行 AI / 本地实验机）

本目录包含面向仓库 `ZhaoJackie297/representation-preservation-anomaly-detection` 的**最小可执行补实验脚本包**，用于回应中文一级学报 / CCF-B 审稿意见中的全部关键实验缺口。

## 0. 执行铁律（请严格遵守）

1. **禁止编造、插值或修改任何指标**；所有数字必须来自真实脚本运行结果，原样保存 CSV/JSON。
2. **严禁覆盖或修改仓库原有的 `results/canonical/`、已有模型权重及数据切分**；所有新产物统一写入 `research/ccf-b/supplement_results/`。
3. **部署位置**：将本文件夹内全部 `exp_s*.py` 复制到仓库目录 `<repo_root>/research/ccf-b/supplement/` 后，**在 `<repo_root>` 根目录**下运行。
4. **若遇到路径/环境微差**（例如本地 `<external-root>` 路径、旧 `.npz` 的 key 名、数据文件路径或 `runtime/cert` 数据软链接未建）：先检查本地真实路径并只调整命令行参数或做最小适配，**不要改动评测口径**（时间外切分、`-1 -> NaN` 缺失契约、`K ∈ {5, 10, 20}`、7 天冷却期、3 日容差、固定 10 种子 `20261116–20261125`）。
5. **步数锁定铁律（Exp S2）**：如果 `exp_s2_coverage_dose_and_null_graphs.py` 提示 `dose_A3_90` 所需批数超过 `--total-steps 700`，请按报错给出的批数将 `--total-steps` 统一提高（例如 `850` 或 `900`）并加 `--force` 让全部 6 组条件在**完全相同的总梯度步数**下运行。

---

## 1. 先做 1 分钟环境与路径预检（执行 AI 第一步）

```powershell
# 1) 确认仓库根目录、GPU 与 Python 环境
python -c "import torch, scipy, sklearn, pandas; print('CUDA:', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU')"

# 2) 确认 CERT 预处理数据已链接到位
Test-Path runtime/cert/processed_r42/r4.2_sequence_dataset.npz
Test-Path runtime/cert/processed_r52/r5.2_sequence_dataset.npz

# 3) 创建脚本目录并把本包里的 exp_s*.py 复制进去
New-Item -ItemType Directory -Force -Path research/ccf-b/supplement | Out-Null
# Copy-Item "<本包路径>\exp_s*.py" research/ccf-b/supplement/ -Force
```

---

## 2. 按优先级依次执行（P0 必跑，P1 强烈建议）

### 任务 A（P0，纯 CPU，~5 分钟，零重训）：`exp_s3_cpu_diagnostics_bootstrap_norm.py`

```powershell
# A1. CERT r4.2 200 种子随机排序器事件召回基线
python research/ccf-b/supplement/exp_s3_cpu_diagnostics_bootstrap_norm.py random-r42

# A2. 无编码器独立幅值基线（纯 magG / 纯 T2 / magG+T2）
python research/ccf-b/supplement/exp_s3_cpu_diagnostics_bootstrap_norm.py amp-standalone --dataset r4.2
python research/ccf-b/supplement/exp_s3_cpu_diagnostics_bootstrap_norm.py amp-standalone --dataset r5.2

# A3. CERT r4.2 表示范数 vs. 输入幅值相关性 + 式(7) 径向/角度能量分解
#     先在本地查找已有 T0 / T3 / T4 / A1-Cov 的 model.pth（同 seed 20261116 即可）再传入 --checkpoints
python research/ccf-b/supplement/exp_s3_cpu_diagnostics_bootstrap_norm.py norm-corr `
  --dataset r4.2 `
  --checkpoints T0=<本地T0_seed20261116/model.pth> T3=<本地T3_seed20261116/model.pth> T4=<本地T4_seed20261116/model.pth>

# A4. 已有 10 种子分数的事件级 Bootstrap (24/99 起独立事件) + 用户簇 Bootstrap (PR/ROC)
#     先检查本地 pilot_r42_10seed_scores_v1 和 r52_10seed_scores_v1 的目录结构与 .npz keys，
#     至少跑以下 4 组关键配对（r4.2 与 r5.2 各 2 组）：
#       1) A1-Cov + PAI-A1  vs  A0-official + plain
#       2) A1-Cov + PAI-A1  vs  A0-matched + PAI-A1
#     以及在任务 B 跑完后补跑：
#       3) SoftInst-Rand-Matched + PAI-A1  vs  A1-Cov + PAI-A1
python research/ccf-b/supplement/exp_s3_cpu_diagnostics_bootstrap_norm.py bootstrap `
  --dataset r4.2 `
  --dir-a "<external-root>\pilot_r42_10seed_scores_v1\A1-Cov" --key-a pai_a1 `
  --dir-b "<external-root>\pilot_r42_10seed_scores_v1\A0-official" --key-b plain_l1 `
  --tag r42_A1CovPAI_vs_OfficialPlain
```

### 任务 B（P0 核心定音，GPU，r4.2 ~10-15m / r5.2 ~20-30m）：`exp_s1_soft_random_4th_cell.py`

补齐缺失第 4 格（`Soft Instance + Random Batch`，10 种子 `20261116–20261125`），同一编码器同步输出 `plain_l1 / bank_cosine / bank_euclidean / pai_a1 / pai_official` 五种打分及 `hit_ids_k10.json`：

```powershell
# B1. CERT r4.2（标准 10 轮 620 步 + 匹配 A1-Cov 步数 ~1145 步；可加 --also-hard-random-matched 顺手排查步数差异）
python research/ccf-b/supplement/exp_s1_soft_random_4th_cell.py --dataset r4.2 --step-mode both --also-hard-random-matched

# B2. CERT r5.2（标准 10 轮 1250 步 + 匹配步数；先核对 r5.2 A1-Cov 实际批数填入 --r52-matched-steps）
python research/ccf-b/supplement/exp_s1_soft_random_4th_cell.py --dataset r5.2 --step-mode both
```

### 任务 C（P0 因果闭环，GPU，~15-20m / 目标）：`exp_s2_coverage_dose_and_null_graphs.py`

纯 $A_3$ 覆盖率剂量-响应（`~15% / 50% / 80% / 90%`）+ 独立空图对照（单独 `A5a`、单独 `A5b`，绝不与 $A_3$ 混在同一批表），全部 6 组严格锁定相同训练步数：

```powershell
# C1. 软实例目标（5 种子 20261116-20261120，若算力充足可传全部 10 种子）
python research/ccf-b/supplement/exp_s2_coverage_dose_and_null_graphs.py --objective soft --total-steps 700

# C2. 硬对比目标（同 6 组条件、同步数，形成完整的硬/软剂量-响应双曲线）
python research/ccf-b/supplement/exp_s2_coverage_dose_and_null_graphs.py --objective hard --total-steps 700
```

### 任务 D（P1 强烈建议，GPU，~15-20m）：`exp_s3b_smd_norm_corr.py` & `exp_s4_daily_ae_and_hyperparams.py`

```powershell
# D1. SMD 28 台服务器范数-幅值相关性与式(7) 径向/角度能量分解（与 A3 的 CERT 结果形成跨模态对照）
python research/ccf-b/supplement/exp_s3b_smd_norm_corr.py --seed 20261201

# D2. 正常日级深度基线（MLP-AE-27D 与 Causal LSTM-Pred-27D，替代失败的 Anomaly Transformer）
python research/ccf-b/supplement/exp_s4_daily_ae_and_hyperparams.py ae-baseline --dataset r4.2
python research/ccf-b/supplement/exp_s4_daily_ae_and_hyperparams.py ae-baseline --dataset r5.2

# D3. 软实例权重上限 alpha ∈ {0.25, 0.50, 0.75} 超参敏感性扫描
python research/ccf-b/supplement/exp_s4_daily_ae_and_hyperparams.py alpha-sweep
```

---

## 3. 完成后请打包回传的轻量结果文件（无需大模型权重与 `.npz`）

所有结果均在 `research/ccf-b/supplement_results/` 下，请汇总以下 CSV/JSON 返回给论文写作端：

1. `exp_s3_diagnostics/random_r42/r4.2_random_baseline_summary.csv`
2. `exp_s3_diagnostics/amp_standalone_r4.2/amp_standalone_summary.csv` & `amp_standalone_r5.2/amp_standalone_summary.csv`
3. `exp_s3_diagnostics/norm_corr_r4.2/norm_amplitude_radial_audit.csv` & `norm_corr_smd/smd_norm_amplitude_summary.csv`
4. `exp_s3_diagnostics/bootstrap_*/*_bootstrap.json`
5. `exp_s1_r4.2/method_summary.csv`、`exp_s1_r4.2/metrics_by_seed.csv`、`exp_s1_r5.2/method_summary.csv`、`exp_s1_r5.2/metrics_by_seed.csv`
6. `exp_s2_soft_r42/dose_response_summary.csv`、`exp_s2_soft_r42/coverage_audit.csv`、`exp_s2_hard_r42/dose_response_summary.csv`
7. `exp_s4_baselines_hp/ae_r4.2/ae_baselines_summary.csv`、`ae_r5.2/ae_baselines_summary.csv`、`alpha_sweep_r42/alpha_sweep_summary.csv`

*(执行过程如有任何报错、调整过的参数或发现异常，请一并附在 `RUN_LOG.md` 中如实说明。)*
