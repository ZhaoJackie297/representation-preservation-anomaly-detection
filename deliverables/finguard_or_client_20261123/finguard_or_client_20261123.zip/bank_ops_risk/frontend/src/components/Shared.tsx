import type { ReactNode } from "react";
import { AlertTriangle, CheckCircle2, LoaderCircle } from "lucide-react";

export function PageHeader({
  eyebrow,
  title,
  description,
  actions
}: {
  eyebrow: string;
  title: string;
  description: string;
  actions?: ReactNode;
}) {
  return (
    <header className="page-header">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {actions ? <div className="page-actions">{actions}</div> : null}
    </header>
  );
}

export function MetricCard({
  label,
  value,
  detail,
  tone = "default"
}: {
  label: string;
  value: ReactNode;
  detail?: string;
  tone?: "default" | "good" | "alert";
}) {
  return (
    <article className={`metric-card metric-${tone}`}>
      <span>{label}</span>
      <strong>{value}</strong>
      {detail ? <small>{detail}</small> : null}
    </article>
  );
}

export function SyntheticBanner({ text }: { text: string }) {
  return (
    <div className="synthetic-banner">
      <AlertTriangle size={17} />
      <strong>{text}</strong>
    </div>
  );
}

export function LoadingBlock({ label = "正在读取服务数据" }: { label?: string }) {
  return (
    <div className="loading-block">
      <LoaderCircle className="spin" size={20} />
      <span>{label}</span>
    </div>
  );
}

export function ErrorBlock({ message }: { message: string }) {
  return (
    <div className="error-block">
      <AlertTriangle size={18} />
      <span>{message}</span>
    </div>
  );
}

export function HealthDot({ ok, text }: { ok: boolean; text: string }) {
  return (
    <span className={`health-dot ${ok ? "is-ok" : "is-bad"}`}>
      {ok ? <CheckCircle2 size={14} /> : <AlertTriangle size={14} />}
      {text}
    </span>
  );
}
