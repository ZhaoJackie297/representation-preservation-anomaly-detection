"""SQLAlchemy persistence for FinGuard-OR.

The ORM uses portable SQLAlchemy types only. A deployment switches from SQLite
to openGauss by replacing DATABASE_URL; no SQLite-specific SQL is required.
"""

from __future__ import annotations

import os
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    create_engine,
    event,
    select,
)
from sqlalchemy.engine import Engine
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    Session,
    mapped_column,
    relationship,
    sessionmaker,
)


PACKAGE_ROOT = Path(__file__).resolve().parent
DEFAULT_DATABASE_URL = f"sqlite:///{(PACKAGE_ROOT / 'data' / 'finguard_or.db').as_posix()}"
DATABASE_URL_ENV = "FINGUARD_DATABASE_URL"
VALID_RUN_MODES = {"unlabeled_live", "simulated_drill", "benchmark"}
VALID_REVIEW_STATES = {
    "escalated_ldc",
    "dismissed_fp",
    "watchlist_cooldown",
}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class Run(Base):
    __tablename__ = "runs"

    id: Mapped[str] = mapped_column(
        String(64),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    run_mode: Mapped[str] = mapped_column(String(32), nullable=False)
    model_version: Mapped[str] = mapped_column(String(128), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="completed")
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=utc_now,
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    cross_modal_audit: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    metrics: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)

    alerts: Mapped[list["Alert"]] = relationship(
        back_populates="run",
        cascade="all, delete-orphan",
    )


class Alert(Base):
    __tablename__ = "alerts"

    id: Mapped[str] = mapped_column(
        String(64),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    run_id: Mapped[str] = mapped_column(
        ForeignKey("runs.id"),
        nullable=False,
        index=True,
    )
    employee_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    alert_date: Mapped[str] = mapped_column(String(10), nullable=False, index=True)
    rank: Mapped[int] = mapped_column(Integer, nullable=False)
    risk_score: Mapped[float] = mapped_column(Float, nullable=False)
    grid_name: Mapped[str] = mapped_column(String(32), nullable=False)
    role_name: Mapped[str] = mapped_column(String(64), nullable=False)
    basel_category: Mapped[str] = mapped_column(String(128), nullable=False)
    data_sensitivity_jr_t_0197: Mapped[str] = mapped_column(String(16), nullable=False)
    personal_info_jr_t_0171: Mapped[str] = mapped_column(String(16), nullable=False)
    watchlist_flag: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    reason_code: Mapped[str] = mapped_column(String(128), nullable=False)
    subscores: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    evidence_card: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=utc_now,
    )

    run: Mapped[Run] = relationship(back_populates="alerts")
    reviews: Mapped[list["ReviewLDC"]] = relationship(
        back_populates="alert",
        cascade="all, delete-orphan",
    )


class ReviewLDC(Base):
    __tablename__ = "reviews_ldc"

    id: Mapped[str] = mapped_column(
        String(64),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    alert_id: Mapped[str] = mapped_column(
        ForeignKey("alerts.id"),
        nullable=False,
        index=True,
    )
    review_state: Mapped[str] = mapped_column(String(32), nullable=False)
    basel_category_corrected: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True,
    )
    recommended_action: Mapped[str] = mapped_column(Text, nullable=False)
    reviewer_role: Mapped[str] = mapped_column(String(64), nullable=False)
    review_notes: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=utc_now,
    )

    alert: Mapped[Alert] = relationship(back_populates="reviews")


class WatchlistEntity(Base):
    __tablename__ = "watchlist_entities"

    id: Mapped[str] = mapped_column(
        String(64),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    employee_id: Mapped[str] = mapped_column(
        String(64),
        nullable=False,
        unique=True,
        index=True,
    )
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_by: Mapped[str] = mapped_column(String(64), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=utc_now,
    )
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )


class AuditTrail(Base):
    __tablename__ = "audit_trail"

    id: Mapped[str] = mapped_column(
        String(64),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    actor_role: Mapped[str] = mapped_column(String(64), nullable=False)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=utc_now,
    )
    target_entity: Mapped[str] = mapped_column(String(128), nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    action: Mapped[str] = mapped_column(String(64), nullable=False)
    action_details: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)


@event.listens_for(AuditTrail, "before_update")
@event.listens_for(AuditTrail, "before_delete")
def prevent_audit_mutation(*_args: object, **_kwargs: object) -> None:
    raise ValueError("audit_trail is append-only")


def create_db_engine(database_url: str = DEFAULT_DATABASE_URL) -> Engine:
    if database_url.startswith("sqlite"):
        database_path = database_url.removeprefix("sqlite:///")
        if database_path and database_path != ":memory:":
            Path(database_path).parent.mkdir(parents=True, exist_ok=True)
    return create_engine(database_url, future=True)


def database_url_from_env() -> str:
    """Read deployment URL; no model or schema change is needed for openGauss."""
    return os.environ.get(DATABASE_URL_ENV, DEFAULT_DATABASE_URL)


def create_session_factory(engine: Engine) -> sessionmaker[Session]:
    return sessionmaker(bind=engine, expire_on_commit=False, future=True)


def init_db(engine: Engine) -> None:
    Base.metadata.create_all(engine)


@contextmanager
def session_scope(factory: sessionmaker[Session]) -> Iterator[Session]:
    session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def append_audit(
    session: Session,
    *,
    actor_role: str,
    target_entity: str,
    reason: str,
    action: str,
    action_details: dict[str, Any],
) -> AuditTrail:
    entry = AuditTrail(
        actor_role=actor_role,
        target_entity=target_entity,
        reason=reason,
        action=action,
        action_details=action_details,
    )
    session.add(entry)
    return entry


def persist_run_result(
    session: Session,
    result: Any,
    staff_meta: dict[str, dict[str, str]] | None = None,
) -> Run:
    if result.run_mode not in VALID_RUN_MODES:
        raise ValueError(f"Invalid run mode: {result.run_mode}")
    staff_meta = staff_meta or {}
    run = Run(
        run_mode=result.run_mode,
        model_version=result.model_version,
        status="completed",
        completed_at=utc_now(),
        cross_modal_audit=result.cross_modal_audit,
        metrics=result.metrics,
    )
    session.add(run)
    session.flush()
    active_watchlist = set(
        session.scalars(
            select(WatchlistEntity.employee_id).where(
                WatchlistEntity.active.is_(True)
            )
        )
    )
    for payload in result.alerts:
        metadata = staff_meta.get(payload["employee_id"], {})
        session.add(
            Alert(
                run_id=run.id,
                employee_id=payload["employee_id"],
                alert_date=payload["alert_date"],
                rank=int(payload["rank"]),
                risk_score=float(payload["risk_score"]),
                grid_name=metadata.get("grid_name", "未映射"),
                role_name=metadata.get("role_name", "未映射"),
                basel_category=payload["basel_category"],
                data_sensitivity_jr_t_0197=payload[
                    "data_sensitivity_jr_t_0197"
                ],
                personal_info_jr_t_0171=payload["personal_info_jr_t_0171"],
                watchlist_flag=payload["employee_id"] in active_watchlist,
                reason_code=payload["reason_code"],
                subscores=payload["subscores"],
                evidence_card=payload["evidence_card"],
            )
        )
    append_audit(
        session,
        actor_role="system",
        target_entity=run.id,
        reason="模型推理完成并写入告警",
        action="run_persisted",
        action_details={
            "run_mode": run.run_mode,
            "alerts": len(result.alerts),
            "watchlist_matches": sum(
                payload["employee_id"] in active_watchlist
                for payload in result.alerts
            ),
        },
    )
    return run


def create_review(
    session: Session,
    *,
    alert_id: str,
    review_state: str,
    reviewer_role: str,
    recommended_action: str,
    review_notes: str,
    basel_category_corrected: str | None = None,
) -> ReviewLDC:
    if review_state not in VALID_REVIEW_STATES:
        raise ValueError(f"Invalid review state: {review_state}")
    review = ReviewLDC(
        alert_id=alert_id,
        review_state=review_state,
        basel_category_corrected=basel_category_corrected,
        recommended_action=recommended_action,
        reviewer_role=reviewer_role,
        review_notes=review_notes,
    )
    session.add(review)
    append_audit(
        session,
        actor_role=reviewer_role,
        target_entity=alert_id,
        reason=review_notes,
        action=f"review_{review_state}",
        action_details={
            "recommended_action": recommended_action,
            "basel_category_corrected": basel_category_corrected,
        },
    )
    return review


def set_watchlist(
    session: Session,
    *,
    employee_id: str,
    reason: str,
    created_by: str,
    active: bool = True,
    expires_at: datetime | None = None,
) -> WatchlistEntity:
    entity = session.scalar(
        select(WatchlistEntity).where(
            WatchlistEntity.employee_id == employee_id
        )
    )
    if entity is None:
        entity = WatchlistEntity(
            employee_id=employee_id,
            reason=reason,
            created_by=created_by,
            active=active,
            expires_at=expires_at,
        )
        session.add(entity)
    else:
        entity.reason = reason
        entity.active = active
        entity.expires_at = expires_at
    append_audit(
        session,
        actor_role=created_by,
        target_entity=employee_id,
        reason=reason,
        action="watchlist_changed",
        action_details={"active": active},
    )
    return entity
