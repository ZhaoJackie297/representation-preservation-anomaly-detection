from __future__ import annotations

import sys
from pathlib import Path

import pytest


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))


@pytest.fixture(scope="session")
def generated_bank_data(tmp_path_factory: pytest.TempPathFactory):
    from bank_sim_generator import generate_bank_sim

    output = tmp_path_factory.mktemp("bank-ops-data")
    manifest = generate_bank_sim(
        employees=50,
        days=180,
        seed=20261122,
        output_dir=output,
        force=True,
    )
    return output, manifest
