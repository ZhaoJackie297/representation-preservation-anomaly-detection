"""FastAPI service for the FinGuard-OR workbench."""

from __future__ import annotations

import json
import math
import os
import uuid
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

import pandas as pd
from fastapi import (
    Depends,
    FastAPI,
    File,
    Header,
    HTTPException,
    Query,
    UploadFile,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from db import (
    Alert,
    AuditTrail,
    ReviewLDC,
    Run,
    WatchlistEntity,
    append_audit,
    create_db_engine,
    create_review,
    create_session_factory,
    database_url_from_env,
    init_db,
    persist_run_result,
    session_scope,
    set_watchlist,
)
from model_runner import (
    DEFAULT_CHECKPOINT,
    FEATURE_NAMES,
    ModelRunner,
    ModelRunnerConfig,
)
from schemas import (
    AlertDetail,
    AlertItem,
    AlertPage,
    AuditItem,
    AuditPage,
    DrillRunRequest,
    HealthResponse,
    OverviewResponse,
    Pagination,
    ReviewRequest,
    ReviewResponse,
    RunCreated,
    RunMode,
    RunSummary,
    SmaCapitalEstimate,
    UnmaskResponse,
    WatchlistCreate,
    WatchlistItem,
)


PACKAGE_ROOT = Path(__file__).resolve().parent
DOMAIN_DICT_PATH = PACKAGE_ROOT / "bank_domain_dict.json"
STAFF_META_PATH = PACKAGE_ROOT / "data" / "bank_staff_meta.csv"
DEFAULT_DRILL_CSV = PACKAGE_ROOT / "data" / "bank_sim_unlabeled.csv"
UPLOAD_DIR = PACKAGE_ROOT / "data" / "uploads"
MAX_UPLOAD_BYTES = 64 * 1024 * 1024
PRODUCTION_COLUMNS = ["user_id", "date", *FEATURE_NAMES]
SYNTHETIC_BANNER = "合成演练数据（非真实生产记录）"
ROLES = {"first_line_reviewer", "second_line_risk", "third_line_audit"}
ROLE_ALLOWED = {
    "review": ROLES,
    "unmask": {"second_line_risk", "third_line_audit"},
    "watchlist": {"second_line_risk", "third_line_audit"},
}
REVIEW_TO_DB = {
    "confirmed_risk": "escalated_ldc",
    "false_positive": "dismissed_fp",
    "watchlist_observe": "watchlist_cooldown",
    "escalate_audit": "escalated_ldc",
}
SMA_PRESETS = {
    "medium_city": {
        "label": "中型城商行基准",
        "interest_income": 8_000_000_000.0,
        "services_income": 2_000_000_000.0,
        "financial_income": 1_000_000_000.0,
        "loss_component": 70_000_000.0,
        "assumed_risk_reduction_rate": 0.03,
    },
    "large_city": {
        "label": "大型城商行基准",
        "interest_income": 28_000_000_000.0,
        "services_income": 7_000_000_000.0,
        "financial_income": 4_000_000_000.0,
        "loss_component": 260_000_000.0,
        "assumed_risk_reduction_rate": 0.03,
    },
}


@dataclass(frozen=True)
class ApiSettings:
    database_url: str
    data_dir: Path
    frontend_dist: Path
    model_runner: ModelRunner | None = None


def _load_domain_dict() -> dict[str, Any]:
    return json.loads(DOMAIN_DICT_PATH.read_text(encoding="utf-8"))


def _load_staff_map() -> dict[str, dict[str, str]]:
    if not STAFF_META_PATH.is_file():
        return {}
    frame = pd.read_csv(STAFF_META_PATH)
    return {
        row.employee_id: {
            "employee_code": row.employee_code,
            "employee_name": row.employee_name,
            "role_name": row.role_name,
            "grid_name": row.grid_name,
        }
        for row in frame.itertuples(index=False)
    }


def _role_dependency(action: str):
    allowed = ROLE_ALLOWED[action]

    def dependency(
        x_role: str | None = Header(default=None, alias="X-Role"),
    ) -> str:
        if x_role not in ROLES:
            raise HTTPException(
                status_code=403,
                detail=f"Unknown or missing X-Role for {action}",
            )
        if x_role not in allowed:
            raise HTTPException(
                status_code=403,
                detail=f"Role {x_role} is not permitted to perform {action}",
            )
        return x_role

    return dependency


def _review_status(alert: Alert, reviews: list[ReviewLDC]) -> str:
    if not reviews:
        return "pending"
    action = reviews[-1].recommended_action
    for verdict in (
        "confirmed_risk",
        "false_positive",
        "watchlist_observe",
        "escalate_audit",
    ):
        if action.startswith(f"verdict={verdict}"):
            return verdict
    return "reviewed"


def _alert_item(
    alert: Alert,
    reviews: list[ReviewLDC],
    active_watchlist: set[str],
) -> AlertItem:
    return AlertItem(
        alert_id=alert.id,
        run_id=alert.run_id,
        employee_id_masked=alert.employee_id,
        alert_date=alert.alert_date,
        rank=alert.rank,
        risk_score=alert.risk_score,
        grid_name=alert.grid_name,
        role_name=alert.role_name,
        basel_category=alert.basel_category,
        data_sensitivity_jr_t_0197=alert.data_sensitivity_jr_t_0197,
        personal_info_jr_t_0171=alert.personal_info_jr_t_0171,
        watchlist_flag=alert.watchlist_flag or alert.employee_id in active_watchlist,
        reason_code=alert.reason_code,
        status=_review_status(alert, reviews),
    )


def _run_summary(run: Run) -> RunSummary:
    audit = run.cross_modal_audit or {}
    metrics = run.metrics or {}
    return RunSummary(
        run_id=run.id,
        run_mode=run.run_mode,
        model_version=run.model_version,
        status=run.status,
        started_at=run.started_at,
        completed_at=run.completed_at,
        abs_rho=(
            abs(float(audit["spearman_repr_norm_vs_input_norm"]))
            if "spearman_repr_norm_vs_input_norm" in audit
            else None
        ),
        route=audit.get("route"),
        selected_metric=audit.get("selected_metric"),
        top_k=int(metrics.get("top_k", 10)),
        cooldown_days=int(metrics.get("cooldown_days", 7)),
        alert_count=int(metrics.get("alert_count", 0)),
        synthetic_banner=SYNTHETIC_BANNER if run.run_mode == "simulated_drill" else None,
    )


def _validate_uploaded_csv(path: Path) -> None:
    try:
        header = pd.read_csv(path, nrows=0)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"CSV parse failed: {exc}") from exc
    columns = header.columns.tolist()
    if len(columns) != len(set(columns)):
        raise HTTPException(status_code=422, detail="CSV contains duplicate columns")
    if columns != PRODUCTION_COLUMNS:
        missing = [column for column in PRODUCTION_COLUMNS if column not in columns]
        extra = [column for column in columns if column not in PRODUCTION_COLUMNS]
        raise HTTPException(
            status_code=422,
            detail={
                "message": "CSV must use the exact 29-column production contract",
                "missing": missing,
                "extra": extra,
                "expected_columns": PRODUCTION_COLUMNS,
            },
        )


def _sma_estimate(preset: str, risk_reduction_rate: float | None) -> SmaCapitalEstimate:
    if preset not in SMA_PRESETS:
        raise HTTPException(status_code=422, detail=f"Unknown SMA preset: {preset}")
    values = SMA_PRESETS[preset]
    business_indicator = (
        float(values["interest_income"])
        + 0.5 * float(values["services_income"])
        + float(values["financial_income"])
    )
    bic = business_indicator * 0.12
    loss_ratio = float(values["loss_component"]) / max(bic, 1e-8)
    ilm = math.log(math.e - 1.0 + loss_ratio)
    baseline_capital = bic * ilm
    reduction = (
        float(values["assumed_risk_reduction_rate"])
        if risk_reduction_rate is None
        else min(max(float(risk_reduction_rate), 0.0), 0.20)
    )
    return SmaCapitalEstimate(
        preset=preset,
        business_indicator=business_indicator,
        business_indicator_component=bic,
        loss_component_ratio=loss_ratio,
        internal_loss_multiplier=ilm,
        baseline_operational_risk_capital=baseline_capital,
        assumed_risk_reduction_rate=reduction,
        estimated_capital_release=baseline_capital * reduction,
        note=(
            "SMA 资本节约为可调参数下的辅助测算，不构成监管资本申报或审计结论。"
        ),
    )


def create_app(
    *,
    database_url: str | None = None,
    model_runner: ModelRunner | None = None,
    frontend_dist: Path | None = None,
) -> FastAPI:
    settings = ApiSettings(
        database_url=database_url or database_url_from_env(),
        data_dir=PACKAGE_ROOT / "data",
        frontend_dist=frontend_dist or PACKAGE_ROOT / "frontend" / "dist",
        model_runner=model_runner,
    )
    engine = create_db_engine(settings.database_url)
    init_db(engine)
    factory = create_session_factory(engine)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.engine = engine
        app.state.session_factory = factory
        app.state.settings = settings
        app.state.domain_dict = _load_domain_dict()
        app.state.staff_map = _load_staff_map()
        app.state.model_runner = model_runner or ModelRunner(
            ModelRunnerConfig(device="cpu")
        )
        yield
        engine.dispose()

    app = FastAPI(
        title="智御内控 FinGuard-OR API",
        version="0.2.0",
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    def get_session() -> Iterator[Session]:
        with session_scope(factory) as session:
            yield session

    def runner() -> ModelRunner:
        return app.state.model_runner

    def _persist_result(
        session: Session,
        result: Any,
    ) -> Run:
        return persist_run_result(
            session,
            result,
            staff_meta=app.state.staff_map,
        )

    @app.get("/api/health", response_model=HealthResponse)
    def health(session: Session = Depends(get_session)) -> HealthResponse:
        latest = session.scalar(
            select(Run).order_by(Run.started_at.desc()).limit(1)
        )
        return HealthResponse(
            status="ok",
            database_connected=True,
            latest_run_id=latest.id if latest else None,
            model_frozen=DEFAULT_CHECKPOINT.is_file(),
            model_version="SoftInst-Rand-seed20261116-v1",
            environment_mode=os.environ.get("FINGUARD_ENV", "development"),
        )

    @app.get("/api/runs", response_model=list[RunSummary])
    def list_runs(session: Session = Depends(get_session)) -> list[RunSummary]:
        runs = session.scalars(
            select(Run).order_by(Run.started_at.desc())
        )
        return [_run_summary(run) for run in runs]

    @app.post("/api/runs/drill", response_model=RunCreated)
    def run_drill(
        request: DrillRunRequest,
        session: Session = Depends(get_session),
        runner_dep: ModelRunner = Depends(runner),
    ) -> RunCreated:
        input_path = (
            Path(request.input_path).resolve()
            if request.input_path
            else DEFAULT_DRILL_CSV
        )
        if input_path != DEFAULT_DRILL_CSV.resolve() and not input_path.is_relative_to(
            settings.data_dir.resolve()
        ):
            raise HTTPException(
                status_code=422,
                detail="input_path must stay inside the bank_ops_risk data directory",
            )
        if not input_path.is_file():
            raise HTTPException(status_code=404, detail=f"Drill CSV not found: {input_path}")
        result = runner_dep.fast_bank_refit(
            input_path,
            run_mode="simulated_drill",
        )
        run = _persist_result(session, result)
        return RunCreated(
            run_id=run.id,
            run_mode="simulated_drill",
            alert_count=len(result.alerts),
            cross_modal_audit=result.cross_modal_audit,
            synthetic_banner=SYNTHETIC_BANNER,
        )

    @app.post("/api/runs/upload", response_model=RunCreated)
    async def upload_csv(
        session: Session = Depends(get_session),
        runner_dep: ModelRunner = Depends(runner),
        file: UploadFile = File(...),
    ) -> RunCreated:
        if not file.filename or not file.filename.lower().endswith(".csv"):
            raise HTTPException(status_code=422, detail="Only CSV files are accepted")
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        target = UPLOAD_DIR / f"{uuid.uuid4().hex}.csv"
        size = 0
        try:
            with target.open("wb") as handle:
                while chunk := await file.read(1024 * 1024):
                    size += len(chunk)
                    if size > MAX_UPLOAD_BYTES:
                        raise HTTPException(
                            status_code=413,
                            detail="CSV exceeds 64 MiB upload limit",
                        )
                    handle.write(chunk)
            _validate_uploaded_csv(target)
            result = runner_dep.fast_bank_refit(
                target,
                run_mode="unlabeled_live",
            )
            run = _persist_result(session, result)
            return RunCreated(
                run_id=run.id,
                run_mode="unlabeled_live",
                alert_count=len(result.alerts),
                cross_modal_audit=result.cross_modal_audit,
            )
        finally:
            await file.close()
            if target.exists():
                target.unlink()

    def _run_or_404(session: Session, run_id: str) -> Run:
        run = session.get(Run, run_id)
        if run is None:
            raise HTTPException(status_code=404, detail="Run not found")
        return run

    @app.get("/api/runs/{run_id}/overview", response_model=OverviewResponse)
    def run_overview(
        run_id: str,
        session: Session = Depends(get_session),
        sma_preset: str = Query(default="medium_city"),
        risk_reduction_rate: float | None = Query(default=None, ge=0, le=0.20),
    ) -> OverviewResponse:
        run = _run_or_404(session, run_id)
        metrics = run.metrics or {}
        audit = run.cross_modal_audit or {}
        alert_count = int(metrics.get("alert_count", 0))
        top_k = int(metrics.get("top_k", 10))
        evaluation_active = int(metrics.get("evaluation_active_employee_days", 0))
        cooldown = int(metrics.get("cooldown_suppressed_candidates", 0))
        funnel = [
            {"stage": "评估期活跃员工日", "count": evaluation_active},
            {"stage": "每日候选", "count": max(evaluation_active, 0)},
            {"stage": "7日冷却拦截", "count": cooldown},
            {"stage": f"K={top_k}告警槽", "count": alert_count},
        ]
        return OverviewResponse(
            run=_run_summary(run),
            total_active_employee_days=int(metrics.get("active_employee_days", 0)),
            latest_active_employees=int(metrics.get("latest_active_employees", 0)),
            evaluation_active_employee_days=evaluation_active,
            evaluation_employee_count=int(metrics.get("evaluation_employee_count", 0)),
            daily_top_k=top_k,
            alert_count=alert_count,
            cooldown_suppressed_candidates=cooldown,
            funnel=funnel,
            router_curve=audit.get("training_window_curve", []),
            recommended_metric=audit.get("selected_metric", "pai_mean"),
            sma_capital_estimate=_sma_estimate(
                sma_preset,
                risk_reduction_rate,
            ),
            synthetic_banner=(
                SYNTHETIC_BANNER if run.run_mode == "simulated_drill" else None
            ),
        )

    @app.get("/api/alerts", response_model=AlertPage)
    def list_alerts(
        session: Session = Depends(get_session),
        run_id: str | None = None,
        date: str | None = None,
        department: str | None = None,
        role: str | None = None,
        status: str | None = None,
        min_score: float | None = None,
        page: int = Query(default=1, ge=1),
        page_size: int = Query(default=25, ge=1, le=200),
    ) -> AlertPage:
        statement = select(Alert)
        if run_id:
            statement = statement.where(Alert.run_id == run_id)
        if date:
            statement = statement.where(Alert.alert_date == date)
        if department:
            statement = statement.where(Alert.grid_name == department)
        if role:
            statement = statement.where(Alert.role_name == role)
        if min_score is not None:
            statement = statement.where(Alert.risk_score >= min_score)
        statement = statement.order_by(
            Alert.watchlist_flag.desc(),
            Alert.risk_score.desc(),
            Alert.alert_date.desc(),
        )
        all_alerts = list(session.scalars(statement))
        reviews: dict[str, list[ReviewLDC]] = {}
        if all_alerts:
            alert_ids = [alert.id for alert in all_alerts]
            review_rows = session.scalars(
                select(ReviewLDC)
                .where(ReviewLDC.alert_id.in_(alert_ids))
                .order_by(ReviewLDC.created_at.asc())
            )
            for review in review_rows:
                reviews.setdefault(review.alert_id, []).append(review)
        active_watchlist = set(
            session.scalars(
                select(WatchlistEntity.employee_id).where(
                    WatchlistEntity.active.is_(True)
                )
            )
        )
        filtered = []
        for alert in all_alerts:
            item = _alert_item(
                alert,
                reviews.get(alert.id, []),
                active_watchlist,
            )
            if status and item.status != status:
                continue
            filtered.append(item)
        filtered.sort(key=lambda item: (not item.watchlist_flag, -item.risk_score))
        total = len(filtered)
        start = (page - 1) * page_size
        items = filtered[start : start + page_size]
        return AlertPage(
            items=items,
            pagination=Pagination(
                page=page,
                page_size=page_size,
                total=total,
                pages=math.ceil(total / page_size) if total else 0,
            ),
        )

    @app.get("/api/alerts/{alert_id}", response_model=AlertDetail)
    def alert_detail(
        alert_id: str,
        session: Session = Depends(get_session),
    ) -> AlertDetail:
        alert = session.get(Alert, alert_id)
        if alert is None:
            raise HTTPException(status_code=404, detail="Alert not found")
        run = session.get(Run, alert.run_id)
        if run is None:
            raise HTTPException(status_code=404, detail="Run not found")
        reviews = list(
            session.scalars(
                select(ReviewLDC)
                .where(ReviewLDC.alert_id == alert.id)
                .order_by(ReviewLDC.created_at.asc())
            )
        )
        active_watchlist = set(
            session.scalars(
                select(WatchlistEntity.employee_id).where(
                    WatchlistEntity.active.is_(True)
                )
            )
        )
        evidence = alert.evidence_card
        peer = evidence.get("peer_channel_means", {})
        self_median = evidence.get("self_hist_channel_medians", {})
        labels = {
            group["id"]: group["name_zh"]
            for group in app.state.domain_dict["feature_groups"]
        }
        group_to_id = {
            "login": "core_teller_logon",
            "usb": "restricted_usb",
            "export": "customer_credit_export",
            "mail": "mail_channels",
            "web": "web_cloud_channels",
        }
        behavior = [
            {
                "feature": key,
                "label_zh": labels.get(group_to_id.get(key, ""), key),
                "value": float(self_median.get(key, 0.0)),
                "peer_mean": float(peer.get(key, 0.0)),
                "self_median": float(self_median.get(key, 0.0)),
            }
            for key in sorted(
                peer.keys(),
                key=lambda key: abs(
                    float(self_median.get(key, 0.0))
                    - float(peer.get(key, 0.0))
                ),
                reverse=True,
            )
        ]
        alert_date = pd.Timestamp(alert.alert_date)
        timeline_rows = session.execute(
            select(Alert)
            .where(
                Alert.employee_id == alert.employee_id,
                Alert.alert_date >= (alert_date - pd.Timedelta(days=30)).strftime("%Y-%m-%d"),
                Alert.alert_date <= alert.alert_date,
            )
            .order_by(Alert.alert_date.asc())
        ).scalars()
        return AlertDetail(
            alert=_alert_item(alert, reviews, active_watchlist),
            evidence_card=evidence,
            behavior_dimensions=[
                {
                    **item,
                }
                for item in behavior
            ],
            radial_angular={
                "route": run.cross_modal_audit.get("route"),
                "radial_energy_share": run.cross_modal_audit.get(
                    "radial_energy_share"
                ),
                "spearman_norm_vs_input": run.cross_modal_audit.get(
                    "spearman_repr_norm_vs_input_norm"
                ),
                "norm_cv": run.cross_modal_audit.get("norm_cv"),
            },
            soft_peer_baseline={
                "profile_dimensions": 47,
                "peer_ids": evidence.get("peer_ids", []),
                "peer_channel_means": peer,
                "self_hist_channel_medians": self_median,
            },
            timeline_30d=[
                {
                    "alert_id": row.id,
                    "date": row.alert_date,
                    "risk_score": row.risk_score,
                    "rank": row.rank,
                }
                for row in timeline_rows
            ],
            regulatory_mapping={
                "basel_category": alert.basel_category,
                "data_sensitivity_jr_t_0197": alert.data_sensitivity_jr_t_0197,
                "personal_info_jr_t_0171": alert.personal_info_jr_t_0171,
                "compliance_registry": app.state.domain_dict["compliance_registry"],
            },
            ldc_history=[
                {
                    "review_id": review.id,
                    "state": review.review_state,
                    "reviewer_role": review.reviewer_role,
                    "recommended_action": review.recommended_action,
                    "notes": review.review_notes,
                    "created_at": review.created_at,
                }
                for review in reviews
            ],
            synthetic_banner=(
                SYNTHETIC_BANNER if run.run_mode == "simulated_drill" else None
            ),
        )

    @app.post(
        "/api/alerts/{alert_id}/review",
        response_model=ReviewResponse,
    )
    def review_alert(
        alert_id: str,
        request: ReviewRequest,
        session: Session = Depends(get_session),
        actor_role: str = Depends(_role_dependency("review")),
    ) -> ReviewResponse:
        alert = session.get(Alert, alert_id)
        if alert is None:
            raise HTTPException(status_code=404, detail="Alert not found")
        db_state = REVIEW_TO_DB[request.verdict]
        watchlist_added = False
        if request.verdict == "watchlist_observe" and actor_role in ROLE_ALLOWED[
            "watchlist"
        ]:
            set_watchlist(
                session,
                employee_id=alert.employee_id,
                reason=request.disposition,
                created_by=actor_role,
            )
            watchlist_added = True
        review = create_review(
            session,
            alert_id=alert.id,
            review_state=db_state,
            reviewer_role=actor_role,
            recommended_action=(
                f"verdict={request.verdict}; {request.disposition}"
            ),
            review_notes=request.reviewer_note,
            basel_category_corrected=request.corrected_basel_category,
        )
        session.flush()
        return ReviewResponse(
            review_id=review.id,
            alert_id=alert.id,
            verdict=request.verdict,
            database_state=db_state,
            watchlist_added=watchlist_added,
            audit_written=True,
        )

    @app.post(
        "/api/alerts/{alert_id}/unmask",
        response_model=UnmaskResponse,
    )
    def unmask_alert(
        alert_id: str,
        session: Session = Depends(get_session),
        actor_role: str = Depends(_role_dependency("unmask")),
    ) -> UnmaskResponse:
        alert = session.get(Alert, alert_id)
        if alert is None:
            raise HTTPException(status_code=404, detail="Alert not found")
        staff = app.state.staff_map.get(alert.employee_id)
        if staff is None:
            raise HTTPException(status_code=404, detail="Staff metadata not found")
        append_audit(
            session,
            actor_role=actor_role,
            target_entity=alert.employee_id,
            reason="合规解敏查看",
            action="unmask_employee_identity",
            action_details={
                "alert_id": alert.id,
                "run_id": alert.run_id,
            },
        )
        return UnmaskResponse(
            employee_id=alert.employee_id,
            employee_code=staff["employee_code"],
            employee_name=staff["employee_name"],
            role_name=staff["role_name"],
            grid_name=staff["grid_name"],
            audit_written=True,
        )

    @app.get("/api/watchlist", response_model=list[WatchlistItem])
    def list_watchlist(
        session: Session = Depends(get_session),
    ) -> list[WatchlistItem]:
        entities = session.scalars(
            select(WatchlistEntity).order_by(
                WatchlistEntity.active.desc(),
                WatchlistEntity.created_at.desc(),
            )
        )
        return [
            WatchlistItem(
                id=entity.id,
                employee_id=entity.employee_id,
                reason=entity.reason,
                active=entity.active,
                created_by=entity.created_by,
                created_at=entity.created_at,
                expires_at=entity.expires_at,
            )
            for entity in entities
        ]

    @app.post(
        "/api/watchlist",
        response_model=WatchlistItem,
    )
    def create_watchlist(
        request: WatchlistCreate,
        session: Session = Depends(get_session),
        actor_role: str = Depends(_role_dependency("watchlist")),
    ) -> WatchlistItem:
        entity = set_watchlist(
            session,
            employee_id=request.employee_id,
            reason=request.reason,
            created_by=actor_role,
            active=request.active,
            expires_at=request.expires_at,
        )
        session.flush()
        return WatchlistItem(
            id=entity.id,
            employee_id=entity.employee_id,
            reason=entity.reason,
            active=entity.active,
            created_by=entity.created_by,
            created_at=entity.created_at,
            expires_at=entity.expires_at,
        )

    @app.get("/api/audit", response_model=AuditPage)
    def audit_log(
        session: Session = Depends(get_session),
        actor_role: str = Depends(_role_dependency("review")),
        page: int = Query(default=1, ge=1),
        page_size: int = Query(default=50, ge=1, le=200),
    ) -> AuditPage:
        del actor_role
        total = int(
            session.scalar(select(func.count()).select_from(AuditTrail)) or 0
        )
        entries = session.scalars(
            select(AuditTrail)
            .order_by(AuditTrail.timestamp.desc())
            .offset((page - 1) * page_size)
            .limit(page_size)
        )
        return AuditPage(
            items=[
                AuditItem(
                    id=entry.id,
                    actor_role=entry.actor_role,
                    timestamp=entry.timestamp,
                    target_entity=entry.target_entity,
                    reason=entry.reason,
                    action=entry.action,
                    action_details=entry.action_details,
                )
                for entry in entries
            ],
            pagination=Pagination(
                page=page,
                page_size=page_size,
                total=total,
                pages=math.ceil(total / page_size) if total else 0,
            ),
        )

    @app.get("/api/domain-dict")
    def domain_dict() -> dict[str, Any]:
        return app.state.domain_dict

    if settings.frontend_dist.is_dir() and (settings.frontend_dist / "index.html").is_file():
        app.mount(
            "/",
            StaticFiles(directory=settings.frontend_dist, html=True),
            name="frontend",
        )
    return app


app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("api:app", host="127.0.0.1", port=8000, reload=False)
