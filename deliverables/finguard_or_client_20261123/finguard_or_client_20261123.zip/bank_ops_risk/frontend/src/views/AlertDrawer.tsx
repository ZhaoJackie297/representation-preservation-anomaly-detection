import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Eye,
  LockKeyhole,
  ShieldCheck,
  X
} from "lucide-react";
import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";
import { api } from "../api";
import { formatScore, roleLabel } from "../format";
import type {
  AlertDetail,
  RunSummary,
  Role,
  UnmaskResult
} from "../types";
import { ErrorBlock, LoadingBlock } from "../components/Shared";

const verdicts = [
  ["confirmed_risk", "确认风险"],
  ["false_positive", "误报归档"],
  ["watchlist_observe", "关注观察"],
  ["escalate_audit", "移交内审"]
] as const;

const channelOrder = ["web", "export", "mail", "login", "usb"] as const;

interface EvidenceCardShape {
  z_cos?: number;
  z_euc?: number;
  z_magG?: number;
  z_T2?: number;
  manifold_velocity?: number;
  manifold_curvature?: number;
  raw_first_logon_min?: number;
  raw_last_logoff_min?: number;
  raw_active_span_min?: number;
  raw_usb_connect_count?: number;
}

export function AlertDrawer({
  alertId,
  role,
  queueRank,
  run,
  onClose,
  onChanged
}: {
  alertId: string;
  role: Role;
  queueRank: number;
  run: RunSummary | null;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [detail, setDetail] = useState<AlertDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [verdict, setVerdict] = useState("confirmed_risk");
  const [disposition, setDisposition] = useState("");
  const [note, setNote] = useState("");
  const [unmasked, setUnmasked] = useState<UnmaskResult | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const load = () => {
    setError(null);
    api
      .alert(alertId)
      .then(setDetail)
      .catch((reason: Error) => setError(reason.message));
  };

  useEffect(() => {
    setDetail(null);
    setUnmasked(null);
    setVerdict("confirmed_risk");
    setDisposition("");
    setNote("");
    load();
  }, [alertId]);

  const evidence = (detail?.evidence_card ??
    {}) as EvidenceCardShape;
  const scoreBasis = useMemo(
    () => [
      {
        key: "z_euc",
        label: "欧氏库偏离度",
        value: numberValue(evidence.z_euc),
        color: "#B91C1C"
      },
      {
        key: "z_cos",
        label: "方向漂移余弦",
        value: numberValue(evidence.z_cos),
        color: "#0F4C81"
      },
      {
        key: "z_T2",
        label: "霍特林统计量",
        value: numberValue(evidence.z_T2),
        color: "#1D4ED8"
      },
      {
        key: "z_magG",
        label: "梯度幅值惩罚",
        value: numberValue(evidence.z_magG),
        color: "#64748B"
      }
    ],
    [evidence.z_cos, evidence.z_T2, evidence.z_euc, evidence.z_magG]
  );
  const maxBasis = Math.max(
    1,
    ...scoreBasis.map((item) => Math.abs(item.value ?? 0))
  );
  const channelRows = useMemo(
    () =>
      channelOrder.map((channel) => {
        const behavior = detail?.behavior_dimensions.find(
          (item) => item.feature === channel
        );
        const self =
          detail?.soft_peer_baseline.self_hist_channel_medians[channel] ??
          behavior?.self_median ??
          null;
        const peer =
          detail?.soft_peer_baseline.peer_channel_means[channel] ??
          behavior?.peer_mean ??
          null;
        return {
          channel,
          label: channelLabel(channel),
          self,
          peer,
          delta: self != null && peer != null ? self - peer : null
        };
      }),
    [detail]
  );

  const submitReview = async () => {
    if (!disposition.trim()) {
      setError("请填写处置说明");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      await api.review(alertId, role, {
        verdict,
        disposition,
        reviewer_note: note
      });
      setDisposition("");
      setNote("");
      load();
      onChanged();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "处置提交失败");
    } finally {
      setSubmitting(false);
    }
  };

  const unmask = async () => {
    setError(null);
    try {
      const result = await api.unmask(alertId, role);
      setUnmasked(result);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "解敏失败");
    }
  };

  if (!detail && !error) {
    return (
      <section className="terminal-panel alert-evidence-pane">
        <header className="terminal-panel-head">
          <div>
            <span className="panel-rule" />
            <div>
              <h2>单条行为证据卡</h2>
              <small>正在读取同批次证据</small>
            </div>
          </div>
        </header>
        <LoadingBlock label="正在组装多视图流形证据卡" />
      </section>
    );
  }

  return (
    <section className="terminal-panel alert-evidence-pane">
      <header className="evidence-identity-header">
        <div className="evidence-nameplate">
          <div className="evidence-mark">AE</div>
          <div>
            <span>单条行为证据卡 · 同批次关联</span>
            <h2>{detail?.alert.employee_id_masked ?? "证据读取中"}</h2>
            <p>
              {detail
                ? `${detail.alert.grid_name} · ${detail.alert.role_name} · 队列第 ${queueRank} 位 · 全周期 #${detail.alert.rank}`
                : "正在读取身份与合规边界"}
            </p>
          </div>
        </div>
        <div className="evidence-score-block">
          <span>综合风险分</span>
          <strong className="mono">
            {detail ? formatScore(detail.alert.risk_score) : "—"}
          </strong>
          <small>{scoringLabel(run?.selected_metric)} · 人工复核</small>
        </div>
        <button
          className="evidence-close"
          onClick={onClose}
          aria-label="关闭证据卡"
        >
          <X size={16} />
        </button>
      </header>

      {error ? <ErrorBlock message={error} /> : null}
      {detail ? (
        <>
          <div className="evidence-scroll">
            {detail.synthetic_banner ? (
              <div className="drawer-synthetic">
                <AlertTriangle size={15} />
                {detail.synthetic_banner}
              </div>
            ) : null}

            <div className="evidence-identity-grid">
              <IdentityCell label="用户代号" value={detail.alert.employee_id_masked} mono />
              <IdentityCell
                label="队列排名"
                value={`#${queueRank}（全周期 #${detail.alert.rank}）`}
                mono
              />
              <IdentityCell
                label="风险结论"
                value={riskLevel(detail.alert.risk_score)}
                tone="risk"
              />
              <IdentityCell
                label="归属条线"
                value={`${detail.alert.grid_name} · ${detail.alert.role_name}`}
              />
              <IdentityCell
                label="Basel 分类"
                value={detail.alert.basel_category}
              />
              <IdentityCell
                label="合规分级"
                value={`JR/T 0197 ${detail.alert.data_sensitivity_jr_t_0197} / ${detail.alert.personal_info_jr_t_0171}`}
                mono
              />
            </div>

            <section className="evidence-module trend-module">
              <ModuleHeader
                title="近 30 日风险与队列轨迹"
                note={`${detail.timeline_30d.length} 个历史抽检点 · 同批连续关联`}
              />
              <div className="evidence-chart">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart
                    data={detail.timeline_30d}
                    margin={{ top: 12, right: 8, bottom: 0, left: -16 }}
                  >
                    <defs>
                      <linearGradient
                        id="riskArea"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop offset="0%" stopColor="#B91C1C" stopOpacity={0.18} />
                        <stop offset="100%" stopColor="#B91C1C" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid
                      stroke="#E7EBF0"
                      strokeDasharray="2 4"
                      vertical={false}
                    />
                    <XAxis
                      dataKey="date"
                      tickFormatter={(value: string) => value.slice(5)}
                      tick={{ fontSize: 10, fill: "#64748B" }}
                      axisLine={{ stroke: "#CBD5E1" }}
                      tickLine={false}
                    />
                    <YAxis
                      yAxisId="score"
                      tick={{ fontSize: 10, fill: "#64748B" }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis
                      yAxisId="rank"
                      orientation="right"
                      tick={{ fontSize: 9, fill: "#94A3B8" }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        border: "1px solid #CBD5E1",
                        borderRadius: 2,
                        boxShadow: "none",
                        fontSize: 11
                      }}
                    />
                    <ReferenceLine
                      yAxisId="score"
                      y={0}
                      stroke="#CBD5E1"
                    />
                    <Area
                      yAxisId="score"
                      type="monotone"
                      dataKey="risk_score"
                      name="风险分"
                      isAnimationActive={false}
                      stroke="#B91C1C"
                      strokeWidth={2}
                      fill="url(#riskArea)"
                      dot={{ r: 3, fill: "#B91C1C", strokeWidth: 0 }}
                      activeDot={{ r: 5 }}
                    />
                    <Line
                      yAxisId="rank"
                      type="monotone"
                      dataKey="rank"
                      name="全周期排名"
                      isAnimationActive={false}
                      stroke="#0F4C81"
                      strokeWidth={1.2}
                      strokeDasharray="4 3"
                      dot={false}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
              <div className="chart-legend">
                <span>
                  <i className="legend-risk" />
                  风险分
                </span>
                <span>
                  <i className="legend-rank" />
                  全周期排名
                </span>
                <small>排名线越向下表示队列位置越靠前</small>
              </div>
            </section>

            <div className="evidence-two-column">
              <section className="evidence-module peer-module">
                <ModuleHeader
                  title="47 维 Soft-Peer 同岗位参照"
                  note={`Top-${detail.soft_peer_baseline.peer_ids.length} 画像近邻`}
                />
                <div className="compact-table-wrap">
                  <table className="evidence-table">
                    <thead>
                      <tr>
                        <th>监测行为通道</th>
                        <th className="right">本人中位</th>
                        <th className="right">同群均值</th>
                        <th className="right">画像偏离</th>
                      </tr>
                    </thead>
                    <tbody>
                      {channelRows.map((row, index) => (
                        <tr
                          key={row.channel}
                          className={
                            index ===
                            maxDeltaIndex(channelRows.map((item) => item.delta))
                              ? "channel-highlight"
                              : ""
                          }
                        >
                          <td>{row.label}</td>
                          <td className="right mono">
                            {formatMetric(row.self)}
                          </td>
                          <td className="right mono">
                            {formatMetric(row.peer)}
                          </td>
                          <td
                            className={`right mono ${
                              Math.abs(row.delta ?? 0) > 0.25
                                ? "metric-risk"
                                : ""
                            }`}
                          >
                            {formatSigned(row.delta)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="peer-footnote">
                  <strong>同群可解释邻居：</strong>
                  <span className="mono">
                    {detail.soft_peer_baseline.peer_ids.slice(0, 4).join("、")}
                  </span>
                  <small>非训练输入，仅用于当前告警解释。</small>
                </div>
              </section>

              <section className="evidence-module basis-module">
                <ModuleHeader
                  title={`主要评分依据 · ${scoringLabel(run?.selected_metric)}`}
                  note={`曲率 ${formatSigned(
                    numberValue(evidence.manifold_curvature)
                  )}`}
                />
                <div className="basis-list">
                  {scoreBasis.map((item) => (
                    <div className="basis-row" key={item.key}>
                      <span>{item.label}</span>
                      <div className="basis-track">
                        <i
                          style={{
                            width: `${Math.min(
                              100,
                              (Math.abs(item.value ?? 0) / maxBasis) * 100
                            )}%`,
                            background: item.color
                          }}
                        />
                      </div>
                      <strong className="mono">
                        {formatSigned(item.value)}
                      </strong>
                    </div>
                  ))}
                </div>
                <div className="manifold-meta">
                  <span>
                    流形速度
                    <b className="mono">
                      {formatMetric(numberValue(evidence.manifold_velocity), 4)}
                    </b>
                  </span>
                  <span>
                    径向能量
                    <b className="mono">
                      {(detail.radial_angular.radial_energy_share * 100).toFixed(
                        1
                      )}
                      %
                    </b>
                  </span>
                  <span>
                    路由
                    <b className="mono">
                      {detail.radial_angular.route} · |ρ|
                      {Math.abs(
                        detail.radial_angular.spearman_norm_vs_input
                      ).toFixed(3)}
                    </b>
                  </span>
                </div>
                <div className="rule-callout">
                  <strong>主触发规则：</strong>
                  <span className="mono">{detail.alert.reason_code}</span>
                  <small>{channelFinding(channelRows)}</small>
                </div>
              </section>
            </div>

            <div className="evidence-two-column lower-grid">
              <section className="evidence-module raw-module">
                <ModuleHeader title="原始观测与时序契约" note="0 为午夜有效值 · -1 为缺失" />
                <div className="raw-observation-grid">
                  <Observation
                    label="首次登录"
                    value={formatClock(evidence.raw_first_logon_min)}
                  />
                  <Observation
                    label="末次签退"
                    value={formatClock(evidence.raw_last_logoff_min)}
                  />
                  <Observation
                    label="活跃跨度"
                    value={formatMinutes(evidence.raw_active_span_min)}
                  />
                  <Observation
                    label="USB 接入"
                    value={`${formatMetric(
                      numberValue(evidence.raw_usb_connect_count)
                    )} 次`}
                  />
                </div>
                <p className="contract-note">
                  时间字段在进入模型前仅将负值映射为 NaN；午夜 0
                  保留为合法时刻。当前页面不读取任何生产真值标签。
                </p>
              </section>

              <section className="evidence-module compliance-module">
                <ModuleHeader title="监管映射与处置边界" note="三道防线 X-Role" />
                <div className="regulatory-grid">
                  <RegulatoryTag
                    code="JR/T 0197-2020"
                    value={`数据安全 ${detail.alert.data_sensitivity_jr_t_0197}`}
                  />
                  <RegulatoryTag
                    code="JR/T 0171-2020"
                    value={`个人金融信息 ${detail.alert.personal_info_jr_t_0171}`}
                  />
                  <RegulatoryTag code="Basel 操作风险" value={detail.alert.basel_category} />
                  <RegulatoryTag
                    code="金监总局令 2023 年第 5 号"
                    value="操作风险治理与内部控制"
                  />
                </div>
                <div className="history-section">
                  <span className="subsection-title">历史 LDC 处置</span>
                  {detail.ldc_history.length ? (
                    <div className="history-list compact-history">
                      {detail.ldc_history.slice(0, 2).map((item, index) => (
                        <article key={index}>
                          <AlertTriangle size={13} />
                          <div>
                            <strong>
                              {String(item.state)} ·{" "}
                              {String(item.reviewer_role)}
                            </strong>
                            <p>{String(item.recommended_action)}</p>
                          </div>
                        </article>
                      ))}
                    </div>
                  ) : (
                    <p className="muted">尚无历史处置记录。</p>
                  )}
                </div>
              </section>
            </div>

            <section className="evidence-module disposition-module">
              <ModuleHeader
                title="闭环处置"
                note={`当前角色：${roleLabel(role)}`}
              />
              <div className="role-caption">
                <Eye size={14} />
                {role === "first_line_reviewer"
                  ? "一道防线可提交复核结论，不可解敏或管理 Watchlist。"
                  : "解敏与 Watchlist 变更将自动写入不可篡改审计台账。"}
              </div>
              <div className="verdict-grid">
                {verdicts.map(([value, label]) => (
                  <button
                    key={value}
                    className={`verdict-button ${
                      verdict === value ? "active" : ""
                    }`}
                    onClick={() => setVerdict(value)}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <div className="disposition-fields">
                <label>
                  处置说明
                  <textarea
                    rows={2}
                    value={disposition}
                    onChange={(event) => setDisposition(event.target.value)}
                    placeholder="填写核查依据、建议管控动作或升级原因"
                  />
                </label>
                <label>
                  复核备注
                  <textarea
                    rows={2}
                    value={note}
                    onChange={(event) => setNote(event.target.value)}
                    placeholder="可选：补充证据位置、访谈结果或交接说明"
                  />
                </label>
              </div>
              {unmasked ? (
                <dl className="inline-identity unmasked-inline">
                  <div>
                    <dt>姓名</dt>
                    <dd>{unmasked.employee_name}</dd>
                  </div>
                  <div>
                    <dt>工号</dt>
                    <dd>{unmasked.employee_code}</dd>
                  </div>
                  <div>
                    <dt>审计留痕</dt>
                    <dd>{unmasked.audit_written ? "已写入" : "未写入"}</dd>
                  </div>
                </dl>
              ) : null}
            </section>
          </div>

          <footer className="evidence-action-bar">
            <div>
              <strong>建议核查动作：</strong>
              <span>{recommendedAction(detail.alert.reason_code)}</span>
            </div>
            <div className="evidence-actions">
              <button
                className="button secondary"
                onClick={unmask}
                disabled={role === "first_line_reviewer"}
                title={
                  role === "first_line_reviewer"
                    ? "一道防线无解敏权限"
                    : "解敏操作将写入审计"
                }
              >
                <LockKeyhole size={14} />
                {role === "first_line_reviewer" ? "无解敏权限" : "申请解敏"}
              </button>
              <button
                className="button primary gradient-primary"
                onClick={submitReview}
                disabled={submitting}
              >
                <CheckCircle2 size={14} />
                {submitting ? "提交中" : "进入复核并提交"}
              </button>
            </div>
          </footer>
        </>
      ) : null}
    </section>
  );
}

function IdentityCell({
  label,
  value,
  tone = "default",
  mono = false
}: {
  label: string;
  value: string;
  tone?: "default" | "risk";
  mono?: boolean;
}) {
  return (
    <div className={`identity-cell identity-${tone}`}>
      <span>{label}</span>
      <strong className={mono ? "mono" : ""}>{value}</strong>
    </div>
  );
}

function ModuleHeader({ title, note }: { title: string; note: string }) {
  return (
    <header className="evidence-module-head">
      <h3>{title}</h3>
      <span>{note}</span>
    </header>
  );
}

function Observation({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <span>{label}</span>
      <strong className="mono">{value}</strong>
    </div>
  );
}

function RegulatoryTag({ code, value }: { code: string; value: string }) {
  return (
    <div>
      <span>{code}</span>
      <strong>{value}</strong>
    </div>
  );
}

function numberValue(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function formatMetric(value: number | null, digits = 3): string {
  return value == null || !Number.isFinite(value)
    ? "缺失"
    : value.toFixed(digits);
}

function formatSigned(value: number | null): string {
  if (value == null || !Number.isFinite(value)) return "—";
  return `${value >= 0 ? "+" : ""}${value.toFixed(3)}`;
}

function formatClock(value: unknown): string {
  const minute = numberValue(value);
  if (minute == null || minute < 0) return "缺失";
  const normalized = Math.round(minute) % 1440;
  return `${String(Math.floor(normalized / 60)).padStart(2, "0")}:${String(
    normalized % 60
  ).padStart(2, "0")}`;
}

function formatMinutes(value: unknown): string {
  const minute = numberValue(value);
  return minute == null || minute < 0 ? "缺失" : `${minute.toFixed(0)} 分钟`;
}

function channelLabel(channel: string): string {
  return (
    {
      login: "核心系统登录",
      usb: "涉密 USB 外设",
      export: "客群 / 征信导出",
      mail: "内外网邮件",
      web: "网页 / 网盘访问"
    } as Record<string, string>
  )[channel] ?? channel;
}

function scoringLabel(metric: string | null | undefined): string {
  return (
    {
      pai_mean: "PAI-Mean",
      bank_cosine: "余弦库",
      bank_euclidean: "欧氏库",
      mask_original: "Mask-L1"
    } as Record<string, string>
  )[metric ?? ""] ?? "PAI-Mean";
}

function riskLevel(score: number): string {
  if (score >= 20) return "高风险 · 人工复核";
  if (score >= 10) return "中风险 · 重点复核";
  return "关注级 · 常规复核";
}

function maxDeltaIndex(values: Array<number | null>): number {
  let result = 0;
  let maximum = -1;
  values.forEach((value, index) => {
    if (Math.abs(value ?? 0) > maximum) {
      maximum = Math.abs(value ?? 0);
      result = index;
    }
  });
  return result;
}

function channelFinding(
  rows: Array<{ label: string; delta: number | null }>
): string {
  const largest = [...rows].sort(
    (left, right) =>
      Math.abs(right.delta ?? 0) - Math.abs(left.delta ?? 0)
  )[0];
  return largest
    ? `${largest.label}相对同群画像偏离 ${formatSigned(largest.delta)}。`
    : "当前证据卡未提供可比同群画像。";
}

function recommendedAction(reasonCode: string): string {
  return (
    {
      web_external_channel_drift:
        "安排强制休假并复核外部网页 / 网盘访问权限与传输对象。",
      export_sensitive_data_movement:
        "暂停批量导出权限，核查敏感文件去向与接收对象。",
      after_hours_credit_query:
        "复核非营业时段征信查询授权、客户管户关系与终端来源。",
      account_borrowing:
        "核验账号借用与代客操作证据，必要时冻结会话并约谈。"
    } as Record<string, string>
  )[reasonCode] ?? "核验异常行为、授权边界与数据流向后提交闭环结论。";
}
