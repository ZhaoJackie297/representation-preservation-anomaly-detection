"""Generate deterministic, privacy-safe bank operation-risk drill data."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd


PACKAGE_ROOT = Path(__file__).resolve().parent
DEFAULT_OUTPUT_DIR = PACKAGE_ROOT / "data"
DOMAIN_DICT_PATH = PACKAGE_ROOT / "bank_domain_dict.json"

FEATURE_NAMES = [
    "has_any_event",
    "logon_count",
    "logoff_count",
    "first_logon_minute",
    "last_logoff_minute",
    "active_span_minutes",
    "after_hours_logon_count",
    "other_pc_logon_count",
    "usb_connect_count",
    "usb_disconnect_count",
    "file_copy_count",
    "archive_copy_count",
    "executable_copy_count",
    "unique_file_extensions",
    "email_count",
    "email_recipient_count",
    "external_recipient_count",
    "email_attachment_count",
    "email_size_bytes",
    "after_hours_email_count",
    "http_count",
    "after_hours_http_count",
    "external_http_count",
    "unique_http_domains",
    "is_weekend",
    "weekday_sin",
    "weekday_cos",
]
FEATURE_INDEX = {name: index for index, name in enumerate(FEATURE_NAMES)}
TIMING_INDICES = [
    FEATURE_INDEX["first_logon_minute"],
    FEATURE_INDEX["last_logoff_minute"],
    FEATURE_INDEX["active_span_minutes"],
]
COUNT_INDICES = [
    FEATURE_INDEX[name]
    for name in FEATURE_NAMES[1:3] + FEATURE_NAMES[6:24]
]
ROLE_IDS = [
    "teller",
    "relationship_manager",
    "credit_approver",
    "technology_ops",
]
ROLE_NAMES = {
    "teller": "柜面运营",
    "relationship_manager": "客户经理",
    "credit_approver": "信贷审批",
    "technology_ops": "科技运维",
}
GRID_NAMES = {"hq": "总行", "branch": "分行", "outlet": "网点"}
SURNAMES = list("赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦许何吕施张孔曹魏陶姜谢苏潘葛范彭")
GIVEN_NAMES = [
    "安",
    "宁",
    "晨",
    "嘉",
    "远",
    "清",
    "诚",
    "思",
    "然",
    "文",
    "博",
    "恒",
    "明",
    "若",
    "知",
    "和",
]


@dataclass(frozen=True)
class ScenarioSpec:
    scenario_id: str
    name_zh: str
    basel_category: str
    level_4: str
    personal_info_class: str
    default_action: str


SCENARIOS = {
    "departure_exfiltration": ScenarioSpec(
        "departure_exfiltration",
        "离职窗口窃密",
        "内部欺诈——盗窃与欺诈",
        "L4-L5",
        "C2-C3",
        "冻结高风险导出并转纪律审查/LDC",
    ),
    "after_hours_credit_query": ScenarioSpec(
        "after_hours_credit_query",
        "非营业时段越权查询征信",
        "内部欺诈——未经授权活动",
        "L4",
        "C3",
        "暂停异常终端权限并核查客户授权",
    ),
    "account_borrowing": ScenarioSpec(
        "account_borrowing",
        "账号借用与异常代客切换",
        "内部欺诈——未经授权活动",
        "L3-L4",
        "C2-C3",
        "强制重新认证并核查岗位职责分离",
    ),
    "stealth_permission_probe": ScenarioSpec(
        "stealth_permission_probe",
        "长期不休假隐蔽权限探测",
        "执行、交割和流程管理",
        "L4-L5",
        "C2-C3",
        "安排强制休假并执行权限最小化复核",
    ),
}


def _role_parameters(role: str, grid: str) -> dict[str, float]:
    table = {
        "teller": {
            "login_mean": 8.2,
            "first_mean": 485,
            "first_std": 18,
            "span_mean": 500,
            "files": 0.35,
            "archive": 0.05,
            "mail": 0.25,
            "external_mail": 0.01,
            "http": 1.1,
            "external_http": 0.02,
            "usb": 0.015,
        },
        "relationship_manager": {
            "login_mean": 7.1,
            "first_mean": 505,
            "first_std": 45,
            "span_mean": 525,
            "files": 0.9,
            "archive": 0.16,
            "mail": 1.5,
            "external_mail": 0.08,
            "http": 2.8,
            "external_http": 0.08,
            "usb": 0.025,
        },
        "credit_approver": {
            "login_mean": 6.1,
            "first_mean": 495,
            "first_std": 30,
            "span_mean": 540,
            "files": 1.15,
            "archive": 0.28,
            "mail": 0.75,
            "external_mail": 0.015,
            "http": 1.9,
            "external_http": 0.03,
            "usb": 0.01,
        },
        "technology_ops": {
            "login_mean": 5.5,
            "first_mean": 470,
            "first_std": 70,
            "span_mean": 620,
            "files": 0.5,
            "archive": 0.09,
            "mail": 0.45,
            "external_mail": 0.01,
            "http": 3.1,
            "external_http": 0.06,
            "usb": 0.09,
        },
    }
    output = dict(table[role])
    if grid == "hq":
        output["external_mail"] *= 0.75
        output["files"] *= 0.85
    elif grid == "outlet":
        output["mail"] *= 0.9
        output["http"] *= 0.85
    return output


def _staff_meta(employees: int, rng: np.random.Generator) -> pd.DataFrame:
    roles = np.asarray(ROLE_IDS, dtype=object)
    role_probability = np.asarray([0.39, 0.29, 0.17, 0.15])
    grids = np.asarray(["hq", "branch", "outlet"], dtype=object)
    grid_probability = np.asarray([0.18, 0.36, 0.46])
    rows = []
    for index in range(employees):
        sid = f"AnonEmp-{index + 1:04d}"
        name = SURNAMES[index % len(SURNAMES)] + GIVEN_NAMES[(index * 7) % len(GIVEN_NAMES)]
        role = str(rng.choice(roles, p=role_probability))
        grid = str(rng.choice(grids, p=grid_probability))
        rows.append(
            {
                "employee_id": sid,
                "employee_code": f"SIM{202600000 + index + 1}",
                "employee_name": name,
                "role_id": role,
                "role_name": ROLE_NAMES[role],
                "grid_id": grid,
                "grid_name": GRID_NAMES[grid],
                "watchlist_default": bool(rng.random() < 0.025),
            }
        )
    return pd.DataFrame(rows)


def _normal_counts(
    meta: pd.DataFrame,
    dates: pd.DatetimeIndex,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    employees = len(meta)
    days = len(dates)
    values = np.zeros((employees, days, len(FEATURE_NAMES)), dtype=np.float32)
    values[:, :, TIMING_INDICES] = -1.0
    active = np.zeros((employees, days), dtype=bool)
    employee_activity = rng.uniform(0.72, 1.08, size=employees)
    employee_speed = rng.uniform(0.85, 1.18, size=employees)

    for user, record in enumerate(meta.itertuples(index=False)):
        params = _role_parameters(record.role_id, record.grid_id)
        for time, date in enumerate(dates):
            weekend = date.weekday() >= 5
            active_probability = (0.16 if weekend else 0.96) * employee_activity[user]
            if record.role_id == "technology_ops" and weekend:
                active_probability += 0.18
            if rng.random() > min(active_probability, 0.995):
                continue

            weekly_modulation = 0.90 + 0.20 * np.sin(2 * np.pi * (time % 7) / 7.0)
            login = rng.poisson(max(params["login_mean"] * weekly_modulation, 0.3))
            if login == 0 and rng.random() < 0.35:
                login = 1
            values[user, time, FEATURE_INDEX["logon_count"]] = login
            values[user, time, FEATURE_INDEX["logoff_count"]] = max(
                login - rng.integers(0, 2),
                0,
            )
            values[user, time, FEATURE_INDEX["other_pc_logon_count"]] = (
                rng.binomial(max(login, 1), 0.025)
            )

            file_probability = min(
                max(params["files"] * weekly_modulation, 0.01),
                0.98,
            )
            values[user, time, FEATURE_INDEX["file_copy_count"]] = rng.poisson(
                file_probability
            )
            values[user, time, FEATURE_INDEX["archive_copy_count"]] = rng.poisson(
                params["archive"]
            )
            values[user, time, FEATURE_INDEX["executable_copy_count"]] = (
                rng.binomial(1, 0.004)
            )
            values[user, time, FEATURE_INDEX["unique_file_extensions"]] = min(
                int(
                    values[user, time, FEATURE_INDEX["file_copy_count"]]
                    + values[user, time, FEATURE_INDEX["archive_copy_count"]]
                ),
                rng.integers(0, 4),
            )

            mail = rng.poisson(params["mail"])
            values[user, time, FEATURE_INDEX["email_count"]] = mail
            values[user, time, FEATURE_INDEX["email_recipient_count"]] = rng.poisson(
                max(mail * 0.8, 0.1)
            )
            values[user, time, FEATURE_INDEX["external_recipient_count"]] = (
                rng.binomial(
                    max(int(values[user, time, FEATURE_INDEX["email_recipient_count"]]), 1),
                    min(params["external_mail"], 0.4),
                )
            )
            values[user, time, FEATURE_INDEX["email_attachment_count"]] = rng.poisson(
                max(mail * 0.25, 0.05)
            )
            values[user, time, FEATURE_INDEX["email_size_bytes"]] = (
                rng.integers(8_000, 350_000)
                * max(int(values[user, time, FEATURE_INDEX["email_attachment_count"]]), 1)
                if mail
                else 0
            )

            http = rng.poisson(params["http"] * weekly_modulation)
            values[user, time, FEATURE_INDEX["http_count"]] = http
            values[user, time, FEATURE_INDEX["external_http_count"]] = rng.binomial(
                max(http, 1),
                min(params["external_http"], 0.5),
            )
            values[user, time, FEATURE_INDEX["unique_http_domains"]] = rng.binomial(
                max(http, 1),
                0.16,
            )

            usb_events = rng.poisson(params["usb"])
            values[user, time, FEATURE_INDEX["usb_connect_count"]] = usb_events
            values[user, time, FEATURE_INDEX["usb_disconnect_count"]] = usb_events

            first = int(
                np.clip(
                    rng.normal(params["first_mean"], params["first_std"]),
                    0,
                    1380,
                )
            )
            span = int(
                np.clip(
                    rng.normal(params["span_mean"], 55) * employee_speed[user],
                    60,
                    1200,
                )
            )
            last = min(first + span, 1439)
            values[user, time, FEATURE_INDEX["first_logon_minute"]] = first
            values[user, time, FEATURE_INDEX["last_logoff_minute"]] = last
            values[user, time, FEATURE_INDEX["active_span_minutes"]] = max(
                last - first,
                0,
            )
            values[user, time, FEATURE_INDEX["after_hours_email_count"]] = (
                rng.binomial(max(mail, 1), 0.025)
            )
            values[user, time, FEATURE_INDEX["after_hours_logon_count"]] = (
                rng.binomial(max(login, 1), 0.012)
            )
            values[user, time, FEATURE_INDEX["after_hours_http_count"]] = (
                rng.binomial(max(http, 1), 0.018)
            )
            values[user, time, FEATURE_INDEX["has_any_event"]] = 1
            values[user, time, FEATURE_INDEX["is_weekend"]] = int(weekend)
            values[user, time, FEATURE_INDEX["weekday_sin"]] = np.sin(
                2 * np.pi * date.weekday() / 7.0
            )
            values[user, time, FEATURE_INDEX["weekday_cos"]] = np.cos(
                2 * np.pi * date.weekday() / 7.0
            )
            active[user, time] = True
    return values, active


def _plant_scenario(
    values: np.ndarray,
    active: np.ndarray,
    labels: np.ndarray,
    event_id: np.ndarray,
    meta: pd.DataFrame,
    dates: pd.DatetimeIndex,
    target_indices: np.ndarray,
    scenario: ScenarioSpec,
    rng: np.random.Generator,
    incident_offset: int,
) -> list[dict]:
    events = []
    for local_event, user in enumerate(target_indices):
        role = meta.iloc[user]["role_id"]
        if scenario.scenario_id == "departure_exfiltration":
            start = int(rng.integers(94, 162))
            duration = int(rng.integers(4, 8))
        elif scenario.scenario_id == "after_hours_credit_query":
            start = int(rng.integers(96, 170))
            duration = int(rng.integers(1, 4))
        elif scenario.scenario_id == "account_borrowing":
            start = int(rng.integers(98, 160))
            duration = int(rng.integers(5, 11))
        else:
            start = int(rng.integers(110, 145))
            duration = int(rng.integers(22, 36))
        end = min(start + duration - 1, len(dates) - 1)
        incident_id = incident_offset + local_event

        for step, time in enumerate(range(start, end + 1)):
            # Violation days are active even if the employee was originally off.
            active[user, time] = True
            values[user, time, FEATURE_INDEX["has_any_event"]] = 1
            values[user, time, FEATURE_INDEX["is_weekend"]] = int(
                dates[time].weekday() >= 5
            )
            values[user, time, FEATURE_INDEX["weekday_sin"]] = np.sin(
                2 * np.pi * dates[time].weekday() / 7.0
            )
            values[user, time, FEATURE_INDEX["weekday_cos"]] = np.cos(
                2 * np.pi * dates[time].weekday() / 7.0
            )
            labels[user, time] = 1
            event_id[user, time] = incident_id

            if scenario.scenario_id == "departure_exfiltration":
                values[user, time, FEATURE_INDEX["file_copy_count"]] = rng.integers(
                    35, 95
                )
                values[user, time, FEATURE_INDEX["archive_copy_count"]] = rng.integers(
                    12, 38
                )
                values[user, time, FEATURE_INDEX["unique_file_extensions"]] = rng.integers(
                    4, 9
                )
                values[user, time, FEATURE_INDEX["usb_connect_count"]] = rng.integers(
                    1, 4
                )
                values[user, time, FEATURE_INDEX["usb_disconnect_count"]] = values[
                    user, time, FEATURE_INDEX["usb_connect_count"]
                ]
                values[user, time, FEATURE_INDEX["external_recipient_count"]] += (
                    rng.integers(3, 8)
                )
                values[user, time, FEATURE_INDEX["email_attachment_count"]] += (
                    rng.integers(2, 7)
                )
                values[user, time, FEATURE_INDEX["email_size_bytes"]] += rng.integers(
                    8_000_000, 42_000_000
                )
                values[user, time, FEATURE_INDEX["external_http_count"]] += (
                    rng.integers(2, 8)
                )
                values[user, time, FEATURE_INDEX["first_logon_minute"]] = rng.integers(
                    250, 430
                )
                values[user, time, FEATURE_INDEX["last_logoff_minute"]] = min(
                    int(values[user, time, FEATURE_INDEX["first_logon_minute"]])
                    + rng.integers(560, 920),
                    1439,
                )
                values[user, time, FEATURE_INDEX["active_span_minutes"]] = (
                    values[user, time, FEATURE_INDEX["last_logoff_minute"]]
                    - values[user, time, FEATURE_INDEX["first_logon_minute"]]
                )
            elif scenario.scenario_id == "after_hours_credit_query":
                values[user, time, FEATURE_INDEX["first_logon_minute"]] = (
                    0 if local_event == 0 and step == 0 else rng.integers(0, 241)
                )
                values[user, time, FEATURE_INDEX["last_logoff_minute"]] = min(
                    int(values[user, time, FEATURE_INDEX["first_logon_minute"]])
                    + rng.integers(90, 280),
                    1439,
                )
                values[user, time, FEATURE_INDEX["active_span_minutes"]] = (
                    values[user, time, FEATURE_INDEX["last_logoff_minute"]]
                    - values[user, time, FEATURE_INDEX["first_logon_minute"]]
                )
                values[user, time, FEATURE_INDEX["after_hours_logon_count"]] += (
                    rng.integers(4, 12)
                )
                values[user, time, FEATURE_INDEX["other_pc_logon_count"]] += (
                    rng.integers(3, 9)
                )
                values[user, time, FEATURE_INDEX["file_copy_count"]] += rng.integers(
                    8, 25
                )
                values[user, time, FEATURE_INDEX["archive_copy_count"]] += (
                    rng.integers(4, 15)
                )
                values[user, time, FEATURE_INDEX["after_hours_http_count"]] += (
                    rng.integers(3, 10)
                )
                values[user, time, FEATURE_INDEX["external_http_count"]] += (
                    rng.integers(1, 5)
                )
            elif scenario.scenario_id == "account_borrowing":
                donor_role = rng.choice([value for value in ROLE_IDS if value != role])
                donor = _role_parameters(str(donor_role), str(meta.iloc[user]["grid_id"]))
                values[user, time, FEATURE_INDEX["logon_count"]] = rng.poisson(
                    donor["login_mean"] * 1.3
                )
                values[user, time, FEATURE_INDEX["other_pc_logon_count"]] += (
                    rng.integers(2, 7)
                )
                values[user, time, FEATURE_INDEX["email_count"]] = rng.poisson(
                    donor["mail"] * 1.8
                )
                values[user, time, FEATURE_INDEX["http_count"]] = rng.poisson(
                    donor["http"] * 1.6
                )
                values[user, time, FEATURE_INDEX["first_logon_minute"]] = int(
                    np.clip(rng.normal(donor["first_mean"] - 55, donor["first_std"]), 0, 1430)
                )
                values[user, time, FEATURE_INDEX["active_span_minutes"]] = int(
                    np.clip(rng.normal(donor["span_mean"] + 55, 45), 90, 1200)
                )
                values[user, time, FEATURE_INDEX["last_logoff_minute"]] = min(
                    int(values[user, time, FEATURE_INDEX["first_logon_minute"]])
                    + int(values[user, time, FEATURE_INDEX["active_span_minutes"]]),
                    1439,
                )
                values[user, time, FEATURE_INDEX["active_span_minutes"]] = (
                    values[user, time, FEATURE_INDEX["last_logoff_minute"]]
                    - values[user, time, FEATURE_INDEX["first_logon_minute"]]
                )
            else:
                growth = 1.0 + step / max(duration, 1)
                values[user, time, FEATURE_INDEX["logon_count"]] += rng.integers(1, 5)
                values[user, time, FEATURE_INDEX["file_copy_count"]] = int(
                    rng.integers(4, 14) * growth
                )
                values[user, time, FEATURE_INDEX["archive_copy_count"]] = int(
                    rng.integers(2, 9) * growth
                )
                values[user, time, FEATURE_INDEX["executable_copy_count"]] += (
                    rng.integers(0, 3)
                )
                values[user, time, FEATURE_INDEX["external_http_count"]] = int(
                    rng.integers(2, 10) * growth
                )
                values[user, time, FEATURE_INDEX["unique_http_domains"]] += (
                    rng.integers(1, 4)
                )
                values[user, time, FEATURE_INDEX["first_logon_minute"]] = rng.integers(
                    330, 470
                )
                values[user, time, FEATURE_INDEX["last_logoff_minute"]] = min(
                    int(values[user, time, FEATURE_INDEX["first_logon_minute"]])
                    + rng.integers(660, 980),
                    1439,
                )
                values[user, time, FEATURE_INDEX["active_span_minutes"]] = (
                    values[user, time, FEATURE_INDEX["last_logoff_minute"]]
                    - values[user, time, FEATURE_INDEX["first_logon_minute"]]
                )

        events.append(
            {
                "incident_id": f"SIM-{incident_id:03d}",
                "scenario_id": scenario.scenario_id,
                "scenario_name": scenario.name_zh,
                "employee_id": meta.iloc[user]["employee_id"],
                "role_name": meta.iloc[user]["role_name"],
                "grid_name": meta.iloc[user]["grid_name"],
                "start_index": start,
                "end_index": end,
                "start_date": dates[start].strftime("%Y-%m-%d"),
                "end_date": dates[end].strftime("%Y-%m-%d"),
                "basel_category": scenario.basel_category,
                "data_sensitivity_jr_t_0197": scenario.level_4,
                "personal_info_jr_t_0171": scenario.personal_info_class,
                "recommended_action": scenario.default_action,
            }
        )
    return events


def generate_bank_sim(
    employees: int = 500,
    days: int = 180,
    seed: int = 20261122,
    output_dir: Path = DEFAULT_OUTPUT_DIR,
    force: bool = False,
) -> dict:
    if employees < 50:
        raise ValueError("employees must be at least 50")
    if days != 180:
        raise ValueError("work package 1 requires exactly 180 days")
    output_dir.mkdir(parents=True, exist_ok=True)
    npz_path = output_dir / "bank_sim_drill.npz"
    parquet_path = output_dir / "bank_sim_drill.parquet"
    unlabeled_path = output_dir / "bank_sim_unlabeled.csv"
    meta_path = output_dir / "bank_staff_meta.csv"
    events_path = output_dir / "bank_sim_drill_events.csv"
    manifest_path = output_dir / "bank_sim_manifest.json"
    if not force and all(
        path.exists()
        for path in (
            npz_path,
            parquet_path,
            unlabeled_path,
            meta_path,
            events_path,
            manifest_path,
        )
    ):
        return json.loads(manifest_path.read_text(encoding="utf-8"))

    rng = np.random.default_rng(seed)
    dates = pd.date_range("2025-01-06", periods=days, freq="D")
    meta = _staff_meta(employees, rng)
    values, active = _normal_counts(meta, dates, rng)
    labels = np.zeros((employees, days), dtype=np.uint8)
    event_id = np.full((employees, days), -1, dtype=np.int16)
    pool = rng.permutation(employees)
    allocations = {
        "departure_exfiltration": 18,
        "after_hours_credit_query": 20,
        "account_borrowing": 16,
        "stealth_permission_probe": 12,
    }
    events = []
    cursor = 0
    incident_offset = 1
    for scenario_id, count in allocations.items():
        targets = np.sort(pool[cursor : cursor + count])
        cursor += count
        scenario_events = _plant_scenario(
            values,
            active,
            labels,
            event_id,
            meta,
            dates,
            targets,
            SCENARIOS[scenario_id],
            rng,
            incident_offset,
        )
        events.extend(scenario_events)
        incident_offset += count

    # Preserve the timing missing contract exactly in the drill files.
    values[:, :, TIMING_INDICES] = np.where(
        active[:, :, None] & (values[:, :, TIMING_INDICES] >= 0),
        values[:, :, TIMING_INDICES],
        -1.0,
    )
    for time in range(days):
        values[:, time, FEATURE_INDEX["has_any_event"]] = active[
            :, time
        ].astype(np.float32)
        values[:, time, FEATURE_INDEX["is_weekend"]] = float(
            dates[time].weekday() >= 5
        )
        values[:, time, FEATURE_INDEX["weekday_sin"]] = np.sin(
            2 * np.pi * dates[time].weekday() / 7.0
        )
        values[:, time, FEATURE_INDEX["weekday_cos"]] = np.cos(
            2 * np.pi * dates[time].weekday() / 7.0
        )

    users = meta["employee_id"].to_numpy(dtype=str)
    date_strings = np.asarray(dates.strftime("%Y-%m-%d"), dtype=str)
    np.savez_compressed(
        npz_path,
        users=users,
        dates=date_strings,
        values=values,
        active_mask=active,
        labels=labels,
        event_id=event_id,
        features=np.asarray(FEATURE_NAMES, dtype=str),
        train_end_index=np.asarray(89),
        eval_start_index=np.asarray(90),
        seed=np.asarray(seed),
    )

    rows = {"user_id": np.repeat(users, days), "date": np.tile(date_strings, employees)}
    for index, name in enumerate(FEATURE_NAMES):
        rows[name] = values[:, :, index].reshape(-1)
    unlabeled = pd.DataFrame(rows)
    unlabeled.to_csv(unlabeled_path, index=False, encoding="utf-8")

    drill = unlabeled.copy()
    drill["active"] = active.reshape(-1).astype(np.uint8)
    drill["labels"] = labels.reshape(-1).astype(np.uint8)
    drill["event_id"] = event_id.reshape(-1)
    drill.to_parquet(parquet_path, index=False)
    meta.to_csv(meta_path, index=False, encoding="utf-8")
    events_frame = pd.DataFrame(events)
    events_frame.to_csv(events_path, index=False, encoding="utf-8")
    manifest = {
        "schema_version": "1.0.0",
        "seed": seed,
        "employees": employees,
        "days": days,
        "train_days": 90,
        "evaluation_days": 90,
        "feature_dimensions": len(FEATURE_NAMES),
        "active_cells": int(active.sum()),
        "event_cells": int(labels.sum()),
        "events": int(len(events)),
        "scenario_counts": {
            scenario_id: int(
                events_frame["scenario_id"].eq(scenario_id).sum()
            )
            for scenario_id in allocations
        },
        "missing_timing_cells": int(
            (values[:, :, TIMING_INDICES] < 0).sum()
        ),
        "midnight_zero_cells": int(
            (
                values[
                    :,
                    :,
                    [
                        FEATURE_INDEX["first_logon_minute"],
                        FEATURE_INDEX["last_logoff_minute"],
                    ],
                ]
                == 0
            ).sum()
        ),
        "outputs": {
            "drill_npz": str(npz_path),
            "drill_parquet": str(parquet_path),
            "unlabeled_csv": str(unlabeled_path),
            "staff_meta_csv": str(meta_path),
            "events_csv": str(events_path),
        },
        "claim_boundary": (
            "Synthetic drill data only. It is not real bank data and must not "
            "be represented as production records."
        ),
    }
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate FinGuard-OR bank operation-risk simulation data"
    )
    parser.add_argument("--employees", type=int, default=500)
    parser.add_argument("--days", type=int, default=180)
    parser.add_argument("--seed", type=int, default=20261122)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    manifest = generate_bank_sim(
        employees=args.employees,
        days=args.days,
        seed=args.seed,
        output_dir=args.output_dir,
        force=args.force,
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
