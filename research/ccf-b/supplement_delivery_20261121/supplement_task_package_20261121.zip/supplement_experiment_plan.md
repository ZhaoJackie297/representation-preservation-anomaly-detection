# 论文大修最小可执行补实验方案与脚本清单

> **定位**：用**最小 GPU/CPU 开销**直接补齐审稿意见中全部 6 项实验与统计缺口，避免盲目扩跑无效实验；全部脚本均按你当前仓库 `ZhaoJackie297/representation-preservation-anomaly-detection` 的真实模块与数据接口编写，复制到 `<repo_root>/research/ccf-b/supplement/` 即可运行。

---

## 一、实验优先级总览与预期耗时

| 序号 | 优先级 | 对应审稿意见 | 实验内容 | 硬件与预估耗时 | 脚本文件 |
| :---: | :---: | :--- | :--- | :--- | :--- |
| **S3** | **P0（先跑，5 分钟出结果）** | 问题 2、3、6 | ① CERT r4.2 200 种子随机排序基线<br>② 纯 `magG` / 纯 `T2` 无编码器基线（r4.2 & r5.2）<br>③ 已有分数的事件级（24/99）与用户簇 Bootstrap 95% CI<br>④ 表示范数与输入幅值相关性 + 式 (7) 径向/角度能量分解 | **纯 CPU**，~5 分钟（零重训） | `exp_s3_cpu_diagnostics_bootstrap_norm.py` |
| **S1** | **P0（核心定音实验）** | 问题 1、3 | **补齐 $2\times 2$ 缺失第 4 格**：10 种子（`20261116–20261125`）`SoftInst + Random`（标准 10 轮与匹配步数两档），同一编码器同步评测 `plain_l1 / bank_cosine / bank_euclidean / pai_a1 / pai_official`（CERT r4.2 & r5.2） | 单卡 GPU，r4.2 ~10–15 min，r5.2 ~20–30 min | `exp_s1_soft_random_4th_cell.py` |
| **S2** | **P0（因果闭环实验）** | 问题 1 | **纯 $A_3$ 覆盖率剂量-响应 + 独立空图对照**（CERT r4.2，5 种子，**锁定统一训练步数 700 步**）：`dose_rand (~15%) → dose_A3_50 → dose_A3_80 → dose_A3_90` + 独立 `ctrl_A5a_only` + 独立 `ctrl_A5b_only`（彻底剥离旧版把 `A5a/A5b` 混入同一批表的污染）；先跑 `--objective soft`，必要时补 `--objective hard` | 单卡 GPU，~15–20 min（每目标 30 模型） | `exp_s2_coverage_dose_and_null_graphs.py` |
| **S4** | **P1（强烈建议，冲一级学报/CCF-B）** | 问题 4、6 | ① 补两个正常日级深度基线：`MLP-AE-27D` 与 `LSTM-Pred-27D`（替代失败的 Anomaly Transformer，r4.2 & r5.2，3 种子）<br>② 软权重上限 $\alpha \in \{0.25, 0.50, 0.75\}$ 超参敏感性扫描（r4.2，3 种子） | 单卡 GPU，~10–15 min | `exp_s4_daily_ae_and_hyperparams.py` |

> **建议执行顺序**：**S3（5 分钟热身验证环境与已有模型）→ S1（先跑 r4.2，10 分钟看清第 4 格真相）→ S2（纯 $A_3$ 剂量响应）→ S1（r5.2）→ S4（基线与 $\alpha$ 敏感性）**。

---

## 二、S1 + S2 结果如何决定最终论文主线（关键决策树）

在动手大改论文之前，S1 和 S2 会给出一个毫无争议的实证分岔口，无论结果朝哪一边，论文都可以写得非常扎实：

```mermaid
flowchart TD
    A["跑完 S1 (Soft+Random 10-seed) 与 S2 (纯 A3 剂量响应 & 独立 A5a/A5b)"] --> B{"纯 A3 高覆盖是否显著优于<br>Soft+Random 且优于 A5a/A5b?"}
    B -- "是 (分支 1)" --> C["完整坐实 2×2 符号反转与覆盖采样增益:<br>指出旧版 A1-Cov 略弱于 T3 是因混入 A5a/A5b 噪边;<br>用纯 A3 覆盖替代旧 A1-Cov 作为主方法"]
    B -- "否 / 持平 (分支 2)" --> D["重构核心贡献为更诚实稳固的机制发现:<br>1) 软实例对比主增益源自隐式范数正则与连续重心校准(随机批已可拿满);<br>2) 高邻域共现下硬对比退化 9/10 而软对比保持稳健(批-目标非对称交互);<br>3) 打分端三层拆解: 记忆库替代残差 + 欧氏消除连续流盲区 + 幅值权衡"]
```

---

## 三、部署方式与逐条运行命令

将以下 4 个脚本复制到你本地仓库的 `research/ccf-b/supplement/` 目录中，在仓库根目录 `<repo_root>` 下激活你跑实验的 Python 环境执行：

- [exp_s1_soft_random_4th_cell.py](./exp_s1_soft_random_4th_cell.py)
- [exp_s2_coverage_dose_and_null_graphs.py](./exp_s2_coverage_dose_and_null_graphs.py)
- [exp_s3_cpu_diagnostics_bootstrap_norm.py](./exp_s3_cpu_diagnostics_bootstrap_norm.py)
- [exp_s4_daily_ae_and_hyperparams.py](./exp_s4_daily_ae_and_hyperparams.py)

> 所有脚本均内置**断点续跑**（已跑完的种子自动 `[SKIP]`，加 `--force` 才覆盖重跑），所有结果统一输出到 `research/ccf-b/supplement_results/`，不修改你原有任何 `results/canonical/` 文件。

### 第 1 步：S3（纯 CPU，~5 分钟，零重训）

```powershell
# 1.1 CERT r4.2 200 种子随机排序器基线（K=5/10/20，7天冷却，3日容差）
python research/ccf-b/supplement/exp_s3_cpu_diagnostics_bootstrap_norm.py random-r42

# 1.2 无编码器独立幅值基线（纯 magG、纯 T2、magG+T2）
python research/ccf-b/supplement/exp_s3_cpu_diagnostics_bootstrap_norm.py amp-standalone --dataset r4.2
python research/ccf-b/supplement/exp_s3_cpu_diagnostics_bootstrap_norm.py amp-standalone --dataset r5.2

# 1.3 表示范数 vs. 输入幅值相关性 + 式 (7) 径向/角度能量分解
#     请把下面两个 .pth 路径替换为你本地已有 T0 与 T3/T4/A1-Cov 的模型权重路径（同 seed 20261116 即可，也可传多个）
python research/ccf-b/supplement/exp_s3_cpu_diagnostics_bootstrap_norm.py norm-corr `
  --dataset r4.2 `
  --checkpoints T0=runtime/cert/experiments/representation_preservation/e2/runs/r42_T0_seed20261116/model.pth `
                T3=runtime/cert/experiments/representation_preservation/e2_instance/missing_safe_v2_20261117/T3_instance_soft/seed_20261116/model.pth `
                T4=runtime/cert/experiments/representation_preservation/e2_instance/missing_safe_v2_20261117/T4_full_soft/seed_20261116/model.pth

# 1.4 已有 10 种子分数的事件级 Bootstrap (24/99 事件) + 用户簇 Bootstrap (PR/ROC)
#     请将 <external-root> 替换为你存放 pilot_r42_10seed_scores_v1 与 r52_10seed_scores_v1 的目录，
#     并确认 .npz 内部键名（例如 pai_a1 / plain_l1，若不同改 --key-a / --key-b 即可）
python research/ccf-b/supplement/exp_s3_cpu_diagnostics_bootstrap_norm.py bootstrap `
  --dataset r4.2 `
  --dir-a "<external-root>\pilot_r42_10seed_scores_v1\A1-Cov" --key-a pai_a1 `
  --dir-b "<external-root>\pilot_r42_10seed_scores_v1\A0-official" --key-b plain_l1 `
  --tag r42_A1CovPAI_vs_OfficialPlain
```

*(提示：如果原 `pilot_r42_10seed_scores_v1` 里的 `.npz` 文件名或键名结构略有差异，跑 1.4 前用 `python -c "import numpy as np; z=np.load('<某文件>.npz'); print(list(z.keys()))"` 看一眼键名填给 `--key-a/--key-b`；同时 S1 跑完后会自动产出标准格式的 `scores.npz`，也能直接喂给 `bootstrap`！)*

### 第 2 步：S1（P0 核心：10 种子 `Soft + Random` 缺失第 4 格）

```powershell
# 2.1 CERT r4.2（同时跑标准 10 轮 620 步与匹配 A1-Cov 步数 ~1145 步，且同步评估 5 种打分器）
python research/ccf-b/supplement/exp_s1_soft_random_4th_cell.py --dataset r4.2 --step-mode both

# （可选，如果你怀疑 620 步 vs 1145 步本身也影响了硬对比，可加 --also-hard-random-matched 顺手排查步数混杂）

# 2.2 CERT r5.2（标准 10 轮 1250 步 + 匹配步数；r5.2 若有具体平均批数可传 --r52-matched-steps）
python research/ccf-b/supplement/exp_s1_soft_random_4th_cell.py --dataset r5.2 --step-mode both
```

### 第 3 步：S2（P0 因果闭环：纯 $A_3$ 剂量-响应 + 独立 `A5a/A5b` 对照）

```powershell
# 3.1 软实例目标下：统一锁定 700 步，测试 Random(~15%) -> A3-50% -> A3-80% -> A3-90% 以及独立 A5a-80% / A5b-80%
python research/ccf-b/supplement/exp_s2_coverage_dose_and_null_graphs.py --objective soft --total-steps 700

# 3.2 硬对比目标下跑完全相同的 6 组条件（直接画出硬/软随 A3 覆盖率单调分叉的双曲线！）
python research/ccf-b/supplement/exp_s2_coverage_dose_and_null_graphs.py --objective hard --total-steps 700
```

> **注意**：如果运行 3.1 时 `dose_A3_90` 提示所需批数略超过 `700`（脚本会自动报错并告诉你精确所需批数），按提示把 `--total-steps` 调大到例如 `800` 或 `900` 再跑即可，确保 6 组步数严格完全一致。

### 第 4 步：S4（P1 加分项：正常日级深度基线 + $\alpha$ 敏感性）

```powershell
# 4.1 补 Daily MLP-AE 与 Causal LSTM-Pred 基线（r4.2 & r5.2，3 种子）
python research/ccf-b/supplement/exp_s4_daily_ae_and_hyperparams.py ae-baseline --dataset r4.2
python research/ccf-b/supplement/exp_s4_daily_ae_and_hyperparams.py ae-baseline --dataset r5.2

# 4.2 软权重上限 alpha ∈ {0.25, 0.50, 0.75} 敏感性扫描（r4.2，3 种子）
python research/ccf-b/supplement/exp_s4_daily_ae_and_hyperparams.py alpha-sweep
```

---

## 四、跑完后只需把哪些汇总文件发回给我

不用传大体积模型权重和 `.npz`，你跑完后只要把 `research/ccf-b/supplement_results/` 下生成的轻量 `.csv` / `.json` 汇总文本直接发给我（或推到仓库告诉我一声）：

1. `exp_s3_diagnostics/random_r42/r4.2_random_baseline_summary.csv`
2. `exp_s3_diagnostics/amp_standalone_r4.2/amp_standalone_summary.csv` 与 `amp_standalone_r5.2/amp_standalone_summary.csv`
3. `exp_s3_diagnostics/norm_corr_r4.2/norm_amplitude_radial_audit.csv`
4. `exp_s3_diagnostics/bootstrap_*/..._bootstrap.json`
5. `exp_s1_r4.2/method_summary.csv`（及 `metrics_by_seed.csv`）与 `exp_s1_r5.2/method_summary.csv`
6. `exp_s2_soft_r42/dose_response_summary.csv` 与 `exp_s2_hard_r42/dose_response_summary.csv`
7. `exp_s4_baselines_hp/ae_r4.2/ae_baselines_summary.csv`、`ae_r5.2/ae_baselines_summary.csv`、`alpha_sweep_r42/alpha_sweep_summary.csv`

拿到这批真实结果后，我会一次性完成：
- 按 S1/S2 实证落点重构主线与全套公式证明（修正式 (5) 符号、补全命题 1 非退化条件、降格命题 2 后半与命题 4 并改用正确的 $N_{\text{day}}, L_e$ 推导）；
- 用 `amplitude_only`、`norm-corr`、10 种子四格表重塑打分端与训练端叙事；
- 重绘全部 5 幅期刊图（同步更新数据与参照基线）；
- 修复 `build_paper_docx.ps1` 的大小写缓存与叠式分数 Bug，重新输出终版 `.md` / `.docx` / `.pdf`。
