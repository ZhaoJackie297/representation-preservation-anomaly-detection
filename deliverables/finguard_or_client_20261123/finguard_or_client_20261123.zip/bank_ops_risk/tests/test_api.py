from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from api import create_app


@pytest.fixture(scope="session")
def api_client(tmp_path_factory: pytest.TempPathFactory):
    database = tmp_path_factory.mktemp("api-db") / "api.sqlite"
    app = create_app(database_url=f"sqlite:///{database.as_posix()}")
    with TestClient(app) as client:
        yield client


@pytest.fixture(scope="session")
def drill_run(api_client: TestClient) -> dict:
    response = api_client.post(
        "/api/runs/drill",
        json={"force_refresh": True},
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["run_mode"] == "simulated_drill"
    assert payload["synthetic_banner"] == "合成演练数据（非真实生产记录）"
    return payload


@pytest.fixture(scope="session")
def first_alert(api_client: TestClient, drill_run: dict) -> dict:
    response = api_client.get(
        "/api/alerts",
        params={"run_id": drill_run["run_id"], "page": 1, "page_size": 5},
    )
    assert response.status_code == 200, response.text
    items = response.json()["items"]
    assert items
    return items[0]


def test_health_and_runs(api_client: TestClient, drill_run: dict) -> None:
    health = api_client.get("/api/health")
    assert health.status_code == 200
    assert health.json()["database_connected"] is True
    assert health.json()["latest_run_id"] == drill_run["run_id"]
    assert health.json()["model_frozen"] is True
    runs = api_client.get("/api/runs")
    assert runs.status_code == 200
    assert runs.json()[0]["run_mode"] == "simulated_drill"
    assert runs.json()[0]["top_k"] == 10
    assert runs.json()[0]["cooldown_days"] == 7


def test_overview_and_alert_detail(
    api_client: TestClient,
    drill_run: dict,
    first_alert: dict,
) -> None:
    overview = api_client.get(
        f"/api/runs/{drill_run['run_id']}/overview",
        params={"sma_preset": "medium_city"},
    )
    assert overview.status_code == 200, overview.text
    overview_payload = overview.json()
    assert overview_payload["daily_top_k"] == 10
    assert overview_payload["router_curve"]
    assert overview_payload["sma_capital_estimate"]["estimated_capital_release"] > 0

    detail = api_client.get(f"/api/alerts/{first_alert['alert_id']}")
    assert detail.status_code == 200, detail.text
    payload = detail.json()
    assert payload["evidence_card"]["evidence_card_type"] == (
        "multi_view_manifold_evidence_card"
    )
    assert payload["behavior_dimensions"]
    assert payload["soft_peer_baseline"]["profile_dimensions"] == 47
    assert payload["regulatory_mapping"]["basel_category"]


def test_csv_contract_rejects_invalid_header(api_client: TestClient) -> None:
    response = api_client.post(
        "/api/runs/upload",
        files={"file": ("bad.csv", b"user_id,date,has_any_event\nA,2025-01-01,1\n", "text/csv")},
    )
    assert response.status_code == 422
    assert "expected_columns" in response.json()["detail"]


def test_csv_upload_success(
    api_client: TestClient,
    generated_bank_data,
) -> None:
    output, _ = generated_bank_data
    csv_path = output / "bank_sim_unlabeled.csv"
    with csv_path.open("rb") as handle:
        response = api_client.post(
            "/api/runs/upload",
            files={"file": ("unlabeled.csv", handle, "text/csv")},
        )
    assert response.status_code == 200, response.text
    assert response.json()["run_mode"] == "unlabeled_live"
    assert response.json()["alert_count"] > 0


def test_rbac_masking_unmask_and_review(
    api_client: TestClient,
    first_alert: dict,
) -> None:
    forbidden = api_client.post(
        f"/api/alerts/{first_alert['alert_id']}/unmask",
        headers={"X-Role": "first_line_reviewer"},
    )
    assert forbidden.status_code == 403

    unmask = api_client.post(
        f"/api/alerts/{first_alert['alert_id']}/unmask",
        headers={"X-Role": "second_line_risk"},
    )
    assert unmask.status_code == 200, unmask.text
    assert unmask.json()["audit_written"] is True
    assert unmask.json()["employee_name"]

    review = api_client.post(
        f"/api/alerts/{first_alert['alert_id']}/review",
        headers={"X-Role": "first_line_reviewer"},
        json={
            "verdict": "confirmed_risk",
            "disposition": "转入二道防线调查",
            "reviewer_note": "测试确认",
            "corrected_basel_category": "内部欺诈——未经授权活动",
        },
    )
    assert review.status_code == 200, review.text
    assert review.json()["audit_written"] is True

    audit = api_client.get(
        "/api/audit",
        headers={"X-Role": "third_line_audit"},
    )
    assert audit.status_code == 200
    actions = {item["action"] for item in audit.json()["items"]}
    assert "unmask_employee_identity" in actions
    assert "review_escalated_ldc" in actions


def test_watchlist_permissions_and_priority(
    api_client: TestClient,
    first_alert: dict,
) -> None:
    denied = api_client.post(
        "/api/watchlist",
        headers={"X-Role": "first_line_reviewer"},
        json={
            "employee_id": first_alert["employee_id_masked"],
            "reason": "测试",
        },
    )
    assert denied.status_code == 403
    created = api_client.post(
        "/api/watchlist",
        headers={"X-Role": "second_line_risk"},
        json={
            "employee_id": first_alert["employee_id_masked"],
            "reason": "重点关注测试",
        },
    )
    assert created.status_code == 200, created.text
    items = api_client.get(
        "/api/alerts",
        params={"page": 1, "page_size": 5},
    ).json()["items"]
    assert items[0]["watchlist_flag"] is True
