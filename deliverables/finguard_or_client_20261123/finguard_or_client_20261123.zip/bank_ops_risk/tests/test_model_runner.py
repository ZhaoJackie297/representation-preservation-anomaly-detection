from __future__ import annotations

from model_runner import ModelRunner, ModelRunnerConfig


def test_softinst_rand_runner_unlabeled_live(generated_bank_data) -> None:
    output, _ = generated_bank_data
    runner = ModelRunner(
        ModelRunnerConfig(
            baseline_days=90,
            top_k=10,
            cooldown_days=7,
        )
    )
    result = runner.run(
        output / "bank_sim_unlabeled.csv",
        run_mode="unlabeled_live",
    )
    assert result.model_version.startswith("SoftInst-Rand")
    assert result.metrics["alert_count"] > 0
    assert "norm_mean" in result.cross_modal_audit
    assert "radial_energy_share" in result.cross_modal_audit
    assert result.alerts
    evidence = result.alerts[0]["evidence_card"]
    assert evidence["evidence_card_type"] == "multi_view_manifold_evidence_card"
    assert "raw_first_logon_min" in evidence
    assert "raw_last_logoff_min" in evidence
    assert "raw_active_span_min" in evidence
    assert "raw_usb_connect_count" in evidence
    assert "peer_channel_means" in evidence
    assert "self_hist_channel_medians" in evidence
    assert "S4" not in evidence["evidence_card_type"]
