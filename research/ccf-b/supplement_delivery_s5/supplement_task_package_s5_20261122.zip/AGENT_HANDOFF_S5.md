# Exp S5 干预补实验执行交接说明（给本地实验 AI）

本包用于闭环二轮严格审稿中**唯一剩余的因果干预与跨表口径缺口**，面向仓库 `ZhaoJackie297/representation-preservation-anomaly-detection`。全部脚本均沿用上一轮 `S1–S4` 已在 RTX 5060 环境验证通过的模块接口与评测口径，复制到 `<repo_root>/research/ccf-b/supplement/` 即可运行。

---

## 0. 执行铁律

1. **禁止编造、插值或修改任何指标**；全部输出原样写入 `research/ccf-b/supplement_results/`，严禁改动原有 `results/canonical/` 与历史权重。
2. **钩子防静默失效（S5a）**：`exp_s5a_norm_intervention.py` 内置 `hook_calls >= n_steps` 强断言，确保 `Hard-L2Reg-*` 与 `Hard-Sphere-*` 的显式范数惩罚/单位球温度损失**每一步均真实生效**；如因本地模块名差异触发断言，请先查看 `research/ccf-b/phase0/coverage_soft_ts2vec.py` 中 `fit_coverage_table` 调用的损失函数名并做最小适配，切勿绕过断言。
3. **统一环境**：沿用上一轮成功的 `C:\Users\Lenovo\.conda\envs\ts2vec\python.exe`，在仓库根目录 `<repo_root>` 下运行。

---

## 1. 部署脚本

```powershell
Copy-Item "<本包路径>\exp_s5*.py" research/ccf-b/supplement/ -Force
```

---

## 2. 执行顺序（P0 必跑，P1 强烈建议）

### 任务 A（P0 最高优先级 — 核心因果干预，GPU ~10–12 分钟）：`exp_s5a_norm_intervention.py`

回应审稿人核心质疑 **一.1（“隐式范数正则带来增益”仅有相关证据、缺少干预实验）**。在 CERT r4.2 同 5 种子（`20261116–20261120`）、同 620 步随机批、同 5 打分器下，同步对比 11 组干预对照（含几何指标 `mean_norm / effective_rank / knn10 / Spearman / radial_share`）：
- `Hard-Rand`（基线）
- `Hard-L2Reg-b{0.02, 0.10, 0.30, 1.00}`（硬对比 + 显式表示平方范数惩罚 $\beta\mathbb{E}[\|\mathbf{z}\|_2^2]$）
- `Hard-Sphere-t{0.1, 0.2, 0.5}`（硬对比 + 每层 L2 单位球归一化 + 温度 $\tau$）
- `PermSoft-Rand`（对称置换 $P W_I P^\top$：同软权重分布/熵/隐式范数收缩、**零 47D 画像语义**）
- `UniformSoft-Rand`（常数非对角软权重：纯标签平滑无配对结构）
- `SoftInst-Rand`（真 47D 画像软权重金标对照）

```powershell
python research/ccf-b/supplement/exp_s5a_norm_intervention.py
```

> **注**：跑完后请扫一眼终端打印的 `S5a GEOMETRY SUMMARY`，确认 `Hard-L2Reg-b*` 4 档中至少有一档的 `mean_norm_active` 落在 `1.2–1.6`（与 `SoftInst-Rand` 的 `~1.39` 对齐）。如果 4 档全高于 `1.8` 或全低于 `1.1`，可顺手补跑一档中间 $\beta$（如 `--arms Hard-L2Reg-b0.05` 或 `Hard-L2Reg-b2.0`）精准卡到 `~1.4`。

---

### 任务 B（P0 必跑 — r5.2 步数对称性 + 10 种子范数口径统一 + iForest 核查，GPU ~15–20 分钟）：`exp_s5b_symmetry_norms_audit.py`

回应审稿人质疑 **一.3（r5.2 缺 `Hard-Rand-Matched`、r4.2 范数 3 种子 vs 10 种子混用）** 与 **三（`iForest` 与 `T0+Mask` 同为 `0.007440` 核查）**：

```powershell
# B1. CPU 15秒核查：扫描仓库已有 iForest / T0 CSV 并复算 500 树 iForest 精确 8 位小数
python research/ccf-b/supplement/exp_s5b_symmetry_norms_audit.py audit-iforest-t0

# B2. CERT r4.2 10 种子 Hard-Rand-10ep（~3 分钟）：补齐表 4 余弦/欧氏库空白格与 10 种子精确均值范数
python research/ccf-b/supplement/exp_s5b_symmetry_norms_audit.py hard-r42-10ep

# B3. CERT r5.2 10 种子 Hard-Rand-10ep + Hard-Rand-Matched（~15 分钟，自动读取每种子精确匹配步数 2,631–2,654）
python research/ccf-b/supplement/exp_s5b_symmetry_norms_audit.py hard-r52-full
```

---

### 任务 C（P1 强烈建议 — 表 7 升级 3 种子 & SMD 补齐 `SoftInst-Rand`，GPU ~12 分钟）：`exp_s5c_norm_corr_3seed.py`

回应审稿人质疑 **一.4（跨数据集主变体不统一）** 与 **三（表 6 vs 表 7 单种子口径差）**：

```powershell
# C1. CERT r4.2 3 种子（20261116-20261118）式 (7) 径向-角度审计（直接复用 S5a 刚训练好的权重，~1 分钟）
python research/ccf-b/supplement/exp_s5c_norm_corr_3seed.py cert-3seed

# C2. SMD 28 台服务器 3 种子（20261201-20261203）T0_hard / T3_inst_soft (=SoftInst-Rand) / T4_soft 审计（~12 分钟）
python research/ccf-b/supplement/exp_s5c_norm_corr_3seed.py smd-3seed
```

---

### 任务 D（P2 可选加分项，若本地已有 CLUE-LDS / CERT r6.2 数据，~6 分钟）

若本地仍保留 `CLUE-LDS` 与 `CERT r6.2`（1,000 用户匹配子集）的预处理数据，建议用仓库原有评测脚本补跑一组统一主方法 **`SoftInst-Rand-10ep`（仅实例软对比、标准随机批 10 轮）** vs **`Hard-Rand-10ep`**（CLUE-LDS 10 种子、r6.2 3 种子），将结果 CSV 一并放入 `research/ccf-b/supplement_results/exp_s5d_unify_clue_r62/`；若数据已移走则跳过即可，并在 `RUN_LOG_S5.md` 中注明。

---

## 3. 完成后打包回传的轻量文件（无需大模型权重与 `.npz`）

请将以下轻量 `.csv` / `.json`（以及执行记录 `RUN_LOG_S5.md`）打成 `supplement_s5_results_light.zip` 推至仓库（如 `research/ccf-b/supplement_delivery_s5/`）即可：

1. `exp_s5a_norm_intervention/`：`method_summary.csv`、`metrics_by_seed.csv`、`geometry_summary.csv`、`geometry_by_seed.csv`、`paired_vs_hard_and_soft.csv`
2. `exp_s5b_symmetry_audit/`：
   - `iforest_t0_audit/iforest_t0_exact_audit.json`
   - `r42_hard_10ep/method_summary.csv`、`metrics_by_seed.csv`、`norms_summary.csv`、`norms_by_seed.csv`
   - `r52_hard_full/method_summary.csv`、`metrics_by_seed.csv`、`norms_summary.csv`、`norms_by_seed.csv`
3. `exp_s5c_norm_corr_3seed/`：
   - `cert_r42_3seed/cert_norm_radial_3seed_summary.csv`、`cert_norm_radial_by_seed.csv`
   - `smd_3seed/smd_norm_radial_3seed_summary.csv`、`smd_norm_radial_by_seed.csv`、`smd_norm_radial_all_machines_3seed.csv`
4. （若执行了任务 D）`exp_s5d_unify_clue_r62/` 下的汇总 CSV
5. `RUN_LOG_S5.md`（记录实际运行命令、耗时、环境微调与终端摘要）
