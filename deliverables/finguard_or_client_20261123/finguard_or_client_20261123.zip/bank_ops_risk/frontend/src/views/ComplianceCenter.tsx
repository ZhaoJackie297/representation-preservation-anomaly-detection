import { useEffect, useState } from "react";
import {
  Eye,
  FileLock2,
  History,
  ShieldCheck,
  Star,
  UserRoundCog
} from "lucide-react";
import { api } from "../api";
import { roleLabel } from "../format";
import type {
  AlertItem,
  AuditPage,
  Role,
  UnmaskResult,
  WatchlistItem
} from "../types";
import {
  ErrorBlock,
  LoadingBlock,
  PageHeader
} from "../components/Shared";

const roleDescriptions: Array<{
  role: Role;
  title: string;
  detail: string;
}> = [
  {
    role: "first_line_reviewer",
    title: "一道防线",
    detail: "业务复核和 LDC 处置，不可解敏。"
  },
  {
    role: "second_line_risk",
    title: "二道防线",
    detail: "风险复核、Watchlist 管理与合规解敏。"
  },
  {
    role: "third_line_audit",
    title: "三道防线",
    detail: "独立审计、解敏与全量留痕查看。"
  }
];

export function ComplianceCenter({
  runId,
  role,
  setRole
}: {
  runId: string | null;
  role: Role;
  setRole: (role: Role) => void;
}) {
  const [audit, setAudit] = useState<AuditPage | null>(null);
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [selectedAlert, setSelectedAlert] = useState("");
  const [unmasked, setUnmasked] = useState<UnmaskResult | null>(null);
  const [watchId, setWatchId] = useState("");
  const [watchReason, setWatchReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const [auditResult, watchResult] = await Promise.all([
        api.audit(role),
        api.watchlist()
      ]);
      setAudit(auditResult);
      setWatchlist(watchResult);
      if (runId) {
        const alertResult = await api.alerts(runId, {
          page: 1,
          pageSize: 50
        });
        setAlerts(alertResult.items);
        setSelectedAlert((value) => value || alertResult.items[0]?.alert_id || "");
      }
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "审计数据加载失败");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [runId, role]);

  const unmask = async () => {
    if (!selectedAlert) return;
    setError(null);
    try {
      setUnmasked(await api.unmask(selectedAlert, role));
      await load();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "解敏失败");
    }
  };

  const addWatch = async () => {
    if (!watchId || !watchReason) return;
    setError(null);
    try {
      await api.addWatchlist(role, {
        employee_id: watchId,
        reason: watchReason
      });
      setWatchReason("");
      await load();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Watchlist 更新失败");
    }
  };

  return (
    <div className="page-stack">
      <PageHeader
        eyebrow="三道防线 / Governance"
        title="合规隐私与审计台账中心"
        description="角色切换用于演示权限隔离。解敏、复核和 Watchlist 变更均写入只读审计流。"
      />
      <section className="role-cards">
        {roleDescriptions.map((item) => (
          <button
            key={item.role}
            className={`role-card ${role === item.role ? "active" : ""}`}
            onClick={() => setRole(item.role)}
          >
            <UserRoundCog size={19} />
            <strong>{item.title}</strong>
            <span>{item.detail}</span>
          </button>
        ))}
      </section>
      {error ? <ErrorBlock message={error} /> : null}
      {loading ? <LoadingBlock /> : null}
      <section className="compliance-grid">
        <article className="panel">
          <div className="panel-title">
            <div>
              <span className="eyebrow">当前权限</span>
              <h2>{roleLabel(role)}</h2>
            </div>
            <FileLock2 size={20} />
          </div>
          <div className="form-stack">
            <label>
              选择告警触发解敏审批
              <select
                value={selectedAlert}
                onChange={(event) => setSelectedAlert(event.target.value)}
              >
                {alerts.map((alert) => (
                  <option value={alert.alert_id} key={alert.alert_id}>
                    {alert.employee_id_masked} · {alert.alert_date}
                  </option>
                ))}
              </select>
            </label>
            <button
              className="button secondary"
              onClick={unmask}
              disabled={role === "first_line_reviewer" || !selectedAlert}
            >
              <Eye size={16} />
              {role === "first_line_reviewer"
                ? "一道防线无解敏权限"
                : "申请解敏并留痕"}
            </button>
            {unmasked ? (
              <div className="unmasked-card">
                <ShieldCheck size={18} />
                <div>
                  <strong>
                    {unmasked.employee_name} / {unmasked.employee_code}
                  </strong>
                  <span>
                    {unmasked.grid_name} · {unmasked.role_name}
                  </span>
                </div>
              </div>
            ) : null}
          </div>
        </article>
        <article className="panel">
          <div className="panel-title">
            <div>
              <span className="eyebrow">Watchlist</span>
              <h2>重点关注名单</h2>
            </div>
            <Star size={20} />
          </div>
          <div className="watchlist-form">
            <input
              placeholder="AnonEmp-xxxx"
              value={watchId}
              onChange={(event) => setWatchId(event.target.value)}
            />
            <input
              placeholder="关注原因"
              value={watchReason}
              onChange={(event) => setWatchReason(event.target.value)}
            />
            <button
              className="button secondary"
              onClick={addWatch}
              disabled={
                role === "first_line_reviewer" || !watchId || !watchReason
              }
            >
              添加关注
            </button>
          </div>
          <div className="watchlist-items">
            {watchlist.map((item) => (
              <div key={item.id}>
                <Star size={14} fill="currentColor" />
                <strong>{item.employee_id}</strong>
                <span>{item.reason}</span>
                <small>{item.active ? "有效" : "停用"}</small>
              </div>
            ))}
          </div>
        </article>
      </section>
      <section className="panel">
        <div className="panel-title">
          <div>
            <span className="eyebrow">Append-only Ledger</span>
            <h2>不可篡改 AuditTrail</h2>
          </div>
          <History size={20} />
        </div>
        <div className="audit-stream">
          {audit?.items.map((item) => (
            <article key={item.id}>
              <time>{new Date(item.timestamp).toLocaleString("zh-CN")}</time>
              <span className="audit-role">{roleLabel(item.actor_role)}</span>
              <strong>{item.action}</strong>
              <p>
                {item.target_entity} · {item.reason}
              </p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
