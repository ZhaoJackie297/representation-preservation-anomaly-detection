from __future__ import annotations

from sqlalchemy import func, inspect, select

from db import (
    Alert,
    AuditTrail,
    ReviewLDC,
    Run,
    WatchlistEntity,
    create_db_engine,
    create_review,
    create_session_factory,
    init_db,
    persist_run_result,
    session_scope,
    set_watchlist,
)
from model_runner import RunResult


def _fake_result() -> RunResult:
    evidence = {
        "evidence_card_type": "multi_view_manifold_evidence_card",
        "z_cos": 1.0,
        "z_euc": 2.0,
        "z_magG": 3.0,
        "z_T2": 4.0,
        "manifold_velocity": 0.1,
        "manifold_curvature": 0.01,
        "peer_channel_means": {"login": 1.0},
        "self_hist_channel_medians": {"login": 0.5},
        "raw_first_logon_min": 0.0,
        "raw_last_logoff_min": 480.0,
        "raw_active_span_min": 480.0,
        "raw_usb_connect_count": 2.0,
    }
    return RunResult(
        run_mode="unlabeled_live",
        model_version="test-model",
        cross_modal_audit={"route": "angular", "norm_mean": 1.0},
        metrics={"alert_count": 1},
        alerts=[
            {
                "employee_id": "AnonEmp-0001",
                "alert_date": "2025-04-01",
                "rank": 1,
                "risk_score": 3.0,
                "reason_code": "export_sensitive_data_movement",
                "basel_category": "内部欺诈——盗窃与欺诈",
                "data_sensitivity_jr_t_0197": "L4",
                "personal_info_jr_t_0171": "C3",
                "subscores": {"z_cos": 1.0, "z_euc": 2.0},
                "evidence_card": evidence,
            }
        ],
    )


def test_sqlite_five_table_read_write() -> None:
    engine = create_db_engine("sqlite:///:memory:")
    init_db(engine)
    assert set(inspect(engine).get_table_names()) == {
        "runs",
        "alerts",
        "reviews_ldc",
        "watchlist_entities",
        "audit_trail",
    }
    factory = create_session_factory(engine)
    with session_scope(factory) as session:
        set_watchlist(
            session,
            employee_id="AnonEmp-0001",
            reason="测试",
            created_by="tester",
        )
        run = persist_run_result(
            session,
            _fake_result(),
            staff_meta={
                "AnonEmp-0001": {
                    "grid_name": "总行",
                    "role_name": "柜面运营",
                }
            },
        )
        alert = session.scalar(select(Alert).where(Alert.run_id == run.id))
        assert alert.watchlist_flag is True
        create_review(
            session,
            alert_id=alert.id,
            review_state="dismissed_fp",
            reviewer_role="tester",
            recommended_action="关闭",
            review_notes="测试误报",
        )
    with session_scope(factory) as session:
        assert session.scalar(select(func.count()).select_from(Run)) == 1
        assert session.scalar(select(func.count()).select_from(Alert)) == 1
        assert session.scalar(select(func.count()).select_from(ReviewLDC)) == 1
        assert session.scalar(select(func.count()).select_from(WatchlistEntity)) == 1
        assert session.scalar(select(func.count()).select_from(AuditTrail)) == 3
