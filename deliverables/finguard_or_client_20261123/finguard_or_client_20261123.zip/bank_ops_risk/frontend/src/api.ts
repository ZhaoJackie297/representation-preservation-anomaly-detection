import type {
  AlertDetail,
  AlertPage,
  AuditPage,
  Health,
  Overview,
  Role,
  RunSummary,
  WatchlistItem
} from "./types";

const API_BASE = "/api";

export class ApiError extends Error {
  status: number;

  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function request<T>(
  path: string,
  init?: RequestInit,
  role?: Role
): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      ...(init?.body instanceof FormData
        ? {}
        : { "Content-Type": "application/json" }),
      ...(role ? { "X-Role": role } : {}),
      ...init?.headers
    }
  });
  if (!response.ok) {
    let message = `HTTP ${response.status}`;
    try {
      const payload = (await response.json()) as {
        detail?: unknown;
      };
      message =
        typeof payload.detail === "string"
          ? payload.detail
          : JSON.stringify(payload.detail ?? payload);
    } catch {
      // Preserve HTTP status.
    }
    throw new ApiError(response.status, message);
  }
  return (await response.json()) as T;
}

export const api = {
  health: () => request<Health>("/health"),
  runs: () => request<RunSummary[]>("/runs"),
  triggerDrill: () =>
    request<{
      run_id: string;
      run_mode: string;
      alert_count: number;
      cross_modal_audit: Record<string, unknown>;
      synthetic_banner: string;
    }>("/runs/drill", {
      method: "POST",
      body: JSON.stringify({ force_refresh: true })
    }),
  upload: (file: File) => {
    const body = new FormData();
    body.append("file", file);
    return request<{
      run_id: string;
      run_mode: string;
      alert_count: number;
      cross_modal_audit: Record<string, unknown>;
      synthetic_banner: string | null;
    }>("/runs/upload", { method: "POST", body });
  },
  overview: (runId: string, preset = "medium_city") =>
    request<Overview>(
      `/runs/${encodeURIComponent(runId)}/overview?sma_preset=${preset}`
    ),
  alerts: (
    runId: string,
    options: {
      page?: number;
      pageSize?: number;
      date?: string;
      department?: string;
      role?: string;
      status?: string;
      minScore?: string;
    } = {}
  ) => {
    const params = new URLSearchParams({
      run_id: runId,
      page: String(options.page ?? 1),
      page_size: String(options.pageSize ?? 25)
    });
    for (const [key, value] of Object.entries(options)) {
      if (!value) continue;
      const queryKey =
        key === "pageSize"
          ? "page_size"
          : key === "minScore"
            ? "min_score"
            : key;
      params.set(queryKey, String(value));
    }
    return request<AlertPage>(`/alerts?${params.toString()}`);
  },
  alert: (alertId: string) =>
    request<AlertDetail>(`/alerts/${encodeURIComponent(alertId)}`),
  review: (
    alertId: string,
    role: Role,
    payload: {
      verdict: string;
      disposition: string;
      reviewer_note: string;
      corrected_basel_category?: string;
    }
  ) =>
    request<Record<string, unknown>>(
      `/alerts/${encodeURIComponent(alertId)}/review`,
      { method: "POST", body: JSON.stringify(payload) },
      role
    ),
  unmask: (alertId: string, role: Role) =>
    request<{
      employee_id: string;
      employee_code: string;
      employee_name: string;
      role_name: string;
      grid_name: string;
      audit_written: boolean;
    }>(
      `/alerts/${encodeURIComponent(alertId)}/unmask`,
      { method: "POST" },
      role
    ),
  watchlist: () => request<WatchlistItem[]>("/watchlist"),
  addWatchlist: (
    role: Role,
    payload: { employee_id: string; reason: string; active?: boolean }
  ) =>
    request<WatchlistItem>(
      "/watchlist",
      { method: "POST", body: JSON.stringify(payload) },
      role
    ),
  audit: (role: Role, page = 1, pageSize = 50) =>
    request<AuditPage>(
      `/audit?page=${page}&page_size=${pageSize}`,
      undefined,
      role
    )
};
