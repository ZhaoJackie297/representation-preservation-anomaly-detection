# 智御内控 FinGuard-OR

本目录是商业银行内部操作风险识别平台的第一阶段后端底座。它独立于旧版
`v3` 和论文仓库，旧 `results/canonical/`、`processed_*`、`innovation_sim/`
与既有 `research/ccf-b/` 文件均为只读依赖。

## Components

- `bank_domain_dict.json`: 27 维模型特征到银行审计语义、监管索引、Basel
  分类、岗位和责任网格的映射。
- `bank_sim_generator.py`: 500 名员工 × 180 天可重复仿真；前 90 天仅正常
  基线，后 90 天植入四类操作风险剧本。
- `model_runner.py`: 冻结的 `SoftInst-Rand` 编码器、CPU
  `fast_bank_refit`、500 簇记忆库、训练期 Z-score、零标签 Eq.(7)
  模态路由和多视图流形证据卡。
- `db.py`: SQLAlchemy 2 ORM 的 5 张表。`sqlite:///...` 用于开发，
  openGauss 部署时改为对应的 PostgreSQL 兼容 SQLAlchemy URL。
- `smoke_e2e.py`: 生成数据、无标签推理、持久化五表和无界面汇总。
- `api.py` / `schemas.py`: FastAPI + Pydantic v2 后端，支持单端口静态挂载。
- `frontend/`: React + TypeScript + Vite 工作台，包含驾驶舱、告警队列、
  六阶段证据抽屉、红队演练、CSV 接入和合规审计视图。
- `tests/`: 特征契约、模型、数据库测试。

## Commands

```powershell
Set-Location E:\MarketRisker\work\cert\apps\bank_ops_risk

C:\Users\Lenovo\.conda\envs\ts2vec\python.exe bank_sim_generator.py --force
C:\Users\Lenovo\.conda\envs\ts2vec\python.exe smoke_e2e.py
C:\Users\Lenovo\.conda\envs\ts2vec\python.exe -m pytest -q
```

## Frontend development

```powershell
Set-Location E:\MarketRisker\work\cert\apps\bank_ops_risk\frontend
pnpm install
pnpm run dev
```

The Vite dev server runs at `http://127.0.0.1:5173` and proxies `/api` to
`http://127.0.0.1:8000`.

## Production single-port service

Build the frontend first:

```powershell
Set-Location E:\MarketRisker\work\cert\apps\bank_ops_risk\frontend
pnpm run build
```

Then start FastAPI from the package root:

```powershell
Set-Location E:\MarketRisker\work\cert\apps\bank_ops_risk
C:\Users\Lenovo\.conda\envs\ts2vec\python.exe -m uvicorn api:app `
  --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`. FastAPI serves the API under `/api` and the
compiled React application from `frontend/dist`.

## API roles and data boundary

Mutating requests use the `X-Role` header:

```text
first_line_reviewer  一道防线复核员，不能解敏
second_line_risk     二道防线风控官，可复核、解敏和管理 Watchlist
third_line_audit     三道防线内审员，可复核、解敏和读取审计台账
```

Production configuration:

```powershell
$env:FINGUARD_DATABASE_URL = "sqlite:///E:/MarketRisker/work/cert/apps/bank_ops_risk/data/finguard_or.db"
$env:FINGUARD_ENV = "development"
```

For openGauss, use its PostgreSQL-compatible SQLAlchemy connection URL and
install the matching DBAPI driver. The ORM and API do not contain SQLite-only
SQL.

Production CSV contract:

```text
user_id,date,has_any_event,logon_count,logoff_count,first_logon_minute,
last_logoff_minute,active_span_minutes,after_hours_logon_count,
other_pc_logon_count,usb_connect_count,usb_disconnect_count,
file_copy_count,archive_copy_count,executable_copy_count,
unique_file_extensions,email_count,email_recipient_count,
external_recipient_count,email_attachment_count,email_size_bytes,
after_hours_email_count,http_count,after_hours_http_count,
external_http_count,unique_http_domains,is_weekend,weekday_sin,weekday_cos
```

`unlabeled_live` 只按上述显式列读取 CSV，不读取 `labels`、`event_id`
或事件表。演练真值文件只用于 `simulated_drill` 评分。

## Abstraction boundaries

- `ModelRunner` owns device choice, causal encoding, memory-bank refit,
  Eq.(7) diagnostics, peer soft weights and evidence generation.
- `db.py` owns ORM persistence. It contains no model scoring logic.
- `api.py` owns HTTP permissions and response shaping. It does not calculate
  anomaly scores.
- Watchlist is applied only when alerts are persisted for frontend priority.
  It is never passed to the encoder, memory bank or score calibration.
