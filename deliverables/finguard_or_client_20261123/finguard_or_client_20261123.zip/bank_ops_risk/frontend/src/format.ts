export const numberFormat = new Intl.NumberFormat("zh-CN", {
  maximumFractionDigits: 2
});

export function formatNumber(value: number | null | undefined): string {
  return value == null || Number.isNaN(value) ? "—" : numberFormat.format(value);
}

export function formatScore(value: number | null | undefined): string {
  return value == null || Number.isNaN(value) ? "—" : value.toFixed(3);
}

export function formatMoney(value: number | null | undefined): string {
  if (value == null || Number.isNaN(value)) return "—";
  if (Math.abs(value) >= 100_000_000) {
    return `${(value / 100_000_000).toFixed(2)} 亿元`;
  }
  if (Math.abs(value) >= 10_000) {
    return `${(value / 10_000).toFixed(2)} 万元`;
  }
  return `${numberFormat.format(value)} 元`;
}

export function roleLabel(role: string): string {
  return (
    {
      first_line_reviewer: "一道防线复核员",
      second_line_risk: "二道防线风控官",
      third_line_audit: "三道防线内审员"
    } as Record<string, string>
  )[role] ?? role;
}

export function metricLabel(metric: string): string {
  return (
    {
      pai_mean: "PAI-Mean",
      bank_cosine: "余弦记忆库",
      bank_euclidean: "欧氏记忆库",
      plain_l1: "Mask L1"
    } as Record<string, string>
  )[metric] ?? metric;
}
