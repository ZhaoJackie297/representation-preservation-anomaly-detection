import {
  Activity,
  ChevronRight,
  Landmark,
  ShieldAlert,
  Users
} from "lucide-react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";
import { formatMoney, formatNumber, metricLabel } from "../format";
import type { Overview } from "../types";
import {
  MetricCard,
  PageHeader,
  SyntheticBanner
} from "../components/Shared";

export function Dashboard({
  overview,
  onConfigureDrill
}: {
  overview: Overview | null;
  onConfigureDrill: () => void;
}) {
  if (!overview) {
    return (
      <section>
        <PageHeader
          eyebrow="风险总览"
          title="尚无可用运行批次"
          description="先生成一次合成演练，或从数据接入中心上传脱敏生产日志。"
        />
        <button className="button primary" onClick={onConfigureDrill}>
          前往红队演练
          <ChevronRight size={17} />
        </button>
      </section>
    );
  }
  const route = overview.router_curve;
  const maxFunnel = Math.max(...overview.funnel.map((item) => item.count), 1);
  return (
    <div className="page-stack">
      <PageHeader
        eyebrow="风险总览 / Control Room"
        title="内部操作风险总览驾驶舱"
        description="聚焦有限审查预算下的 Top-K 风险分流、零标签度量和操作风险资本辅助测算。"
      />
      {overview.synthetic_banner ? (
        <SyntheticBanner text={overview.synthetic_banner} />
      ) : null}
      <section className="metric-grid">
        <MetricCard
          label="最近一日 / 全周期"
          value={`${formatNumber(overview.latest_active_employees)} / ${formatNumber(
            overview.total_active_employee_days
          )}`}
          detail="最近一日活跃员工数 / 全周期活跃员工日"
        />
        <MetricCard
          label={`评估期 Top-${overview.daily_top_k} 告警`}
          value={formatNumber(overview.alert_count)}
          detail={`${overview.evaluation_employee_count} 名员工进入告警队列`}
          tone="alert"
        />
        <MetricCard
          label="7 天冷却拦截"
          value={formatNumber(overview.cooldown_suppressed_candidates)}
          detail="避免同一风险实体连续占满审查预算"
        />
        <MetricCard
          label="零标签路由"
          value={metricLabel(overview.recommended_metric)}
          detail={`|ρ| = ${(overview.run.abs_rho ?? 0).toFixed(3)}，仅使用基线窗口`}
          tone="good"
        />
      </section>

      <section className="dashboard-grid">
        <article className="panel">
          <div className="panel-title">
            <div>
              <span className="eyebrow">预算分流</span>
              <h2>K + 冷却漏斗</h2>
            </div>
            <Activity size={20} />
          </div>
          <div className="funnel">
            {overview.funnel.map((item, index) => (
              <div className="funnel-row" key={item.stage}>
                <span>{item.stage}</span>
                <div>
                  <i
                    style={{
                      width: `${Math.max(
                        (item.count / maxFunnel) * 100,
                        item.count ? 8 : 0
                      )}%`,
                      opacity: 1 - index * 0.12
                    }}
                  />
                </div>
                <strong>{formatNumber(item.count)}</strong>
              </div>
            ))}
          </div>
          <p className="panel-note">
            冷却期只抑制重复告警，不修改风险分；Watchlist 只影响前端排序。
          </p>
        </article>

        <article className="panel">
          <div className="panel-title">
            <div>
              <span className="eyebrow">零标签诊断</span>
              <h2>训练窗口 |ρ̂| 曲线</h2>
            </div>
            <ShieldAlert size={20} />
          </div>
          <div className="chart-box compact">
            <ResponsiveContainer>
              <LineChart data={route}>
                <CartesianGrid stroke="#E2E8F0" strokeDasharray="3 4" />
                <XAxis
                  dataKey="window_days"
                  tickFormatter={(value) => `${value}日`}
                />
                <YAxis domain={[0, 1]} />
                <Tooltip
                  formatter={(value: number) => value.toFixed(3)}
                  labelFormatter={(value) => `${value} 日窗口`}
                />
                <Line
                  type="monotone"
                  dataKey="abs_rho"
                  stroke="#1F4E78"
                  strokeWidth={2.5}
                  dot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="panel-note">
            阈值规则：|ρ| 与 CV 同时大于 0.50 时使用欧氏库，否则使用
            PAI-Mean。
          </p>
        </article>
      </section>

      <section className="dashboard-grid">
        <article className="panel">
          <div className="panel-title">
            <div>
              <span className="eyebrow">Basel III SMA</span>
              <h2>操作风险资本释放辅助测算</h2>
            </div>
            <Landmark size={20} />
          </div>
          <dl className="detail-list">
            <div>
              <dt>业务指标 BI</dt>
              <dd>{formatMoney(overview.sma_capital_estimate.business_indicator)}</dd>
            </div>
            <div>
              <dt>业务指标分量 BIC</dt>
              <dd>
                {formatMoney(
                  overview.sma_capital_estimate.business_indicator_component
                )}
              </dd>
            </div>
            <div>
              <dt>内部损失乘数 ILM</dt>
              <dd>
                {overview.sma_capital_estimate.internal_loss_multiplier.toFixed(3)}
              </dd>
            </div>
            <div>
              <dt>基准操作风险资本</dt>
              <dd>
                {formatMoney(
                  overview.sma_capital_estimate
                    .baseline_operational_risk_capital
                )}
              </dd>
            </div>
            <div className="emphasis-row">
              <dt>估算资本释放</dt>
              <dd>
                {formatMoney(
                  overview.sma_capital_estimate.estimated_capital_release
                )}
              </dd>
            </div>
          </dl>
          <p className="panel-note">
            {overview.sma_capital_estimate.note}
          </p>
        </article>

        <article className="panel">
          <div className="panel-title">
            <div>
              <span className="eyebrow">运营规模</span>
              <h2>审查负载</h2>
            </div>
            <Users size={20} />
          </div>
          <div className="summary-list">
            <div>
              <span>评估期活跃员工日</span>
              <strong>
                {formatNumber(overview.evaluation_active_employee_days)}
              </strong>
            </div>
            <div>
              <span>每日预算</span>
              <strong>{overview.daily_top_k}</strong>
            </div>
            <div>
              <span>冷却间隔</span>
              <strong>{overview.run.cooldown_days} 天</strong>
            </div>
            <div>
              <span>推荐度量</span>
              <strong>{metricLabel(overview.recommended_metric)}</strong>
            </div>
          </div>
        </article>
      </section>
    </div>
  );
}
