from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from bank_sim_generator import FEATURE_NAMES
from model_runner import INDEX, sanitize_model_values


PACKAGE_ROOT = Path(__file__).resolve().parents[1]


def test_domain_dictionary_codes_and_no_c4() -> None:
    payload = json.loads(
        (PACKAGE_ROOT / "bank_domain_dict.json").read_text(encoding="utf-8")
    )
    assert payload["platform"]["feature_dimensions"] == 27
    assert payload["compliance_registry"]["JR/T 0197-2020"]["grades"] == [
        "L1",
        "L2",
        "L3",
        "L4",
        "L5",
    ]
    assert payload["compliance_registry"]["JR/T 0171-2020"]["classes"] == [
        "C1",
        "C2",
        "C3",
    ]
    assert "C4" not in payload["compliance_registry"]["JR/T 0171-2020"]["classes"]
    assert {feature["name"] for feature in payload["features"]} == set(
        FEATURE_NAMES
    )
    assert {
        feature["name"]: feature["index"] for feature in payload["features"]
    } == INDEX


def test_generated_data_contract_and_unlabeled_template(generated_bank_data) -> None:
    output, manifest = generated_bank_data
    with np.load(output / "bank_sim_drill.npz", allow_pickle=False) as dataset:
        values = dataset["values"]
        active = dataset["active_mask"]
        labels = dataset["labels"]
        features = dataset["features"].astype(str).tolist()
        assert values.shape == (50, 180, 27)
        assert active.shape == (50, 180)
        assert labels.shape == (50, 180)
        assert features == FEATURE_NAMES
        assert np.any(values[:, :, 3:6] == -1)
        assert np.any(values[:, :, [3, 4]] == 0)
        assert int(labels.sum()) == manifest["event_cells"]
    unlabeled = pd.read_csv(output / "bank_sim_unlabeled.csv", nrows=5)
    assert "labels" not in unlabeled.columns
    assert "event_id" not in unlabeled.columns
    assert list(unlabeled.columns) == ["user_id", "date", *FEATURE_NAMES]


def test_missing_safe_sentinel_midnight_contract() -> None:
    raw = np.zeros((1, 1, 27), dtype=np.float32)
    raw[0, 0, 0] = 1
    raw[0, 0, 3] = -1
    raw[0, 0, 4] = 0
    raw[0, 0, 5] = 360
    sanitized = sanitize_model_values(raw)
    assert np.isnan(sanitized[0, 0, 3])
    assert sanitized[0, 0, 4] == 0
    assert sanitized[0, 0, 5] == 360
