# FinGuard-OR（智御内控）继续开发交接指南

本文档面向接手 `apps/bank_ops_risk` 继续开发的工程师或 AI 助手，梳理了**目录结构、运行与测试命令、核心架构边界、以及下一阶段重点任务（以“商业银行内网风控终端风格”重构前端 UI）**。

---

## 1. 目录结构总览

```text
E:\MarketRisker\work\cert\apps\bank_ops_risk\
├── __init__.py
├── api.py                   # FastAPI 后端（/api/* 接口、权限头 X-Role 校验、frontend/dist 静态托管）
├── schemas.py               # Pydantic v2 请求/响应契约
├── db.py                    # SQLAlchemy 2 ORM（runs/alerts/reviews_ldc/watchlist_entities/audit_trail 五表）
├── model_runner.py          # 冻结 SoftInst-Rand 编码器、CPU fast_bank_refit、500簇记忆库、Eq.(7)零标签路由、证据卡生成
├── bank_sim_generator.py    # 500员工×180日银行操作风险演练数据生成器（含四类注入剧本）
├── bank_domain_dict.json    # 27维特征到银行审计语义、JR/T 0197/0171、Basel II/III 与网格岗位的映射词典
├── smoke_e2e.py             # 端到端无界面生成->推理->落库冒烟脚本
├── launch_finguard_or.bat   # Windows 纯ASCII一键启动脚本（启动 127.0.0.1:8000 并自动打开浏览器；桌面已有快捷方式）
├── requirements.txt         # Python 依赖（运行环境：C:\Users\Lenovo\.conda\envs\ts2vec\python.exe）
├── pytest.ini
├── README.md
├── HANDOVER.md              # 本交接文档
├── docs/
│   ├── ui_reference_bank_client.png   # 【UI改版视觉靶标】商业银行内网风控客户端参考界面（队列+同批证据卡双栏联动）
│   └── ui_reference_bank_client.html  # 参考界面的完整精确 HTML/CSS/SVG 原型（含色板、边框、圆角、表头与密度规范）
├── data/
│   ├── finguard_or.db                 # 当前已预置演练运行批次（含 0a69b272 等批次）的 SQLite 数据库
│   ├── bank_sim_unlabeled.csv         # 500×180 无标签行为流水特征（29列：user_id, date + 27维契约特征）
│   ├── bank_sim_drill_events.csv      # 仅限 simulated_drill 演练评分用的真值剧本明细
│   ├── bank_staff_meta.csv            # 员工网格与岗位元数据
│   ├── bank_sim_drill.parquet / .npz  # 同批次缓存文件
│   └── bank_sim_manifest.json
├── frontend/
│   ├── package.json         # React 18 + Vite 6 + TypeScript + Recharts + Lucide
│   ├── vite.config.ts       # 开发代理：/api -> http://127.0.0.1:8000
│   ├── dist/                # 编译产物（由 api.py 直接单端口托管）
│   └── src/
│       ├── App.tsx          # 壳层导航（dashboard / alerts / drill / upload / compliance）与角色切换
│       ├── api.ts           # REST 请求封装
│       ├── types.ts         # 前后端契约类型
│       ├── format.ts
│       ├── styles.css       # 【下一阶段重点重构文件】当前样式偏SaaS通用风，需改为行内监管终端风
│       ├── components/Shared.tsx
│       └── views/
│           ├── Dashboard.tsx
│           ├── Alerts.tsx          # 预警队列（当前点击弹窗抽屉，建议改造成左队列+右证据卡分栏联动）
│           ├── AlertDrawer.tsx     # 行为证据卡与合规处置详情（可拆分为右侧联动 EvidencePane 组件）
│           ├── DrillLab.tsx        # 红队演练发起与真值核验
│           ├── UploadCenter.tsx    # 生产 CSV 上传接入（unlabeled_live）
│           └── ComplianceCenter.tsx# 合规审计台账与 Watchlist 管理
└── tests/
    ├── conftest.py
    ├── test_api.py
    ├── test_bank_contracts.py
    ├── test_db.py
    └── test_model_runner.py
```

---

## 2. 环境、启动与验证命令

- **Python 解释器**：`C:\Users\Lenovo\.conda\envs\ts2vec\python.exe`
- **前端包管理器**：`pnpm`（Node/Vite）

```powershell
# 1) 运行全部后端/模型/API测试
Set-Location E:\MarketRisker\work\cert\apps\bank_ops_risk
C:\Users\Lenovo\.conda\envs\ts2vec\python.exe -m pytest -q

# 2) 前端开发热更新模式（需同时启动 uvicorn :8000）
Set-Location E:\MarketRisker\work\cert\apps\bank_ops_risk\frontend
pnpm run dev

# 3) 前端编译并打包进单端口服务端
Set-Location E:\MarketRisker\work\cert\apps\bank_ops_risk\frontend
pnpm run build

# 4) 启动单端口客户端服务（或直接双击 launch_finguard_or.bat）
Set-Location E:\MarketRisker\work\cert\apps\bank_ops_risk
C:\Users\Lenovo\.conda\envs\ts2vec\python.exe -m uvicorn api:app --host 127.0.0.1 --port 8000
```

> 注意：`launch_finguard_or.bat` 必须保持纯 ASCII + CRLF 编码，避免中文字符在 `cmd.exe` 代码页下被拆解报错。

---

## 3. 核心工程约束（修改代码时不可破坏）

1. **上游研究仓库只读隔离**：`apps/bank_ops_risk` 仅以只读方式引用上层历史结果或模型检查点，禁止写入或改动 `results/canonical/`、`processed_*`、`innovation_sim/` 与 `research/ccf-b/`。
2. **27 维缺失安全契约（`-1 -> NaN`）**：时间类特征（`first_logon_minute`、`last_logoff_minute`、`active_span_minutes`）中 `0` 代表午夜零点活动，`-1` 代表缺失；严禁把缺失填 `0`。
3. **无标签与真值严格隔离**：`unlabeled_live` 模式只读 29 列 CSV（`user_id, date` + 27 维），严禁读取任何标签列；Watchlist 仅在 `alerts` 落库展示层做优先级置顶提示，严禁传入编码器、记忆库或异常打分。
4. **RBAC 与解敏留痕**：变更类 API 通过请求头 `X-Role` 控制：
   - `first_line_reviewer`：可复核，**禁止**解敏（`/api/alerts/{id}/unmask`）与 Watchlist 管理；
   - `second_line_risk` / `third_line_audit`：可复核、申请审计解敏，操作必须写入 `audit_trail`。

---

## 4. 下一阶段重点开发任务：去“AI SaaS 味”UI 改造

当前前端虽然功能闭环，但用户明确反馈“现有 UI 的 AI 设计味道较重”，希望向**中国大型商业银行内网风控合规系统**靠拢。请重点参考 `docs/ui_reference_bank_client.png` 与 `docs/ui_reference_bank_client.html` 实施重构：

1. **视觉规范落地（改 `frontend/src/styles.css` 与 `App.tsx`）**：
   - 顶栏增加标志性商业银行深海蓝顶栏 `#0D2B52` + 顶部 `3px` 金融红饰条 `#B91C1C`，明确展示批次号、模型版本与脱敏角色徽标；
   - 左侧内网菜单栏采用深灰蓝 `#162B47` + 左侧 `3px` 亮金指示条 `#E5A93C`（激活态 `#0D4C92`）；
   - 全局画布 `#F0F3F7`，卡片采用**锐利小圆角 `2px` + 清晰 `1px solid #CBD5E1` 细边框**，移除柔和悬浮阴影与大圆角卡片；
   - 表格与指标全面开启等宽对齐数字（`font-variant-numeric: tabular-nums` + `Consolas` / `Microsoft YaHei`）。
2. **告警页重构为“左队列 + 右联动证据卡”双栏布局（改 `Alerts.tsx` + `AlertDrawer.tsx`）**：
   - 取消纯点击弹窗遮罩抽屉，改为左栏（~42% 宽：`日期`、`排名`、`用户代号`、`风险分`、`评分来源` 紧凑型边框表格 + 当日受检/冷却抑制 KPI 条）与右栏（~58% 宽：同批次选中用户的身份合规网格 + 近 30 日行为通道曲线 + `Soft-Peer` 历史对照表 + `PAI-Mean` 分项条形归因 + 底部闭环处置按钮组）实时联动。
3. **验证闭环**：每次前端改动后执行 `pnpm run build`（确保 TypeScript 无报错且同步 `frontend/dist/`），同时运行 `pytest -q` 确保后端 API 全部通过。
