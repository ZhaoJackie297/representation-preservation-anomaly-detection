export type Role =
  | "first_line_reviewer"
  | "second_line_risk"
  | "third_line_audit";

export interface RunSummary {
  run_id: string;
  run_mode: "unlabeled_live" | "simulated_drill" | "benchmark";
  model_version: string;
  status: string;
  started_at: string | null;
  completed_at: string | null;
  abs_rho: number | null;
  route: string | null;
  selected_metric: string | null;
  top_k: number;
  cooldown_days: number;
  alert_count: number;
  synthetic_banner: string | null;
}

export interface Health {
  status: string;
  database_connected: boolean;
  latest_run_id: string | null;
  model_frozen: boolean;
  model_version: string;
  environment_mode: string;
}

export interface SmaEstimate {
  preset: string;
  business_indicator: number;
  business_indicator_component: number;
  loss_component_ratio: number;
  internal_loss_multiplier: number;
  baseline_operational_risk_capital: number;
  assumed_risk_reduction_rate: number;
  estimated_capital_release: number;
  note: string;
}

export interface RouterPoint {
  window_days: number;
  abs_rho: number;
  rho: number;
  norm_cv: number;
  route: string;
}

export interface Overview {
  run: RunSummary;
  total_active_employee_days: number;
  latest_active_employees: number;
  evaluation_active_employee_days: number;
  evaluation_employee_count: number;
  daily_top_k: number;
  alert_count: number;
  cooldown_suppressed_candidates: number;
  funnel: Array<{ stage: string; count: number }>;
  router_curve: RouterPoint[];
  recommended_metric: string;
  sma_capital_estimate: SmaEstimate;
  synthetic_banner: string | null;
}

export interface AlertItem {
  alert_id: string;
  run_id: string;
  employee_id_masked: string;
  alert_date: string;
  rank: number;
  risk_score: number;
  grid_name: string;
  role_name: string;
  basel_category: string;
  data_sensitivity_jr_t_0197: string;
  personal_info_jr_t_0171: string;
  watchlist_flag: boolean;
  reason_code: string;
  status: string;
}

export interface AlertPage {
  items: AlertItem[];
  pagination: {
    page: number;
    page_size: number;
    total: number;
    pages: number;
  };
}

export interface BehaviorDimension {
  feature: string;
  label_zh: string;
  value: number;
  peer_mean: number | null;
  self_median: number | null;
}

export interface AlertDetail {
  alert: AlertItem;
  evidence_card: Record<string, unknown>;
  behavior_dimensions: BehaviorDimension[];
  radial_angular: {
    route: string;
    radial_energy_share: number;
    spearman_norm_vs_input: number;
    norm_cv: number;
  };
  soft_peer_baseline: {
    profile_dimensions: number;
    peer_ids: string[];
    peer_channel_means: Record<string, number>;
    self_hist_channel_medians: Record<string, number>;
  };
  timeline_30d: Array<{
    alert_id: string;
    date: string;
    risk_score: number;
    rank: number;
  }>;
  regulatory_mapping: Record<string, unknown>;
  ldc_history: Array<Record<string, unknown>>;
  synthetic_banner: string | null;
}

export interface AuditItem {
  id: string;
  actor_role: string;
  timestamp: string;
  target_entity: string;
  reason: string;
  action: string;
  action_details: Record<string, unknown>;
}

export interface AuditPage {
  items: AuditItem[];
  pagination: {
    page: number;
    page_size: number;
    total: number;
    pages: number;
  };
}

export interface WatchlistItem {
  id: string;
  employee_id: string;
  reason: string;
  active: boolean;
  created_by: string;
  created_at: string;
  expires_at: string | null;
}

export interface UnmaskResult {
  employee_id: string;
  employee_code: string;
  employee_name: string;
  role_name: string;
  grid_name: string;
  audit_written: boolean;
}
