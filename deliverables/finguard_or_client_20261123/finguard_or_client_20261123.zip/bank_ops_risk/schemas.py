"""Pydantic v2 schemas for the FinGuard-OR API."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


RunMode = Literal["unlabeled_live", "simulated_drill", "benchmark"]
Role = Literal["first_line_reviewer", "second_line_risk", "third_line_audit"]
ReviewVerdict = Literal[
    "confirmed_risk",
    "false_positive",
    "watchlist_observe",
    "escalate_audit",
]


class HealthResponse(BaseModel):
    status: Literal["ok"]
    database_connected: bool
    latest_run_id: str | None
    model_frozen: bool
    model_version: str
    environment_mode: str


class RunSummary(BaseModel):
    run_id: str
    run_mode: RunMode
    model_version: str
    status: str
    started_at: datetime | None
    completed_at: datetime | None
    abs_rho: float | None
    route: str | None
    selected_metric: str | None
    top_k: int
    cooldown_days: int
    alert_count: int
    synthetic_banner: str | None = None


class DrillRunRequest(BaseModel):
    input_path: str | None = None
    force_refresh: bool = True


class RunCreated(BaseModel):
    run_id: str
    run_mode: RunMode
    alert_count: int
    cross_modal_audit: dict[str, Any]
    synthetic_banner: str | None = None


class AlertItem(BaseModel):
    alert_id: str
    run_id: str
    employee_id_masked: str
    alert_date: str
    rank: int
    risk_score: float
    grid_name: str
    role_name: str
    basel_category: str
    data_sensitivity_jr_t_0197: str
    personal_info_jr_t_0171: str
    watchlist_flag: bool
    reason_code: str
    status: str


class Pagination(BaseModel):
    page: int
    page_size: int
    total: int
    pages: int


class AlertPage(BaseModel):
    items: list[AlertItem]
    pagination: Pagination


class EvidenceDimension(BaseModel):
    feature: str
    label_zh: str
    value: float
    peer_mean: float | None = None
    self_median: float | None = None


class AlertDetail(BaseModel):
    alert: AlertItem
    evidence_card: dict[str, Any]
    behavior_dimensions: list[EvidenceDimension]
    radial_angular: dict[str, Any]
    soft_peer_baseline: dict[str, Any]
    timeline_30d: list[dict[str, Any]]
    regulatory_mapping: dict[str, Any]
    ldc_history: list[dict[str, Any]]
    synthetic_banner: str | None = None


class ReviewRequest(BaseModel):
    verdict: ReviewVerdict
    disposition: str = Field(min_length=1, max_length=2000)
    reviewer_note: str = Field(default="", max_length=4000)
    corrected_basel_category: str | None = Field(default=None, max_length=128)


class ReviewResponse(BaseModel):
    review_id: str
    alert_id: str
    verdict: ReviewVerdict
    database_state: str
    watchlist_added: bool
    audit_written: bool


class UnmaskResponse(BaseModel):
    employee_id: str
    employee_code: str
    employee_name: str
    role_name: str
    grid_name: str
    audit_written: bool


class WatchlistCreate(BaseModel):
    employee_id: str = Field(min_length=1, max_length=64)
    reason: str = Field(min_length=1, max_length=2000)
    active: bool = True
    expires_at: datetime | None = None


class WatchlistItem(BaseModel):
    id: str
    employee_id: str
    reason: str
    active: bool
    created_by: str
    created_at: datetime
    expires_at: datetime | None


class AuditItem(BaseModel):
    id: str
    actor_role: str
    timestamp: datetime
    target_entity: str
    reason: str
    action: str
    action_details: dict[str, Any]


class AuditPage(BaseModel):
    items: list[AuditItem]
    pagination: Pagination


class SmaPreset(BaseModel):
    key: str
    label: str
    interest_income: float
    services_income: float
    financial_income: float
    loss_component: float
    assumed_risk_reduction_rate: float


class SmaCapitalEstimate(BaseModel):
    preset: str
    business_indicator: float
    business_indicator_component: float
    loss_component_ratio: float
    internal_loss_multiplier: float
    baseline_operational_risk_capital: float
    assumed_risk_reduction_rate: float
    estimated_capital_release: float
    note: str


class OverviewResponse(BaseModel):
    run: RunSummary
    total_active_employee_days: int
    latest_active_employees: int
    evaluation_active_employee_days: int
    evaluation_employee_count: int
    daily_top_k: int
    alert_count: int
    cooldown_suppressed_candidates: int
    funnel: list[dict[str, Any]]
    router_curve: list[dict[str, Any]]
    recommended_metric: str
    sma_capital_estimate: SmaCapitalEstimate
    synthetic_banner: str | None = None
