"""FinGuard-OR model abstraction around the frozen SoftInst-Rand encoder."""

from __future__ import annotations

import importlib.util
import json
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as torch_functional
from scipy.stats import spearmanr
from sklearn.cluster import MiniBatchKMeans


PACKAGE_ROOT = Path(__file__).resolve().parent
DEFAULT_REPO_ROOT = Path(
    r"C:\Users\Lenovo\Documents\Codex\2026-11-07"
    r"\files-pasted-by-the-user-2026"
    r"\representation-preservation-anomaly-detection"
)
DEFAULT_CHECKPOINT = (
    DEFAULT_REPO_ROOT
    / "research"
    / "ccf-b"
    / "supplement_results"
    / "exp_s5a_norm_intervention"
    / "SoftInst-Rand"
    / "seed_20261116"
    / "model.pth"
)

FEATURE_NAMES = [
    "has_any_event",
    "logon_count",
    "logoff_count",
    "first_logon_minute",
    "last_logoff_minute",
    "active_span_minutes",
    "after_hours_logon_count",
    "other_pc_logon_count",
    "usb_connect_count",
    "usb_disconnect_count",
    "file_copy_count",
    "archive_copy_count",
    "executable_copy_count",
    "unique_file_extensions",
    "email_count",
    "email_recipient_count",
    "external_recipient_count",
    "email_attachment_count",
    "email_size_bytes",
    "after_hours_email_count",
    "http_count",
    "after_hours_http_count",
    "external_http_count",
    "unique_http_domains",
    "is_weekend",
    "weekday_sin",
    "weekday_cos",
]
INDEX = {name: index for index, name in enumerate(FEATURE_NAMES)}
TIMING_INDICES = [
    INDEX["first_logon_minute"],
    INDEX["last_logoff_minute"],
    INDEX["active_span_minutes"],
]
COUNT_INDICES = [
    INDEX[name]
    for name in FEATURE_NAMES[1:3] + FEATURE_NAMES[6:24]
]
CALENDAR_INDICES = [
    INDEX["has_any_event"],
    INDEX["is_weekend"],
    INDEX["weekday_sin"],
    INDEX["weekday_cos"],
]
CHANNEL_GROUPS = {
    "login": [
        INDEX["logon_count"],
        INDEX["logoff_count"],
        INDEX["after_hours_logon_count"],
        INDEX["other_pc_logon_count"],
    ],
    "usb": [
        INDEX["usb_connect_count"],
        INDEX["usb_disconnect_count"],
    ],
    "export": [
        INDEX["file_copy_count"],
        INDEX["archive_copy_count"],
        INDEX["executable_copy_count"],
        INDEX["unique_file_extensions"],
    ],
    "mail": [
        INDEX["email_count"],
        INDEX["email_recipient_count"],
        INDEX["external_recipient_count"],
        INDEX["email_attachment_count"],
        INDEX["email_size_bytes"],
        INDEX["after_hours_email_count"],
    ],
    "web": [
        INDEX["http_count"],
        INDEX["after_hours_http_count"],
        INDEX["external_http_count"],
        INDEX["unique_http_domains"],
    ],
}
PROFILE_FEATURES = [
    *[INDEX[name] for name in FEATURE_NAMES[1:3]],
    *[INDEX[name] for name in FEATURE_NAMES[6:24]],
    *TIMING_INDICES,
]


def load_coverage_model_class(repo_root: Path = DEFAULT_REPO_ROOT):
    module_path = repo_root / "research" / "ccf-b" / "phase0" / "coverage_soft_ts2vec.py"
    if not module_path.is_file():
        raise FileNotFoundError(module_path)
    module_name = "bank_ops_coverage_soft_ts2vec"
    if module_name in sys.modules:
        return sys.modules[module_name].CoverageSoftTS2Vec
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    previous_dont_write_bytecode = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous_dont_write_bytecode
    return module.CoverageSoftTS2Vec


def sanitize_model_values(raw: np.ndarray) -> np.ndarray:
    """Apply the frozen model's missing-safe feature contract."""
    values = np.asarray(raw, dtype=np.float32).copy()
    counts = values[:, :, COUNT_INDICES]
    values[:, :, COUNT_INDICES] = np.where(
        np.isfinite(counts),
        np.log1p(np.maximum(counts, 0.0)),
        np.nan,
    )
    timing = values[:, :, TIMING_INDICES]
    values[:, :, TIMING_INDICES] = np.where(
        np.isfinite(timing) & (timing >= 0),
        timing,
        np.nan,
    )
    calendar = values[:, :, CALENDAR_INDICES]
    values[:, :, CALENDAR_INDICES] = np.where(
        np.isfinite(calendar),
        calendar,
        np.nan,
    )
    return values


def baseline_standardize(
    values: np.ndarray,
    baseline_days: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    if values.shape[1] <= baseline_days:
        raise ValueError("sequence must extend beyond the baseline window")
    baseline = values[:, :baseline_days, :]
    mean = np.nanmean(baseline, axis=(0, 1), keepdims=True)
    std = np.nanstd(baseline, axis=(0, 1), keepdims=True)
    mean = np.where(np.isfinite(mean), mean, 0.0)
    std = np.where(np.isfinite(std) & (std >= 1e-8), std, 1.0)
    normalized = (values - mean) / std
    return (
        normalized.astype(np.float32),
        mean.squeeze(0).squeeze(0),
        std.squeeze(0).squeeze(0),
    )


def causal_moving_average(values: np.ndarray, window: int) -> np.ndarray:
    output = np.full(values.shape, np.nan, dtype=np.float64)
    for user in range(values.shape[0]):
        history: list[np.ndarray] = []
        for time in range(values.shape[1]):
            if not np.isfinite(values[user, time]).all():
                history.clear()
                continue
            history.append(values[user, time].astype(np.float64, copy=True))
            if len(history) > window:
                history.pop(0)
            output[user, time] = np.mean(history, axis=0)
    return output.astype(np.float32)


@dataclass
class ModelRunnerConfig:
    checkpoint_path: Path = DEFAULT_CHECKPOINT
    repo_root: Path = DEFAULT_REPO_ROOT
    baseline_days: int = 90
    top_k: int = 10
    cooldown_days: int = 7
    bank_clusters: int = 500
    alpha: float = 0.5
    peer_top_n: int = 10
    device: str = "cpu"


@dataclass
class RunResult:
    run_mode: str
    model_version: str
    cross_modal_audit: dict[str, Any]
    metrics: dict[str, Any]
    alerts: list[dict[str, Any]]


class ModelRunner:
    """Runtime abstraction isolating model, device, scoring and diagnostics."""

    def __init__(self, config: ModelRunnerConfig | None = None) -> None:
        self.config = config or ModelRunnerConfig()
        self.device = self._resolve_device(self.config.device)
        model_class = load_coverage_model_class(self.config.repo_root)
        self.model = model_class(
            input_dims=27,
            output_dims=64,
            hidden_dims=64,
            depth=5,
            device=0 if self.device.type == "cuda" else "cpu",
            lr=1e-3,
            batch_size=16,
            lambda_=0.5,
            tau_temp=1.5,
            soft_instance=False,
            soft_temporal=False,
        )
        state = torch.load(
            self.config.checkpoint_path,
            map_location=self.device,
            weights_only=True,
        )
        if any(key.startswith("module.") for key in state):
            self.model.net.load_state_dict(state)
        else:
            self.model._net.load_state_dict(state)
        self.model.net.eval()

    @staticmethod
    def _resolve_device(requested: str) -> torch.device:
        if requested == "auto":
            return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        device = torch.device(requested)
        if device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but unavailable")
        return device

    def load_unlabeled_csv(self, path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Read only the production template columns; never load label columns."""
        required = ["user_id", "date", *FEATURE_NAMES]
        header = pd.read_csv(path, nrows=0)
        missing = [column for column in required if column not in header.columns]
        if missing:
            raise ValueError(f"Missing unlabeled CSV columns: {missing}")
        frame = pd.read_csv(
            path,
            usecols=required,
            parse_dates=["date"],
        )
        users = np.sort(frame["user_id"].astype(str).unique())
        dates = pd.DatetimeIndex(sorted(frame["date"].unique()))
        index = pd.MultiIndex.from_product(
            [users, dates],
            names=["user_id", "date"],
        )
        aligned = (
            frame.set_index(["user_id", "date"])
            .reindex(index)
        )
        raw = aligned[FEATURE_NAMES].to_numpy(dtype=np.float32).reshape(
            len(users),
            len(dates),
            len(FEATURE_NAMES),
        )
        has_any = raw[:, :, INDEX["has_any_event"]]
        active = np.isfinite(has_any) & (has_any > 0)
        return raw, users, np.asarray(dates), active

    def prepare_sequences(
        self,
        raw: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        sanitized = sanitize_model_values(raw)
        normalized, mean, std = baseline_standardize(
            sanitized,
            self.config.baseline_days,
        )
        return normalized, mean, std

    def encode(self, normalized: np.ndarray) -> np.ndarray:
        with torch.inference_mode():
            return np.asarray(
                self.model.encode(
                    normalized,
                    causal=True,
                    sliding_length=1,
                    sliding_padding=30,
                    batch_size=256,
                ),
                dtype=np.float32,
            )

    def _fit_bank(
        self,
        representations: np.ndarray,
        active: np.ndarray,
    ) -> tuple[MiniBatchKMeans, np.ndarray]:
        train = representations[
            :, : self.config.baseline_days
        ][active[:, : self.config.baseline_days]]
        clusters = min(self.config.bank_clusters, max(1, int(round(0.1 * len(train)))))
        clusters = min(clusters, len(train) - 1)
        bank = MiniBatchKMeans(
            n_clusters=clusters,
            init="k-means++",
            random_state=2024,
            batch_size=max(8192, clusters),
            max_iter=50,
            n_init=1,
            reassignment_ratio=0.01,
        ).fit(train)
        return bank, bank.cluster_centers_.astype(np.float32)

    def _bank_scores(
        self,
        representations: np.ndarray,
        active: np.ndarray,
        centers: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        center_tensor = torch.from_numpy(centers).to(self.device)
        center_norm = torch_functional.normalize(center_tensor, dim=1)
        users, times = np.nonzero(active)
        query_values = representations[users, times]
        cosine_parts = []
        euclidean_parts = []
        with torch.inference_mode():
            for start in range(0, len(query_values), 4096):
                query = torch.from_numpy(
                    query_values[start : start + 4096].astype(np.float32)
                ).to(self.device)
                query_norm = torch_functional.normalize(query, dim=1)
                cosine = (1.0 - query_norm @ center_norm.T).clamp_min_(0.0)
                euclidean = torch.cdist(query, center_tensor)
                cosine_parts.append(
                    cosine.topk(3, dim=1, largest=False)
                    .values.mean(dim=1)
                    .cpu()
                    .numpy()
                )
                euclidean_parts.append(
                    euclidean.topk(3, dim=1, largest=False)
                    .values.mean(dim=1)
                    .cpu()
                    .numpy()
                )
        cosine_score = np.full(active.shape, np.nan, dtype=np.float32)
        euclidean_score = np.full(active.shape, np.nan, dtype=np.float32)
        cosine_score[users, times] = np.concatenate(cosine_parts)
        euclidean_score[users, times] = np.concatenate(euclidean_parts)
        return cosine_score, euclidean_score

    @staticmethod
    def _train_z(
        values: np.ndarray,
        active: np.ndarray,
        baseline_days: int,
    ) -> np.ndarray:
        mask = active[:, :baseline_days] & np.isfinite(values[:, :baseline_days])
        train = values[:, :baseline_days][mask]
        mean = float(train.mean())
        std = max(float(train.std()), 1e-8)
        return ((values - mean) / std).astype(np.float32)

    def _amplitude_scores(
        self,
        sanitized: np.ndarray,
        active: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        count_values = sanitized[:, :, COUNT_INDICES]
        global_values = []
        for group in CHANNEL_GROUPS.values():
            group_local = [
                COUNT_INDICES.index(index)
                for index in group
            ]
            selected = count_values[:, :, group_local]
            train = selected[:, : self.config.baseline_days][
                active[:, : self.config.baseline_days]
            ]
            median = np.nanmedian(train, axis=0)
            mad = np.nanmedian(np.abs(train - median), axis=0)
            scale = np.maximum(1.4826 * mad, 1e-6)
            z = np.abs(selected - median) / scale
            global_values.append(np.nanmean(z, axis=-1))
        global_score = np.stack(global_values, axis=-1)
        global_score = np.nanmax(global_score, axis=-1)

        moving = causal_moving_average(count_values, 32)
        train_moving = moving[:, : self.config.baseline_days][
            active[:, : self.config.baseline_days]
        ]
        median = np.nanmedian(train_moving, axis=0)
        mad = np.nanmedian(np.abs(train_moving - median), axis=0)
        scale = np.maximum(1.4826 * mad, 1e-6)
        t2_score = np.nanmean(np.abs(moving - median) / scale, axis=-1)
        global_score[~active] = np.nan
        t2_score[~active] = np.nan
        return global_score, t2_score

    def _profiles(
        self,
        sanitized: np.ndarray,
        active: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        rows = []
        channel_means = []
        baseline_active = active[:, : self.config.baseline_days]
        for user in range(sanitized.shape[0]):
            mask = baseline_active[user]
            selected = sanitized[user, : self.config.baseline_days][mask][:, PROFILE_FEATURES]
            if len(selected) == 0:
                selected = sanitized[user, : self.config.baseline_days][:, PROFILE_FEATURES]
            median = np.nanmedian(selected, axis=0)
            q90 = np.nanquantile(selected, 0.9, axis=0)
            rows.append(
                np.concatenate([median, q90, [mask.mean()]])
            )
            channel_row = []
            for group in CHANNEL_GROUPS.values():
                values = sanitized[user, : self.config.baseline_days][mask][:, group]
                channel_row.append(
                    float(np.nanmean(values)) if len(values) else 0.0
                )
            channel_means.append(channel_row)
        profile = np.stack(rows)
        population = np.nanmedian(profile, axis=0)
        population = np.where(np.isfinite(population), population, 0.0)
        missing_rows, missing_columns = np.nonzero(~np.isfinite(profile))
        profile[missing_rows, missing_columns] = population[missing_columns]
        mean = profile.mean(axis=0)
        std = np.where(profile.std(axis=0) < 1e-8, 1.0, profile.std(axis=0))
        return (
            ((profile - mean) / std).astype(np.float64),
            np.asarray(channel_means, dtype=np.float32),
        )

    def _peer_weights(
        self,
        profiles: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        distances = np.linalg.norm(
            profiles[:, None, :] - profiles[None, :, :],
            axis=-1,
        )
        upper = distances[np.triu_indices(len(profiles), k=1)]
        minimum = float(upper.min())
        maximum = float(upper.max())
        scale = maximum - minimum
        normalized = (
            (distances - minimum) / scale
            if scale > 1e-12
            else np.zeros_like(distances)
        )
        normalized = np.clip(normalized, 0.0, 1.0)
        median = float(
            np.median(normalized[np.triu_indices(len(normalized), k=1)])
        )
        tau = 1.0 / max(median, 1e-6)
        weights = (
            2.0 * self.config.alpha / (1.0 + np.exp(tau * normalized))
            + (1.0 - self.config.alpha) * np.eye(len(profiles))
        )
        return weights.astype(np.float32), normalized

    def _diagnose_modality(
        self,
        representations: np.ndarray,
        sanitized: np.ndarray,
        active: np.ndarray,
        centers: np.ndarray,
    ) -> dict[str, Any]:
        baseline_active = active[:, : self.config.baseline_days]
        train_repr = representations[:, : self.config.baseline_days][baseline_active]
        norms = np.linalg.norm(train_repr, axis=-1)
        input_norm = np.linalg.norm(
            sanitized[:, : self.config.baseline_days][
                :, :, COUNT_INDICES
            ][baseline_active],
            axis=-1,
        )
        rho = float(spearmanr(norms, input_norm)[0])
        norm_cv = float(norms.std() / max(norms.mean(), 1e-8))
        center_tensor = torch.from_numpy(centers).to(self.device)
        center_r = torch.linalg.norm(center_tensor, dim=1)
        center_norm = torch_functional.normalize(center_tensor, dim=1)
        query = torch.from_numpy(train_repr.astype(np.float32)).to(self.device)
        query_r = torch.linalg.norm(query, dim=1)
        query_norm = torch_functional.normalize(query, dim=1)
        with torch.inference_mode():
            distance = torch.cdist(query, center_tensor)
            _, top_index = distance.topk(3, dim=1, largest=False)
            nearest_r = center_r[top_index]
            cosine = (1.0 - query_norm @ center_norm.T).clamp_min_(0.0)
            selected_cosine = torch.gather(cosine, 1, top_index)
            radial_sq = (query_r.unsqueeze(1) - nearest_r) ** 2
            angular = 2.0 * query_r.unsqueeze(1) * nearest_r * selected_cosine
            radial_share = (
                radial_sq.mean(dim=1)
                / (radial_sq + angular).mean(dim=1).clamp_min(1e-12)
            ).mean()
        radial_route = bool(rho > 0.50 and norm_cv > 0.50)
        selected_metric = "bank_euclidean" if radial_route else "pai_mean"
        training_window_curve = []
        for window in (30, 60, 90):
            window = min(window, self.config.baseline_days)
            start = self.config.baseline_days - window
            window_active = active[:, start : self.config.baseline_days]
            window_repr = representations[
                :, start : self.config.baseline_days
            ][window_active]
            window_input = sanitized[
                :, start : self.config.baseline_days
            ][:, :, COUNT_INDICES][window_active]
            window_norms = np.linalg.norm(window_repr, axis=-1)
            window_input_norm = np.linalg.norm(window_input, axis=-1)
            window_rho = float(spearmanr(window_norms, window_input_norm)[0])
            window_cv = float(
                window_norms.std() / max(window_norms.mean(), 1e-8)
            )
            training_window_curve.append(
                {
                    "window_days": window,
                    "abs_rho": abs(window_rho),
                    "rho": window_rho,
                    "norm_cv": window_cv,
                    "route": (
                        "radial"
                        if window_rho > 0.50 and window_cv > 0.50
                        else "angular"
                    ),
                }
            )
        return {
            "protocol": "zero_label_training_window",
            "baseline_days": self.config.baseline_days,
            "norm_mean": float(norms.mean()),
            "norm_cv": norm_cv,
            "spearman_repr_norm_vs_input_norm": rho,
            "radial_energy_share": float(radial_share.cpu().item()),
            "route": "radial" if radial_route else "angular",
            "selected_metric": selected_metric,
            "training_window_curve": training_window_curve,
            "rule": "rho > 0.50 and cv > 0.50 -> bank_euclidean; otherwise PAI-Mean",
        }

    def _transition_metrics(
        self,
        representations: np.ndarray,
        active: np.ndarray,
        user: int,
        time: int,
    ) -> tuple[float, float]:
        previous = np.flatnonzero(active[user, :time])
        if len(previous) == 0:
            return 0.0, 0.0
        prev = int(previous[-1])
        current_vec = representations[user, time]
        prev_vec = representations[user, prev]
        denom = max(
            float(np.linalg.norm(current_vec) * np.linalg.norm(prev_vec)),
            1e-8,
        )
        velocity = float(
            1.0 - np.dot(current_vec, prev_vec) / denom
        )
        older = np.flatnonzero(active[user, :prev])
        if len(older) == 0:
            return velocity, 0.0
        older_vec = representations[user, int(older[-1])]
        older_denom = max(
            float(np.linalg.norm(prev_vec) * np.linalg.norm(older_vec)),
            1e-8,
        )
        previous_velocity = float(
            1.0 - np.dot(prev_vec, older_vec) / older_denom
        )
        return velocity, abs(velocity - previous_velocity)

    def _build_alerts(
        self,
        selected_score: np.ndarray,
        active: np.ndarray,
    ) -> tuple[list[tuple[int, int, float]], int]:
        last_alert = np.full(active.shape[0], -10000, dtype=int)
        alerts = []
        suppressed = 0
        for time in range(self.config.baseline_days, active.shape[1]):
            available = active[:, time] & (
                time - last_alert >= self.config.cooldown_days
            )
            blocked = int((active[:, time] & ~available).sum())
            suppressed += blocked
            candidates = np.flatnonzero(
                available & np.isfinite(selected_score[:, time])
            )
            if len(candidates) == 0:
                continue
            order = candidates[
                np.lexsort((candidates, -selected_score[candidates, time]))
            ][: self.config.top_k]
            for rank, user in enumerate(order, start=1):
                alerts.append((int(user), time, float(selected_score[user, time])))
            last_alert[order] = time
        return alerts, suppressed

    def _reason(
        self,
        raw_row: np.ndarray,
        peers: np.ndarray,
        self_median: np.ndarray,
    ) -> tuple[str, str, str, str]:
        group_names = list(CHANNEL_GROUPS)
        scores = []
        for group_index, indices in enumerate(CHANNEL_GROUPS.values()):
            observed = float(np.nanmean(raw_row[indices]))
            baseline = max(float(self_median[group_index]), 1.0)
            scores.append(observed / baseline)
        top = int(np.argmax(scores))
        group = group_names[top]
        if group in ("export", "usb"):
            sensitivity = "L4"
            personal = "C3"
            basel = "内部欺诈——盗窃与欺诈"
            reason = f"{group}_sensitive_data_movement"
        elif group in ("web", "mail"):
            sensitivity = "L3"
            personal = "C2"
            basel = "内部欺诈——未经授权活动"
            reason = f"{group}_external_channel_drift"
        else:
            sensitivity = "L2"
            personal = "C1"
            basel = "执行、交割和流程管理"
            reason = "login_and_timing_drift"
        return reason, basel, sensitivity, personal

    def run(self, csv_path: Path, run_mode: str = "unlabeled_live") -> RunResult:
        if run_mode not in ("unlabeled_live", "simulated_drill", "benchmark"):
            raise ValueError(f"Unsupported run_mode: {run_mode}")
        started = pd.Timestamp.now(tz="Asia/Shanghai")
        raw, users, date_values, active = self.load_unlabeled_csv(csv_path)
        normalized, mean, std = self.prepare_sequences(raw)
        sanitized = sanitize_model_values(raw)
        representations = self.encode(normalized)
        bank, centers = self._fit_bank(representations, active)
        cosine_raw, euclidean_raw = self._bank_scores(
            representations,
            active,
            centers,
        )
        with torch.inference_mode():
            masked_repr = np.asarray(
                self.model.encode(
                    normalized,
                    mask="mask_last",
                    causal=True,
                    sliding_length=1,
                    sliding_padding=30,
                    batch_size=256,
                ),
                dtype=np.float32,
            )
        masked_l1 = np.abs(masked_repr - representations).sum(axis=-1)
        mag_raw, t2_raw = self._amplitude_scores(sanitized, active)
        z_cos = self._train_z(cosine_raw, active, self.config.baseline_days)
        z_euc = self._train_z(euclidean_raw, active, self.config.baseline_days)
        z_mag = self._train_z(mag_raw, active, self.config.baseline_days)
        z_t2 = self._train_z(t2_raw, active, self.config.baseline_days)
        z_mask = self._train_z(masked_l1, active, self.config.baseline_days)
        pai_mean = z_euc + 0.6 * z_mag + 0.4 * z_t2
        cross_modal = self._diagnose_modality(
            representations,
            sanitized,
            active,
            centers,
        )
        metric_bank = {
            "bank_cosine": z_cos,
            "bank_euclidean": z_euc,
            "pai_mean": pai_mean,
            "plain_l1": z_mask,
        }
        selected_score = metric_bank[
            cross_modal["selected_metric"]
            if cross_modal["selected_metric"] in metric_bank
            else "pai_mean"
        ]
        alerts, cooldown_suppressed = self._build_alerts(
            selected_score,
            active,
        )
        profiles, channel_means = self._profiles(sanitized, active)
        peer_weights, _ = self._peer_weights(profiles)
        alert_rows = []
        for user, time, score in alerts:
            peers = [
                value
                for value in np.argsort(-peer_weights[user])
                if value != user
            ][: self.config.peer_top_n]
            peer_channel_means = channel_means[peers].mean(axis=0)
            self_median = channel_means[user]
            velocity, curvature = self._transition_metrics(
                representations,
                active,
                user,
                time,
            )
            reason, basel, sensitivity, personal = self._reason(
                raw[user, time],
                peer_channel_means,
                self_median,
            )
            evidence = {
                "evidence_card_type": "multi_view_manifold_evidence_card",
                "z_cos": float(z_cos[user, time]),
                "z_euc": float(z_euc[user, time]),
                "z_magG": float(z_mag[user, time]),
                "z_T2": float(z_t2[user, time]),
                "manifold_velocity": velocity,
                "manifold_curvature": curvature,
                "peer_channel_means": {
                    name: float(peer_channel_means[index])
                    for index, name in enumerate(CHANNEL_GROUPS)
                },
                "self_hist_channel_medians": {
                    name: float(self_median[index])
                    for index, name in enumerate(CHANNEL_GROUPS)
                },
                "raw_first_logon_min": float(
                    raw[user, time, INDEX["first_logon_minute"]]
                ),
                "raw_last_logoff_min": float(
                    raw[user, time, INDEX["last_logoff_minute"]]
                ),
                "raw_active_span_min": float(
                    raw[user, time, INDEX["active_span_minutes"]]
                ),
                "raw_usb_connect_count": float(
                    raw[user, time, INDEX["usb_connect_count"]]
                ),
                "peer_ids": [str(users[index]) for index in peers],
            }
            alert_rows.append(
                {
                    "employee_id": str(users[user]),
                    "alert_date": pd.Timestamp(date_values[time]).strftime("%Y-%m-%d"),
                    "rank": next(
                        rank
                        for rank, (candidate_user, candidate_time, _) in enumerate(
                            alerts,
                            start=1,
                        )
                        if candidate_user == user and candidate_time == time
                    ),
                    "risk_score": score,
                    "reason_code": reason,
                    "basel_category": basel,
                    "data_sensitivity_jr_t_0197": sensitivity,
                    "personal_info_jr_t_0171": personal,
                    "subscores": {
                        "z_cos": evidence["z_cos"],
                        "z_euc": evidence["z_euc"],
                        "z_magG": evidence["z_magG"],
                        "z_T2": evidence["z_T2"],
                        "z_mask": float(z_mask[user, time]),
                    },
                    "evidence_card": evidence,
                    "watchlist_flag": False,
                }
            )
        finite_selected = selected_score[
            active & np.isfinite(selected_score)
        ]
        metrics = {
            "run_mode": run_mode,
            "execution_profile": "fast_bank_refit_cpu"
            if self.device.type == "cpu"
            else f"fast_bank_refit_{self.device.type}",
            "device": str(self.device),
            "top_k": self.config.top_k,
            "cooldown_days": self.config.cooldown_days,
            "alert_count": len(alert_rows),
            "alerted_employee_count": len(
                {row["employee_id"] for row in alert_rows}
            ),
            "daily_average_alerts": len(alert_rows)
            / max(raw.shape[1] - self.config.baseline_days, 1),
            "cooldown_suppressed_candidates": cooldown_suppressed,
            "active_employee_days": int(active.sum()),
            "latest_active_employees": int(active[:, -1].sum()),
            "evaluation_active_employee_days": int(
                active[:, self.config.baseline_days :].sum()
            ),
            "evaluation_employee_count": int(
                np.any(active[:, self.config.baseline_days :], axis=1).sum()
            ),
            "evaluation_day_count": int(
                active.shape[1] - self.config.baseline_days
            ),
            "score_distribution": {
                "min": float(finite_selected.min()),
                "p50": float(np.quantile(finite_selected, 0.50)),
                "p95": float(np.quantile(finite_selected, 0.95)),
                "p99": float(np.quantile(finite_selected, 0.99)),
                "max": float(finite_selected.max()),
            },
            "calibration": {
                "mean": mean.tolist(),
                "std": std.tolist(),
                "baseline_days": self.config.baseline_days,
            },
        }
        return RunResult(
            run_mode=run_mode,
            model_version="SoftInst-Rand-seed20261116-v1",
            cross_modal_audit=cross_modal,
            metrics=metrics,
            alerts=alert_rows,
        )

    def fast_bank_refit(
        self,
        csv_path: Path,
        run_mode: str = "unlabeled_live",
    ) -> RunResult:
        """Named entry point for the CPU-oriented no-retraining profile."""
        if self.device.type != "cpu":
            raise ValueError(
                "fast_bank_refit requires ModelRunnerConfig(device='cpu')"
            )
        return self.run(csv_path, run_mode=run_mode)


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Run frozen SoftInst-Rand inference")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument(
        "--mode",
        choices=["unlabeled_live", "simulated_drill", "benchmark"],
        default="unlabeled_live",
    )
    parser.add_argument("--checkpoint", type=Path, default=DEFAULT_CHECKPOINT)
    parser.add_argument("--top-k", type=int, default=10)
    args = parser.parse_args()
    runner = ModelRunner(
        ModelRunnerConfig(
            checkpoint_path=args.checkpoint,
            top_k=args.top_k,
        )
    )
    result = runner.run(args.input, args.mode)
    print(json.dumps(asdict(result), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
