import { useState } from "react";
import {
  BadgeAlert,
  Clock3,
  DatabaseZap,
  HardDriveDownload,
  Play,
  ShieldQuestion,
  Usb
} from "lucide-react";
import { api } from "../api";
import { formatNumber, metricLabel } from "../format";
import type { Overview } from "../types";
import {
  ErrorBlock,
  PageHeader,
  SyntheticBanner
} from "../components/Shared";

const scenarios = [
  {
    id: "departure_exfiltration",
    title: "离职前批量外泄",
    description:
      "高敏客群与 C2-C3 个人金融信息批量导出，配合 USB 与非行内邮箱外发。",
    signals: ["文件复制", "外部收件人", "USB", "非营业时段"],
    icon: HardDriveDownload,
    sensitivity: "JR/T 0197 L4-L5 · JR/T 0171 C2-C3"
  },
  {
    id: "after_hours_credit_query",
    title: "非工作时间征信窥探",
    description:
      "00:00-04:00 跨终端查询非管户客户，异常驻留与外部网页访问同步抬升。",
    signals: ["午夜登录", "跨终端", "征信导出", "短时集中"],
    icon: Clock3,
    sensitivity: "JR/T 0197 L4 · JR/T 0171 C3"
  },
  {
    id: "account_borrowing",
    title: "账户借用代操作",
    description:
      "账号通道分布和作息模式突然跨越岗位，出现非惯用终端与代客操作特征。",
    signals: ["岗位漂移", "终端变化", "渠道迁移", "作息异常"],
    icon: Usb,
    sensitivity: "内部欺诈 · 未经授权活动"
  },
  {
    id: "stealth_permission_probe",
    title: "30 天缓慢越权探测",
    description:
      "长期不休假、在岗跨度持续拉长，并渐进增加脚本导出和外部域名访问。",
    signals: ["连续在岗", "脚本落地", "域外访问", "低幅渐进"],
    icon: ShieldQuestion,
    sensitivity: "执行、交割和流程管理"
  }
];

export function DrillLab({
  overview,
  onCreated
}: {
  overview: Overview | null;
  onCreated: (runId: string) => void;
}) {
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const trigger = async () => {
    setRunning(true);
    setError(null);
    try {
      const result = await api.triggerDrill();
      onCreated(result.run_id);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "演练运行失败");
    } finally {
      setRunning(false);
    }
  };
  return (
    <div className="page-stack">
      <PageHeader
        eyebrow="红队演练 / Simulated Drill"
        title="四类银行操作风险红队沙盘"
        description="用固定规则和隐藏真值构造可重复演练，仅用于机制验证与产品演示。"
        actions={
          <button className="button primary" onClick={trigger} disabled={running}>
            <Play size={16} />
            {running ? "推理运行中" : "启动合成演练"}
          </button>
        }
      />
      <SyntheticBanner text="合成演练数据（非真实生产记录）" />
      {error ? <ErrorBlock message={error} /> : null}
      {overview?.synthetic_banner ? (
        <section className="drill-summary panel">
          <div>
            <span className="eyebrow">当前演练批次</span>
            <strong>{overview.run.run_id.slice(0, 12)}…</strong>
          </div>
          <div>
            <span>Top-K 告警</span>
            <strong>{formatNumber(overview.alert_count)}</strong>
          </div>
          <div>
            <span>冷却拦截</span>
            <strong>
              {formatNumber(overview.cooldown_suppressed_candidates)}
            </strong>
          </div>
          <div>
            <span>推荐度量</span>
            <strong>{metricLabel(overview.recommended_metric)}</strong>
          </div>
        </section>
      ) : null}
      <section className="scenario-grid">
        {scenarios.map((scenario, index) => {
          const Icon = scenario.icon;
          return (
            <article className="scenario-card" key={scenario.id}>
              <div className="scenario-index">0{index + 1}</div>
              <div className="scenario-icon">
                <Icon size={21} />
              </div>
              <h2>{scenario.title}</h2>
              <p>{scenario.description}</p>
              <div className="scenario-signals">
                {scenario.signals.map((signal) => (
                  <span key={signal}>{signal}</span>
                ))}
              </div>
              <footer>
                <BadgeAlert size={15} />
                {scenario.sensitivity}
              </footer>
            </article>
          );
        })}
      </section>
      <section className="panel">
        <div className="panel-title">
          <div>
            <span className="eyebrow">判定边界</span>
            <h2>演练结果如何阅读</h2>
          </div>
          <DatabaseZap size={19} />
        </div>
        <p className="prose">
          合成演练能检验行为通道、时间结构和证据链路是否按设计工作，但不能替代真实银行
          生产数据的外部有效性。真实生产模式只读取无标签 CSV，不使用本页面的隐藏评估真值。
        </p>
      </section>
    </div>
  );
}
